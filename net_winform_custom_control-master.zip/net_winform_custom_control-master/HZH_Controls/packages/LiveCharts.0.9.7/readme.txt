==================================
<<<<<<<<<<< IMPORTANT >>>>>>>>>>>>
==================================

LiveCharts is now multipatform (at least the design).

So this package contains nothing but the core of the library, 
you might also need to install the desired platform.

For example if using wpf you must also install the wpf package.

------------------------------------
> Install-Package LiveCharts.Wpf
------------------------------------

For future updates, you will only need to update LiveCharts.Wpf (or any other platform)
forget about the core, all the platforms packages will have a dependency to core.

------------------------------------
> Update-Package LiveCharts.Wpf
------------------------------------

Happy coding!