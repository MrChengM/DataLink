﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HZH_Controls.Controls
{
    public class RadarPosition
    {
        public string Text { get; set; }
        public double MaxValue { get; set; }
        public double MinValue { get; set; }
    }
}
