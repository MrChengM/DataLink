﻿namespace Test.UC
{
    partial class UCTestColors
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.ucControlBase16 = new HZH_Controls.Controls.UCControlBase();
            this.ucControlBase31 = new HZH_Controls.Controls.UCControlBase();
            this.ucControlBase11 = new HZH_Controls.Controls.UCControlBase();
            this.ucControlBase6 = new HZH_Controls.Controls.UCControlBase();
            this.ucControlBase32 = new HZH_Controls.Controls.UCControlBase();
            this.ucControlBase33 = new HZH_Controls.Controls.UCControlBase();
            this.ucControlBase34 = new HZH_Controls.Controls.UCControlBase();
            this.ucControlBase35 = new HZH_Controls.Controls.UCControlBase();
            this.ucControlBase27 = new HZH_Controls.Controls.UCControlBase();
            this.ucControlBase28 = new HZH_Controls.Controls.UCControlBase();
            this.ucControlBase29 = new HZH_Controls.Controls.UCControlBase();
            this.ucControlBase30 = new HZH_Controls.Controls.UCControlBase();
            this.ucControlBase22 = new HZH_Controls.Controls.UCControlBase();
            this.ucControlBase23 = new HZH_Controls.Controls.UCControlBase();
            this.ucControlBase24 = new HZH_Controls.Controls.UCControlBase();
            this.ucControlBase25 = new HZH_Controls.Controls.UCControlBase();
            this.ucControlBase17 = new HZH_Controls.Controls.UCControlBase();
            this.ucControlBase19 = new HZH_Controls.Controls.UCControlBase();
            this.ucControlBase20 = new HZH_Controls.Controls.UCControlBase();
            this.ucControlBase12 = new HZH_Controls.Controls.UCControlBase();
            this.ucControlBase13 = new HZH_Controls.Controls.UCControlBase();
            this.ucControlBase14 = new HZH_Controls.Controls.UCControlBase();
            this.ucControlBase15 = new HZH_Controls.Controls.UCControlBase();
            this.ucControlBase7 = new HZH_Controls.Controls.UCControlBase();
            this.ucControlBase8 = new HZH_Controls.Controls.UCControlBase();
            this.ucControlBase9 = new HZH_Controls.Controls.UCControlBase();
            this.ucControlBase10 = new HZH_Controls.Controls.UCControlBase();
            this.ucControlBase5 = new HZH_Controls.Controls.UCControlBase();
            this.ucControlBase3 = new HZH_Controls.Controls.UCControlBase();
            this.ucControlBase4 = new HZH_Controls.Controls.UCControlBase();
            this.ucControlBase2 = new HZH_Controls.Controls.UCControlBase();
            this.ucControlBase1 = new HZH_Controls.Controls.UCControlBase();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.ucControlBase5);
            this.groupBox1.Controls.Add(this.ucControlBase3);
            this.groupBox1.Controls.Add(this.ucControlBase4);
            this.groupBox1.Controls.Add(this.ucControlBase2);
            this.groupBox1.Controls.Add(this.ucControlBase1);
            this.groupBox1.Location = new System.Drawing.Point(19, 19);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(891, 144);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Status Color";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.ucControlBase7);
            this.groupBox2.Controls.Add(this.ucControlBase8);
            this.groupBox2.Controls.Add(this.ucControlBase9);
            this.groupBox2.Controls.Add(this.ucControlBase10);
            this.groupBox2.Location = new System.Drawing.Point(19, 169);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(891, 144);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Text Color";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.ucControlBase12);
            this.groupBox3.Controls.Add(this.ucControlBase13);
            this.groupBox3.Controls.Add(this.ucControlBase14);
            this.groupBox3.Controls.Add(this.ucControlBase15);
            this.groupBox3.Location = new System.Drawing.Point(19, 319);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(891, 144);
            this.groupBox3.TabIndex = 0;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Line Color";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.ucControlBase17);
            this.groupBox4.Controls.Add(this.ucControlBase19);
            this.groupBox4.Controls.Add(this.ucControlBase20);
            this.groupBox4.Location = new System.Drawing.Point(19, 469);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(891, 144);
            this.groupBox4.TabIndex = 0;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Basis Color";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.ucControlBase22);
            this.groupBox5.Controls.Add(this.ucControlBase23);
            this.groupBox5.Controls.Add(this.ucControlBase24);
            this.groupBox5.Controls.Add(this.ucControlBase25);
            this.groupBox5.Location = new System.Drawing.Point(19, 619);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(891, 144);
            this.groupBox5.TabIndex = 0;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Table Color";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.ucControlBase27);
            this.groupBox6.Controls.Add(this.ucControlBase28);
            this.groupBox6.Controls.Add(this.ucControlBase29);
            this.groupBox6.Controls.Add(this.ucControlBase30);
            this.groupBox6.Location = new System.Drawing.Point(19, 769);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(891, 144);
            this.groupBox6.TabIndex = 0;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Border Color";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.ucControlBase16);
            this.groupBox7.Controls.Add(this.ucControlBase31);
            this.groupBox7.Controls.Add(this.ucControlBase11);
            this.groupBox7.Controls.Add(this.ucControlBase6);
            this.groupBox7.Controls.Add(this.ucControlBase32);
            this.groupBox7.Controls.Add(this.ucControlBase33);
            this.groupBox7.Controls.Add(this.ucControlBase34);
            this.groupBox7.Controls.Add(this.ucControlBase35);
            this.groupBox7.Location = new System.Drawing.Point(19, 919);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(891, 144);
            this.groupBox7.TabIndex = 0;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Gradien Color";
            // 
            // ucControlBase16
            // 
            this.ucControlBase16.BackColor = System.Drawing.Color.White;
            this.ucControlBase16.ConerRadius = 10;
            this.ucControlBase16.FillColor = System.Drawing.Color.Transparent;
            this.ucControlBase16.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucControlBase16.IsRadius = true;
            this.ucControlBase16.IsShowRect = false;
            this.ucControlBase16.Location = new System.Drawing.Point(777, 30);
            this.ucControlBase16.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ucControlBase16.Name = "ucControlBase16";
            this.ucControlBase16.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            this.ucControlBase16.RectWidth = 1;
            this.ucControlBase16.Size = new System.Drawing.Size(100, 100);
            this.ucControlBase16.TabIndex = 0;
            // 
            // ucControlBase31
            // 
            this.ucControlBase31.BackColor = System.Drawing.Color.White;
            this.ucControlBase31.ConerRadius = 10;
            this.ucControlBase31.FillColor = System.Drawing.Color.Transparent;
            this.ucControlBase31.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucControlBase31.IsRadius = true;
            this.ucControlBase31.IsShowRect = false;
            this.ucControlBase31.Location = new System.Drawing.Point(453, 30);
            this.ucControlBase31.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ucControlBase31.Name = "ucControlBase31";
            this.ucControlBase31.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            this.ucControlBase31.RectWidth = 1;
            this.ucControlBase31.Size = new System.Drawing.Size(100, 100);
            this.ucControlBase31.TabIndex = 0;
            // 
            // ucControlBase11
            // 
            this.ucControlBase11.BackColor = System.Drawing.Color.White;
            this.ucControlBase11.ConerRadius = 10;
            this.ucControlBase11.FillColor = System.Drawing.Color.Transparent;
            this.ucControlBase11.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucControlBase11.IsRadius = true;
            this.ucControlBase11.IsShowRect = false;
            this.ucControlBase11.Location = new System.Drawing.Point(561, 30);
            this.ucControlBase11.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ucControlBase11.Name = "ucControlBase11";
            this.ucControlBase11.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            this.ucControlBase11.RectWidth = 1;
            this.ucControlBase11.Size = new System.Drawing.Size(100, 100);
            this.ucControlBase11.TabIndex = 0;
            // 
            // ucControlBase6
            // 
            this.ucControlBase6.BackColor = System.Drawing.Color.White;
            this.ucControlBase6.ConerRadius = 10;
            this.ucControlBase6.FillColor = System.Drawing.Color.Transparent;
            this.ucControlBase6.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucControlBase6.IsRadius = true;
            this.ucControlBase6.IsShowRect = false;
            this.ucControlBase6.Location = new System.Drawing.Point(669, 30);
            this.ucControlBase6.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ucControlBase6.Name = "ucControlBase6";
            this.ucControlBase6.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            this.ucControlBase6.RectWidth = 1;
            this.ucControlBase6.Size = new System.Drawing.Size(100, 100);
            this.ucControlBase6.TabIndex = 0;
            // 
            // ucControlBase32
            // 
            this.ucControlBase32.BackColor = System.Drawing.Color.White;
            this.ucControlBase32.ConerRadius = 10;
            this.ucControlBase32.FillColor = System.Drawing.Color.Transparent;
            this.ucControlBase32.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucControlBase32.IsRadius = true;
            this.ucControlBase32.IsShowRect = false;
            this.ucControlBase32.Location = new System.Drawing.Point(237, 30);
            this.ucControlBase32.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ucControlBase32.Name = "ucControlBase32";
            this.ucControlBase32.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            this.ucControlBase32.RectWidth = 1;
            this.ucControlBase32.Size = new System.Drawing.Size(100, 100);
            this.ucControlBase32.TabIndex = 0;
            // 
            // ucControlBase33
            // 
            this.ucControlBase33.BackColor = System.Drawing.Color.White;
            this.ucControlBase33.ConerRadius = 10;
            this.ucControlBase33.FillColor = System.Drawing.Color.Transparent;
            this.ucControlBase33.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucControlBase33.IsRadius = true;
            this.ucControlBase33.IsShowRect = false;
            this.ucControlBase33.Location = new System.Drawing.Point(345, 30);
            this.ucControlBase33.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ucControlBase33.Name = "ucControlBase33";
            this.ucControlBase33.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            this.ucControlBase33.RectWidth = 1;
            this.ucControlBase33.Size = new System.Drawing.Size(100, 100);
            this.ucControlBase33.TabIndex = 0;
            // 
            // ucControlBase34
            // 
            this.ucControlBase34.BackColor = System.Drawing.Color.White;
            this.ucControlBase34.ConerRadius = 10;
            this.ucControlBase34.FillColor = System.Drawing.Color.Transparent;
            this.ucControlBase34.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucControlBase34.IsRadius = true;
            this.ucControlBase34.IsShowRect = false;
            this.ucControlBase34.Location = new System.Drawing.Point(129, 30);
            this.ucControlBase34.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ucControlBase34.Name = "ucControlBase34";
            this.ucControlBase34.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            this.ucControlBase34.RectWidth = 1;
            this.ucControlBase34.Size = new System.Drawing.Size(100, 100);
            this.ucControlBase34.TabIndex = 0;
            // 
            // ucControlBase35
            // 
            this.ucControlBase35.BackColor = System.Drawing.Color.White;
            this.ucControlBase35.ConerRadius = 10;
            this.ucControlBase35.FillColor = System.Drawing.Color.Transparent;
            this.ucControlBase35.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucControlBase35.IsRadius = true;
            this.ucControlBase35.IsShowRect = false;
            this.ucControlBase35.Location = new System.Drawing.Point(21, 30);
            this.ucControlBase35.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ucControlBase35.Name = "ucControlBase35";
            this.ucControlBase35.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            this.ucControlBase35.RectWidth = 1;
            this.ucControlBase35.Size = new System.Drawing.Size(100, 100);
            this.ucControlBase35.TabIndex = 0;
            // 
            // ucControlBase27
            // 
            this.ucControlBase27.BackColor = System.Drawing.Color.White;
            this.ucControlBase27.ConerRadius = 10;
            this.ucControlBase27.FillColor = System.Drawing.Color.Transparent;
            this.ucControlBase27.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucControlBase27.IsRadius = true;
            this.ucControlBase27.IsShowRect = false;
            this.ucControlBase27.Location = new System.Drawing.Point(237, 30);
            this.ucControlBase27.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ucControlBase27.Name = "ucControlBase27";
            this.ucControlBase27.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            this.ucControlBase27.RectWidth = 1;
            this.ucControlBase27.Size = new System.Drawing.Size(100, 100);
            this.ucControlBase27.TabIndex = 0;
            // 
            // ucControlBase28
            // 
            this.ucControlBase28.BackColor = System.Drawing.Color.White;
            this.ucControlBase28.ConerRadius = 10;
            this.ucControlBase28.FillColor = System.Drawing.Color.Transparent;
            this.ucControlBase28.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucControlBase28.IsRadius = true;
            this.ucControlBase28.IsShowRect = false;
            this.ucControlBase28.Location = new System.Drawing.Point(345, 30);
            this.ucControlBase28.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ucControlBase28.Name = "ucControlBase28";
            this.ucControlBase28.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            this.ucControlBase28.RectWidth = 1;
            this.ucControlBase28.Size = new System.Drawing.Size(100, 100);
            this.ucControlBase28.TabIndex = 0;
            // 
            // ucControlBase29
            // 
            this.ucControlBase29.BackColor = System.Drawing.Color.White;
            this.ucControlBase29.ConerRadius = 10;
            this.ucControlBase29.FillColor = System.Drawing.Color.Transparent;
            this.ucControlBase29.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucControlBase29.IsRadius = true;
            this.ucControlBase29.IsShowRect = false;
            this.ucControlBase29.Location = new System.Drawing.Point(129, 30);
            this.ucControlBase29.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ucControlBase29.Name = "ucControlBase29";
            this.ucControlBase29.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            this.ucControlBase29.RectWidth = 1;
            this.ucControlBase29.Size = new System.Drawing.Size(100, 100);
            this.ucControlBase29.TabIndex = 0;
            // 
            // ucControlBase30
            // 
            this.ucControlBase30.BackColor = System.Drawing.Color.White;
            this.ucControlBase30.ConerRadius = 10;
            this.ucControlBase30.FillColor = System.Drawing.Color.Transparent;
            this.ucControlBase30.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucControlBase30.IsRadius = true;
            this.ucControlBase30.IsShowRect = false;
            this.ucControlBase30.Location = new System.Drawing.Point(21, 30);
            this.ucControlBase30.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ucControlBase30.Name = "ucControlBase30";
            this.ucControlBase30.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            this.ucControlBase30.RectWidth = 1;
            this.ucControlBase30.Size = new System.Drawing.Size(100, 100);
            this.ucControlBase30.TabIndex = 0;
            // 
            // ucControlBase22
            // 
            this.ucControlBase22.BackColor = System.Drawing.Color.White;
            this.ucControlBase22.ConerRadius = 10;
            this.ucControlBase22.FillColor = System.Drawing.Color.Transparent;
            this.ucControlBase22.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucControlBase22.IsRadius = true;
            this.ucControlBase22.IsShowRect = false;
            this.ucControlBase22.Location = new System.Drawing.Point(237, 30);
            this.ucControlBase22.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ucControlBase22.Name = "ucControlBase22";
            this.ucControlBase22.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            this.ucControlBase22.RectWidth = 1;
            this.ucControlBase22.Size = new System.Drawing.Size(100, 100);
            this.ucControlBase22.TabIndex = 0;
            // 
            // ucControlBase23
            // 
            this.ucControlBase23.BackColor = System.Drawing.Color.White;
            this.ucControlBase23.ConerRadius = 10;
            this.ucControlBase23.FillColor = System.Drawing.Color.Transparent;
            this.ucControlBase23.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucControlBase23.IsRadius = true;
            this.ucControlBase23.IsShowRect = false;
            this.ucControlBase23.Location = new System.Drawing.Point(345, 30);
            this.ucControlBase23.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ucControlBase23.Name = "ucControlBase23";
            this.ucControlBase23.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            this.ucControlBase23.RectWidth = 1;
            this.ucControlBase23.Size = new System.Drawing.Size(100, 100);
            this.ucControlBase23.TabIndex = 0;
            // 
            // ucControlBase24
            // 
            this.ucControlBase24.BackColor = System.Drawing.Color.White;
            this.ucControlBase24.ConerRadius = 10;
            this.ucControlBase24.FillColor = System.Drawing.Color.Transparent;
            this.ucControlBase24.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucControlBase24.IsRadius = true;
            this.ucControlBase24.IsShowRect = false;
            this.ucControlBase24.Location = new System.Drawing.Point(129, 30);
            this.ucControlBase24.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ucControlBase24.Name = "ucControlBase24";
            this.ucControlBase24.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            this.ucControlBase24.RectWidth = 1;
            this.ucControlBase24.Size = new System.Drawing.Size(100, 100);
            this.ucControlBase24.TabIndex = 0;
            // 
            // ucControlBase25
            // 
            this.ucControlBase25.BackColor = System.Drawing.Color.White;
            this.ucControlBase25.ConerRadius = 10;
            this.ucControlBase25.FillColor = System.Drawing.Color.Transparent;
            this.ucControlBase25.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucControlBase25.IsRadius = true;
            this.ucControlBase25.IsShowRect = false;
            this.ucControlBase25.Location = new System.Drawing.Point(21, 30);
            this.ucControlBase25.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ucControlBase25.Name = "ucControlBase25";
            this.ucControlBase25.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            this.ucControlBase25.RectWidth = 1;
            this.ucControlBase25.Size = new System.Drawing.Size(100, 100);
            this.ucControlBase25.TabIndex = 0;
            // 
            // ucControlBase17
            // 
            this.ucControlBase17.BackColor = System.Drawing.Color.White;
            this.ucControlBase17.ConerRadius = 10;
            this.ucControlBase17.FillColor = System.Drawing.Color.Transparent;
            this.ucControlBase17.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucControlBase17.IsRadius = true;
            this.ucControlBase17.IsShowRect = false;
            this.ucControlBase17.Location = new System.Drawing.Point(237, 30);
            this.ucControlBase17.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ucControlBase17.Name = "ucControlBase17";
            this.ucControlBase17.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            this.ucControlBase17.RectWidth = 1;
            this.ucControlBase17.Size = new System.Drawing.Size(100, 100);
            this.ucControlBase17.TabIndex = 0;
            // 
            // ucControlBase19
            // 
            this.ucControlBase19.BackColor = System.Drawing.Color.White;
            this.ucControlBase19.ConerRadius = 10;
            this.ucControlBase19.FillColor = System.Drawing.Color.Transparent;
            this.ucControlBase19.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucControlBase19.IsRadius = true;
            this.ucControlBase19.IsShowRect = false;
            this.ucControlBase19.Location = new System.Drawing.Point(129, 30);
            this.ucControlBase19.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ucControlBase19.Name = "ucControlBase19";
            this.ucControlBase19.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            this.ucControlBase19.RectWidth = 1;
            this.ucControlBase19.Size = new System.Drawing.Size(100, 100);
            this.ucControlBase19.TabIndex = 0;
            // 
            // ucControlBase20
            // 
            this.ucControlBase20.BackColor = System.Drawing.Color.White;
            this.ucControlBase20.ConerRadius = 10;
            this.ucControlBase20.FillColor = System.Drawing.Color.Transparent;
            this.ucControlBase20.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucControlBase20.IsRadius = true;
            this.ucControlBase20.IsShowRect = false;
            this.ucControlBase20.Location = new System.Drawing.Point(21, 30);
            this.ucControlBase20.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ucControlBase20.Name = "ucControlBase20";
            this.ucControlBase20.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            this.ucControlBase20.RectWidth = 1;
            this.ucControlBase20.Size = new System.Drawing.Size(100, 100);
            this.ucControlBase20.TabIndex = 0;
            // 
            // ucControlBase12
            // 
            this.ucControlBase12.BackColor = System.Drawing.Color.White;
            this.ucControlBase12.ConerRadius = 10;
            this.ucControlBase12.FillColor = System.Drawing.Color.Transparent;
            this.ucControlBase12.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucControlBase12.IsRadius = true;
            this.ucControlBase12.IsShowRect = false;
            this.ucControlBase12.Location = new System.Drawing.Point(237, 30);
            this.ucControlBase12.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ucControlBase12.Name = "ucControlBase12";
            this.ucControlBase12.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            this.ucControlBase12.RectWidth = 1;
            this.ucControlBase12.Size = new System.Drawing.Size(100, 100);
            this.ucControlBase12.TabIndex = 0;
            // 
            // ucControlBase13
            // 
            this.ucControlBase13.BackColor = System.Drawing.Color.White;
            this.ucControlBase13.ConerRadius = 10;
            this.ucControlBase13.FillColor = System.Drawing.Color.Transparent;
            this.ucControlBase13.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucControlBase13.IsRadius = true;
            this.ucControlBase13.IsShowRect = false;
            this.ucControlBase13.Location = new System.Drawing.Point(345, 30);
            this.ucControlBase13.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ucControlBase13.Name = "ucControlBase13";
            this.ucControlBase13.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            this.ucControlBase13.RectWidth = 1;
            this.ucControlBase13.Size = new System.Drawing.Size(100, 100);
            this.ucControlBase13.TabIndex = 0;
            // 
            // ucControlBase14
            // 
            this.ucControlBase14.BackColor = System.Drawing.Color.White;
            this.ucControlBase14.ConerRadius = 10;
            this.ucControlBase14.FillColor = System.Drawing.Color.Transparent;
            this.ucControlBase14.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucControlBase14.IsRadius = true;
            this.ucControlBase14.IsShowRect = false;
            this.ucControlBase14.Location = new System.Drawing.Point(129, 30);
            this.ucControlBase14.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ucControlBase14.Name = "ucControlBase14";
            this.ucControlBase14.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            this.ucControlBase14.RectWidth = 1;
            this.ucControlBase14.Size = new System.Drawing.Size(100, 100);
            this.ucControlBase14.TabIndex = 0;
            // 
            // ucControlBase15
            // 
            this.ucControlBase15.BackColor = System.Drawing.Color.White;
            this.ucControlBase15.ConerRadius = 10;
            this.ucControlBase15.FillColor = System.Drawing.Color.Transparent;
            this.ucControlBase15.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucControlBase15.IsRadius = true;
            this.ucControlBase15.IsShowRect = false;
            this.ucControlBase15.Location = new System.Drawing.Point(21, 30);
            this.ucControlBase15.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ucControlBase15.Name = "ucControlBase15";
            this.ucControlBase15.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            this.ucControlBase15.RectWidth = 1;
            this.ucControlBase15.Size = new System.Drawing.Size(100, 100);
            this.ucControlBase15.TabIndex = 0;
            // 
            // ucControlBase7
            // 
            this.ucControlBase7.BackColor = System.Drawing.Color.White;
            this.ucControlBase7.ConerRadius = 10;
            this.ucControlBase7.FillColor = System.Drawing.Color.Transparent;
            this.ucControlBase7.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucControlBase7.IsRadius = true;
            this.ucControlBase7.IsShowRect = false;
            this.ucControlBase7.Location = new System.Drawing.Point(237, 30);
            this.ucControlBase7.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ucControlBase7.Name = "ucControlBase7";
            this.ucControlBase7.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            this.ucControlBase7.RectWidth = 1;
            this.ucControlBase7.Size = new System.Drawing.Size(100, 100);
            this.ucControlBase7.TabIndex = 0;
            // 
            // ucControlBase8
            // 
            this.ucControlBase8.BackColor = System.Drawing.Color.White;
            this.ucControlBase8.ConerRadius = 10;
            this.ucControlBase8.FillColor = System.Drawing.Color.Transparent;
            this.ucControlBase8.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucControlBase8.IsRadius = true;
            this.ucControlBase8.IsShowRect = false;
            this.ucControlBase8.Location = new System.Drawing.Point(345, 30);
            this.ucControlBase8.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ucControlBase8.Name = "ucControlBase8";
            this.ucControlBase8.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            this.ucControlBase8.RectWidth = 1;
            this.ucControlBase8.Size = new System.Drawing.Size(100, 100);
            this.ucControlBase8.TabIndex = 0;
            // 
            // ucControlBase9
            // 
            this.ucControlBase9.BackColor = System.Drawing.Color.White;
            this.ucControlBase9.ConerRadius = 10;
            this.ucControlBase9.FillColor = System.Drawing.Color.Transparent;
            this.ucControlBase9.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucControlBase9.IsRadius = true;
            this.ucControlBase9.IsShowRect = false;
            this.ucControlBase9.Location = new System.Drawing.Point(129, 30);
            this.ucControlBase9.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ucControlBase9.Name = "ucControlBase9";
            this.ucControlBase9.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            this.ucControlBase9.RectWidth = 1;
            this.ucControlBase9.Size = new System.Drawing.Size(100, 100);
            this.ucControlBase9.TabIndex = 0;
            // 
            // ucControlBase10
            // 
            this.ucControlBase10.BackColor = System.Drawing.Color.White;
            this.ucControlBase10.ConerRadius = 10;
            this.ucControlBase10.FillColor = System.Drawing.Color.Transparent;
            this.ucControlBase10.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucControlBase10.IsRadius = true;
            this.ucControlBase10.IsShowRect = false;
            this.ucControlBase10.Location = new System.Drawing.Point(21, 30);
            this.ucControlBase10.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ucControlBase10.Name = "ucControlBase10";
            this.ucControlBase10.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            this.ucControlBase10.RectWidth = 1;
            this.ucControlBase10.Size = new System.Drawing.Size(100, 100);
            this.ucControlBase10.TabIndex = 0;
            // 
            // ucControlBase5
            // 
            this.ucControlBase5.BackColor = System.Drawing.Color.White;
            this.ucControlBase5.ConerRadius = 10;
            this.ucControlBase5.FillColor = System.Drawing.Color.Transparent;
            this.ucControlBase5.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucControlBase5.IsRadius = true;
            this.ucControlBase5.IsShowRect = false;
            this.ucControlBase5.Location = new System.Drawing.Point(453, 30);
            this.ucControlBase5.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ucControlBase5.Name = "ucControlBase5";
            this.ucControlBase5.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            this.ucControlBase5.RectWidth = 1;
            this.ucControlBase5.Size = new System.Drawing.Size(100, 100);
            this.ucControlBase5.TabIndex = 0;
            // 
            // ucControlBase3
            // 
            this.ucControlBase3.BackColor = System.Drawing.Color.White;
            this.ucControlBase3.ConerRadius = 10;
            this.ucControlBase3.FillColor = System.Drawing.Color.Transparent;
            this.ucControlBase3.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucControlBase3.IsRadius = true;
            this.ucControlBase3.IsShowRect = false;
            this.ucControlBase3.Location = new System.Drawing.Point(237, 30);
            this.ucControlBase3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ucControlBase3.Name = "ucControlBase3";
            this.ucControlBase3.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            this.ucControlBase3.RectWidth = 1;
            this.ucControlBase3.Size = new System.Drawing.Size(100, 100);
            this.ucControlBase3.TabIndex = 0;
            // 
            // ucControlBase4
            // 
            this.ucControlBase4.BackColor = System.Drawing.Color.White;
            this.ucControlBase4.ConerRadius = 10;
            this.ucControlBase4.FillColor = System.Drawing.Color.Transparent;
            this.ucControlBase4.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucControlBase4.IsRadius = true;
            this.ucControlBase4.IsShowRect = false;
            this.ucControlBase4.Location = new System.Drawing.Point(345, 30);
            this.ucControlBase4.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ucControlBase4.Name = "ucControlBase4";
            this.ucControlBase4.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            this.ucControlBase4.RectWidth = 1;
            this.ucControlBase4.Size = new System.Drawing.Size(100, 100);
            this.ucControlBase4.TabIndex = 0;
            // 
            // ucControlBase2
            // 
            this.ucControlBase2.BackColor = System.Drawing.Color.White;
            this.ucControlBase2.ConerRadius = 10;
            this.ucControlBase2.FillColor = System.Drawing.Color.Transparent;
            this.ucControlBase2.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucControlBase2.IsRadius = true;
            this.ucControlBase2.IsShowRect = false;
            this.ucControlBase2.Location = new System.Drawing.Point(129, 30);
            this.ucControlBase2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ucControlBase2.Name = "ucControlBase2";
            this.ucControlBase2.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            this.ucControlBase2.RectWidth = 1;
            this.ucControlBase2.Size = new System.Drawing.Size(100, 100);
            this.ucControlBase2.TabIndex = 0;
            // 
            // ucControlBase1
            // 
            this.ucControlBase1.BackColor = System.Drawing.Color.White;
            this.ucControlBase1.ConerRadius = 10;
            this.ucControlBase1.FillColor = System.Drawing.Color.Transparent;
            this.ucControlBase1.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucControlBase1.IsRadius = true;
            this.ucControlBase1.IsShowRect = false;
            this.ucControlBase1.Location = new System.Drawing.Point(21, 30);
            this.ucControlBase1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ucControlBase1.Name = "ucControlBase1";
            this.ucControlBase1.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            this.ucControlBase1.RectWidth = 1;
            this.ucControlBase1.Size = new System.Drawing.Size(100, 100);
            this.ucControlBase1.TabIndex = 0;
            // 
            // UCTestColors
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.groupBox7);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "UCTestColors";
            this.Size = new System.Drawing.Size(1145, 1079);
            this.Load += new System.EventHandler(this.UCTestColors_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private HZH_Controls.Controls.UCControlBase ucControlBase1;
        private HZH_Controls.Controls.UCControlBase ucControlBase5;
        private HZH_Controls.Controls.UCControlBase ucControlBase3;
        private HZH_Controls.Controls.UCControlBase ucControlBase4;
        private HZH_Controls.Controls.UCControlBase ucControlBase2;
        private System.Windows.Forms.GroupBox groupBox2;
        private HZH_Controls.Controls.UCControlBase ucControlBase7;
        private HZH_Controls.Controls.UCControlBase ucControlBase8;
        private HZH_Controls.Controls.UCControlBase ucControlBase9;
        private HZH_Controls.Controls.UCControlBase ucControlBase10;
        private System.Windows.Forms.GroupBox groupBox3;
        private HZH_Controls.Controls.UCControlBase ucControlBase12;
        private HZH_Controls.Controls.UCControlBase ucControlBase13;
        private HZH_Controls.Controls.UCControlBase ucControlBase14;
        private HZH_Controls.Controls.UCControlBase ucControlBase15;
        private System.Windows.Forms.GroupBox groupBox4;
        private HZH_Controls.Controls.UCControlBase ucControlBase17;
        private HZH_Controls.Controls.UCControlBase ucControlBase19;
        private HZH_Controls.Controls.UCControlBase ucControlBase20;
        private System.Windows.Forms.GroupBox groupBox5;
        private HZH_Controls.Controls.UCControlBase ucControlBase22;
        private HZH_Controls.Controls.UCControlBase ucControlBase23;
        private HZH_Controls.Controls.UCControlBase ucControlBase24;
        private HZH_Controls.Controls.UCControlBase ucControlBase25;
        private System.Windows.Forms.GroupBox groupBox6;
        private HZH_Controls.Controls.UCControlBase ucControlBase27;
        private HZH_Controls.Controls.UCControlBase ucControlBase28;
        private HZH_Controls.Controls.UCControlBase ucControlBase29;
        private HZH_Controls.Controls.UCControlBase ucControlBase30;
        private System.Windows.Forms.GroupBox groupBox7;
        private HZH_Controls.Controls.UCControlBase ucControlBase31;
        private HZH_Controls.Controls.UCControlBase ucControlBase32;
        private HZH_Controls.Controls.UCControlBase ucControlBase33;
        private HZH_Controls.Controls.UCControlBase ucControlBase34;
        private HZH_Controls.Controls.UCControlBase ucControlBase35;
        private HZH_Controls.Controls.UCControlBase ucControlBase16;
        private HZH_Controls.Controls.UCControlBase ucControlBase11;
        private HZH_Controls.Controls.UCControlBase ucControlBase6;
    }
}
