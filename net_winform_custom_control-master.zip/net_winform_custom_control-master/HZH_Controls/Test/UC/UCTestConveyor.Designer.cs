﻿namespace Test.UC
{
    partial class UCTestConveyor
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.ucConveyor36 = new HZH_Controls.Controls.UCConveyor();
            this.ucConveyor18 = new HZH_Controls.Controls.UCConveyor();
            this.ucConveyor35 = new HZH_Controls.Controls.UCConveyor();
            this.ucConveyor12 = new HZH_Controls.Controls.UCConveyor();
            this.ucConveyor34 = new HZH_Controls.Controls.UCConveyor();
            this.ucConveyor2 = new HZH_Controls.Controls.UCConveyor();
            this.ucConveyor33 = new HZH_Controls.Controls.UCConveyor();
            this.ucConveyor17 = new HZH_Controls.Controls.UCConveyor();
            this.ucConveyor32 = new HZH_Controls.Controls.UCConveyor();
            this.ucConveyor11 = new HZH_Controls.Controls.UCConveyor();
            this.ucConveyor31 = new HZH_Controls.Controls.UCConveyor();
            this.ucConveyor6 = new HZH_Controls.Controls.UCConveyor();
            this.ucConveyor30 = new HZH_Controls.Controls.UCConveyor();
            this.ucConveyor16 = new HZH_Controls.Controls.UCConveyor();
            this.ucConveyor29 = new HZH_Controls.Controls.UCConveyor();
            this.ucConveyor10 = new HZH_Controls.Controls.UCConveyor();
            this.ucConveyor28 = new HZH_Controls.Controls.UCConveyor();
            this.ucConveyor4 = new HZH_Controls.Controls.UCConveyor();
            this.ucConveyor27 = new HZH_Controls.Controls.UCConveyor();
            this.ucConveyor15 = new HZH_Controls.Controls.UCConveyor();
            this.ucConveyor26 = new HZH_Controls.Controls.UCConveyor();
            this.ucConveyor9 = new HZH_Controls.Controls.UCConveyor();
            this.ucConveyor25 = new HZH_Controls.Controls.UCConveyor();
            this.ucConveyor5 = new HZH_Controls.Controls.UCConveyor();
            this.ucConveyor24 = new HZH_Controls.Controls.UCConveyor();
            this.ucConveyor14 = new HZH_Controls.Controls.UCConveyor();
            this.ucConveyor23 = new HZH_Controls.Controls.UCConveyor();
            this.ucConveyor13 = new HZH_Controls.Controls.UCConveyor();
            this.ucConveyor22 = new HZH_Controls.Controls.UCConveyor();
            this.ucConveyor21 = new HZH_Controls.Controls.UCConveyor();
            this.ucConveyor8 = new HZH_Controls.Controls.UCConveyor();
            this.ucConveyor20 = new HZH_Controls.Controls.UCConveyor();
            this.ucConveyor7 = new HZH_Controls.Controls.UCConveyor();
            this.ucConveyor19 = new HZH_Controls.Controls.UCConveyor();
            this.ucConveyor3 = new HZH_Controls.Controls.UCConveyor();
            this.ucConveyor1 = new HZH_Controls.Controls.UCConveyor();
            this.SuspendLayout();
            // 
            // ucConveyor36
            // 
            this.ucConveyor36.BackColor = System.Drawing.Color.Transparent;
            this.ucConveyor36.ConveyorColor = System.Drawing.Color.DimGray;
            this.ucConveyor36.ConveyorDirection = HZH_Controls.Controls.ConveyorDirection.None;
            this.ucConveyor36.ConveyorHeight = 30;
            this.ucConveyor36.ConveyorSpeed = 100;
            this.ucConveyor36.Inclination = 30D;
            this.ucConveyor36.Location = new System.Drawing.Point(702, 497);
            this.ucConveyor36.Name = "ucConveyor36";
            this.ucConveyor36.Size = new System.Drawing.Size(183, 112);
            this.ucConveyor36.TabIndex = 22;
            // 
            // ucConveyor18
            // 
            this.ucConveyor18.BackColor = System.Drawing.Color.Transparent;
            this.ucConveyor18.ConveyorColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucConveyor18.ConveyorDirection = HZH_Controls.Controls.ConveyorDirection.None;
            this.ucConveyor18.ConveyorHeight = 30;
            this.ucConveyor18.ConveyorSpeed = 100;
            this.ucConveyor18.Inclination = 30D;
            this.ucConveyor18.Location = new System.Drawing.Point(102, 503);
            this.ucConveyor18.Name = "ucConveyor18";
            this.ucConveyor18.Size = new System.Drawing.Size(183, 112);
            this.ucConveyor18.TabIndex = 22;
            // 
            // ucConveyor35
            // 
            this.ucConveyor35.BackColor = System.Drawing.Color.Transparent;
            this.ucConveyor35.ConveyorColor = System.Drawing.Color.DimGray;
            this.ucConveyor35.ConveyorDirection = HZH_Controls.Controls.ConveyorDirection.Forward;
            this.ucConveyor35.ConveyorHeight = 30;
            this.ucConveyor35.ConveyorSpeed = 100;
            this.ucConveyor35.Inclination = 30D;
            this.ucConveyor35.Location = new System.Drawing.Point(702, 281);
            this.ucConveyor35.Name = "ucConveyor35";
            this.ucConveyor35.Size = new System.Drawing.Size(183, 112);
            this.ucConveyor35.TabIndex = 22;
            // 
            // ucConveyor12
            // 
            this.ucConveyor12.BackColor = System.Drawing.Color.Transparent;
            this.ucConveyor12.ConveyorColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucConveyor12.ConveyorDirection = HZH_Controls.Controls.ConveyorDirection.Forward;
            this.ucConveyor12.ConveyorHeight = 30;
            this.ucConveyor12.ConveyorSpeed = 100;
            this.ucConveyor12.Inclination = 30D;
            this.ucConveyor12.Location = new System.Drawing.Point(102, 287);
            this.ucConveyor12.Name = "ucConveyor12";
            this.ucConveyor12.Size = new System.Drawing.Size(183, 112);
            this.ucConveyor12.TabIndex = 22;
            // 
            // ucConveyor34
            // 
            this.ucConveyor34.BackColor = System.Drawing.Color.Transparent;
            this.ucConveyor34.ConveyorColor = System.Drawing.Color.DimGray;
            this.ucConveyor34.ConveyorDirection = HZH_Controls.Controls.ConveyorDirection.Backward;
            this.ucConveyor34.ConveyorHeight = 30;
            this.ucConveyor34.ConveyorSpeed = 100;
            this.ucConveyor34.Inclination = 30D;
            this.ucConveyor34.Location = new System.Drawing.Point(702, 67);
            this.ucConveyor34.Name = "ucConveyor34";
            this.ucConveyor34.Size = new System.Drawing.Size(183, 112);
            this.ucConveyor34.TabIndex = 22;
            // 
            // ucConveyor2
            // 
            this.ucConveyor2.BackColor = System.Drawing.Color.Transparent;
            this.ucConveyor2.ConveyorColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucConveyor2.ConveyorDirection = HZH_Controls.Controls.ConveyorDirection.Backward;
            this.ucConveyor2.ConveyorHeight = 30;
            this.ucConveyor2.ConveyorSpeed = 100;
            this.ucConveyor2.Inclination = 30D;
            this.ucConveyor2.Location = new System.Drawing.Point(102, 73);
            this.ucConveyor2.Name = "ucConveyor2";
            this.ucConveyor2.Size = new System.Drawing.Size(183, 112);
            this.ucConveyor2.TabIndex = 22;
            // 
            // ucConveyor33
            // 
            this.ucConveyor33.BackColor = System.Drawing.Color.Transparent;
            this.ucConveyor33.ConveyorColor = System.Drawing.Color.DimGray;
            this.ucConveyor33.ConveyorDirection = HZH_Controls.Controls.ConveyorDirection.None;
            this.ucConveyor33.ConveyorHeight = 30;
            this.ucConveyor33.ConveyorSpeed = 100;
            this.ucConveyor33.Inclination = 90D;
            this.ucConveyor33.Location = new System.Drawing.Point(1146, 443);
            this.ucConveyor33.Name = "ucConveyor33";
            this.ucConveyor33.Size = new System.Drawing.Size(72, 173);
            this.ucConveyor33.TabIndex = 23;
            // 
            // ucConveyor17
            // 
            this.ucConveyor17.BackColor = System.Drawing.Color.Transparent;
            this.ucConveyor17.ConveyorColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucConveyor17.ConveyorDirection = HZH_Controls.Controls.ConveyorDirection.None;
            this.ucConveyor17.ConveyorHeight = 30;
            this.ucConveyor17.ConveyorSpeed = 100;
            this.ucConveyor17.Inclination = 90D;
            this.ucConveyor17.Location = new System.Drawing.Point(546, 443);
            this.ucConveyor17.Name = "ucConveyor17";
            this.ucConveyor17.Size = new System.Drawing.Size(72, 173);
            this.ucConveyor17.TabIndex = 23;
            // 
            // ucConveyor32
            // 
            this.ucConveyor32.BackColor = System.Drawing.Color.Transparent;
            this.ucConveyor32.ConveyorColor = System.Drawing.Color.DimGray;
            this.ucConveyor32.ConveyorDirection = HZH_Controls.Controls.ConveyorDirection.Forward;
            this.ucConveyor32.ConveyorHeight = 30;
            this.ucConveyor32.ConveyorSpeed = 100;
            this.ucConveyor32.Inclination = 90D;
            this.ucConveyor32.Location = new System.Drawing.Point(1146, 227);
            this.ucConveyor32.Name = "ucConveyor32";
            this.ucConveyor32.Size = new System.Drawing.Size(72, 173);
            this.ucConveyor32.TabIndex = 23;
            // 
            // ucConveyor11
            // 
            this.ucConveyor11.BackColor = System.Drawing.Color.Transparent;
            this.ucConveyor11.ConveyorColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucConveyor11.ConveyorDirection = HZH_Controls.Controls.ConveyorDirection.Forward;
            this.ucConveyor11.ConveyorHeight = 30;
            this.ucConveyor11.ConveyorSpeed = 100;
            this.ucConveyor11.Inclination = 90D;
            this.ucConveyor11.Location = new System.Drawing.Point(546, 227);
            this.ucConveyor11.Name = "ucConveyor11";
            this.ucConveyor11.Size = new System.Drawing.Size(72, 173);
            this.ucConveyor11.TabIndex = 23;
            // 
            // ucConveyor31
            // 
            this.ucConveyor31.BackColor = System.Drawing.Color.Transparent;
            this.ucConveyor31.ConveyorColor = System.Drawing.Color.DimGray;
            this.ucConveyor31.ConveyorDirection = HZH_Controls.Controls.ConveyorDirection.Backward;
            this.ucConveyor31.ConveyorHeight = 30;
            this.ucConveyor31.ConveyorSpeed = 100;
            this.ucConveyor31.Inclination = 90D;
            this.ucConveyor31.Location = new System.Drawing.Point(1146, 13);
            this.ucConveyor31.Name = "ucConveyor31";
            this.ucConveyor31.Size = new System.Drawing.Size(72, 173);
            this.ucConveyor31.TabIndex = 23;
            // 
            // ucConveyor6
            // 
            this.ucConveyor6.BackColor = System.Drawing.Color.Transparent;
            this.ucConveyor6.ConveyorColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucConveyor6.ConveyorDirection = HZH_Controls.Controls.ConveyorDirection.Backward;
            this.ucConveyor6.ConveyorHeight = 30;
            this.ucConveyor6.ConveyorSpeed = 100;
            this.ucConveyor6.Inclination = 90D;
            this.ucConveyor6.Location = new System.Drawing.Point(546, 13);
            this.ucConveyor6.Name = "ucConveyor6";
            this.ucConveyor6.Size = new System.Drawing.Size(72, 173);
            this.ucConveyor6.TabIndex = 23;
            // 
            // ucConveyor30
            // 
            this.ucConveyor30.BackColor = System.Drawing.Color.Transparent;
            this.ucConveyor30.ConveyorColor = System.Drawing.Color.DimGray;
            this.ucConveyor30.ConveyorDirection = HZH_Controls.Controls.ConveyorDirection.None;
            this.ucConveyor30.ConveyorHeight = 30;
            this.ucConveyor30.ConveyorSpeed = 100;
            this.ucConveyor30.Inclination = 90D;
            this.ucConveyor30.Location = new System.Drawing.Point(627, 443);
            this.ucConveyor30.Name = "ucConveyor30";
            this.ucConveyor30.Size = new System.Drawing.Size(72, 165);
            this.ucConveyor30.TabIndex = 24;
            // 
            // ucConveyor16
            // 
            this.ucConveyor16.BackColor = System.Drawing.Color.Transparent;
            this.ucConveyor16.ConveyorColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucConveyor16.ConveyorDirection = HZH_Controls.Controls.ConveyorDirection.None;
            this.ucConveyor16.ConveyorHeight = 30;
            this.ucConveyor16.ConveyorSpeed = 100;
            this.ucConveyor16.Inclination = 90D;
            this.ucConveyor16.Location = new System.Drawing.Point(27, 443);
            this.ucConveyor16.Name = "ucConveyor16";
            this.ucConveyor16.Size = new System.Drawing.Size(72, 165);
            this.ucConveyor16.TabIndex = 24;
            // 
            // ucConveyor29
            // 
            this.ucConveyor29.BackColor = System.Drawing.Color.Transparent;
            this.ucConveyor29.ConveyorColor = System.Drawing.Color.DimGray;
            this.ucConveyor29.ConveyorDirection = HZH_Controls.Controls.ConveyorDirection.Forward;
            this.ucConveyor29.ConveyorHeight = 30;
            this.ucConveyor29.ConveyorSpeed = 100;
            this.ucConveyor29.Inclination = 90D;
            this.ucConveyor29.Location = new System.Drawing.Point(627, 227);
            this.ucConveyor29.Name = "ucConveyor29";
            this.ucConveyor29.Size = new System.Drawing.Size(72, 165);
            this.ucConveyor29.TabIndex = 24;
            // 
            // ucConveyor10
            // 
            this.ucConveyor10.BackColor = System.Drawing.Color.Transparent;
            this.ucConveyor10.ConveyorColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucConveyor10.ConveyorDirection = HZH_Controls.Controls.ConveyorDirection.Forward;
            this.ucConveyor10.ConveyorHeight = 30;
            this.ucConveyor10.ConveyorSpeed = 100;
            this.ucConveyor10.Inclination = 90D;
            this.ucConveyor10.Location = new System.Drawing.Point(27, 227);
            this.ucConveyor10.Name = "ucConveyor10";
            this.ucConveyor10.Size = new System.Drawing.Size(72, 165);
            this.ucConveyor10.TabIndex = 24;
            // 
            // ucConveyor28
            // 
            this.ucConveyor28.BackColor = System.Drawing.Color.Transparent;
            this.ucConveyor28.ConveyorColor = System.Drawing.Color.DimGray;
            this.ucConveyor28.ConveyorDirection = HZH_Controls.Controls.ConveyorDirection.Backward;
            this.ucConveyor28.ConveyorHeight = 30;
            this.ucConveyor28.ConveyorSpeed = 100;
            this.ucConveyor28.Inclination = 90D;
            this.ucConveyor28.Location = new System.Drawing.Point(627, 13);
            this.ucConveyor28.Name = "ucConveyor28";
            this.ucConveyor28.Size = new System.Drawing.Size(72, 165);
            this.ucConveyor28.TabIndex = 24;
            // 
            // ucConveyor4
            // 
            this.ucConveyor4.BackColor = System.Drawing.Color.Transparent;
            this.ucConveyor4.ConveyorColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucConveyor4.ConveyorDirection = HZH_Controls.Controls.ConveyorDirection.Backward;
            this.ucConveyor4.ConveyorHeight = 30;
            this.ucConveyor4.ConveyorSpeed = 100;
            this.ucConveyor4.Inclination = 90D;
            this.ucConveyor4.Location = new System.Drawing.Point(27, 13);
            this.ucConveyor4.Name = "ucConveyor4";
            this.ucConveyor4.Size = new System.Drawing.Size(72, 165);
            this.ucConveyor4.TabIndex = 24;
            // 
            // ucConveyor27
            // 
            this.ucConveyor27.BackColor = System.Drawing.Color.Transparent;
            this.ucConveyor27.ConveyorColor = System.Drawing.Color.DimGray;
            this.ucConveyor27.ConveyorDirection = HZH_Controls.Controls.ConveyorDirection.None;
            this.ucConveyor27.ConveyorHeight = 30;
            this.ucConveyor27.ConveyorSpeed = 100;
            this.ucConveyor27.Inclination = 0D;
            this.ucConveyor27.Location = new System.Drawing.Point(921, 443);
            this.ucConveyor27.Name = "ucConveyor27";
            this.ucConveyor27.Size = new System.Drawing.Size(213, 53);
            this.ucConveyor27.TabIndex = 25;
            // 
            // ucConveyor15
            // 
            this.ucConveyor15.BackColor = System.Drawing.Color.Transparent;
            this.ucConveyor15.ConveyorColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucConveyor15.ConveyorDirection = HZH_Controls.Controls.ConveyorDirection.None;
            this.ucConveyor15.ConveyorHeight = 30;
            this.ucConveyor15.ConveyorSpeed = 100;
            this.ucConveyor15.Inclination = 0D;
            this.ucConveyor15.Location = new System.Drawing.Point(321, 443);
            this.ucConveyor15.Name = "ucConveyor15";
            this.ucConveyor15.Size = new System.Drawing.Size(213, 53);
            this.ucConveyor15.TabIndex = 25;
            // 
            // ucConveyor26
            // 
            this.ucConveyor26.BackColor = System.Drawing.Color.Transparent;
            this.ucConveyor26.ConveyorColor = System.Drawing.Color.DimGray;
            this.ucConveyor26.ConveyorDirection = HZH_Controls.Controls.ConveyorDirection.Forward;
            this.ucConveyor26.ConveyorHeight = 30;
            this.ucConveyor26.ConveyorSpeed = 100;
            this.ucConveyor26.Inclination = 0D;
            this.ucConveyor26.Location = new System.Drawing.Point(921, 227);
            this.ucConveyor26.Name = "ucConveyor26";
            this.ucConveyor26.Size = new System.Drawing.Size(213, 53);
            this.ucConveyor26.TabIndex = 25;
            // 
            // ucConveyor9
            // 
            this.ucConveyor9.BackColor = System.Drawing.Color.Transparent;
            this.ucConveyor9.ConveyorColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucConveyor9.ConveyorDirection = HZH_Controls.Controls.ConveyorDirection.Forward;
            this.ucConveyor9.ConveyorHeight = 30;
            this.ucConveyor9.ConveyorSpeed = 100;
            this.ucConveyor9.Inclination = 0D;
            this.ucConveyor9.Location = new System.Drawing.Point(321, 227);
            this.ucConveyor9.Name = "ucConveyor9";
            this.ucConveyor9.Size = new System.Drawing.Size(213, 53);
            this.ucConveyor9.TabIndex = 25;
            // 
            // ucConveyor25
            // 
            this.ucConveyor25.BackColor = System.Drawing.Color.Transparent;
            this.ucConveyor25.ConveyorColor = System.Drawing.Color.DimGray;
            this.ucConveyor25.ConveyorDirection = HZH_Controls.Controls.ConveyorDirection.Backward;
            this.ucConveyor25.ConveyorHeight = 30;
            this.ucConveyor25.ConveyorSpeed = 100;
            this.ucConveyor25.Inclination = 0D;
            this.ucConveyor25.Location = new System.Drawing.Point(921, 13);
            this.ucConveyor25.Name = "ucConveyor25";
            this.ucConveyor25.Size = new System.Drawing.Size(213, 53);
            this.ucConveyor25.TabIndex = 25;
            // 
            // ucConveyor5
            // 
            this.ucConveyor5.BackColor = System.Drawing.Color.Transparent;
            this.ucConveyor5.ConveyorColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucConveyor5.ConveyorDirection = HZH_Controls.Controls.ConveyorDirection.Backward;
            this.ucConveyor5.ConveyorHeight = 30;
            this.ucConveyor5.ConveyorSpeed = 100;
            this.ucConveyor5.Inclination = 0D;
            this.ucConveyor5.Location = new System.Drawing.Point(321, 13);
            this.ucConveyor5.Name = "ucConveyor5";
            this.ucConveyor5.Size = new System.Drawing.Size(213, 53);
            this.ucConveyor5.TabIndex = 25;
            // 
            // ucConveyor24
            // 
            this.ucConveyor24.BackColor = System.Drawing.Color.Transparent;
            this.ucConveyor24.ConveyorColor = System.Drawing.Color.DimGray;
            this.ucConveyor24.ConveyorDirection = HZH_Controls.Controls.ConveyorDirection.None;
            this.ucConveyor24.ConveyorHeight = 30;
            this.ucConveyor24.ConveyorSpeed = 100;
            this.ucConveyor24.Inclination = 0D;
            this.ucConveyor24.Location = new System.Drawing.Point(702, 443);
            this.ucConveyor24.Name = "ucConveyor24";
            this.ucConveyor24.Size = new System.Drawing.Size(213, 53);
            this.ucConveyor24.TabIndex = 26;
            // 
            // ucConveyor14
            // 
            this.ucConveyor14.BackColor = System.Drawing.Color.Transparent;
            this.ucConveyor14.ConveyorColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucConveyor14.ConveyorDirection = HZH_Controls.Controls.ConveyorDirection.None;
            this.ucConveyor14.ConveyorHeight = 30;
            this.ucConveyor14.ConveyorSpeed = 100;
            this.ucConveyor14.Inclination = 0D;
            this.ucConveyor14.Location = new System.Drawing.Point(102, 443);
            this.ucConveyor14.Name = "ucConveyor14";
            this.ucConveyor14.Size = new System.Drawing.Size(213, 53);
            this.ucConveyor14.TabIndex = 26;
            // 
            // ucConveyor23
            // 
            this.ucConveyor23.BackColor = System.Drawing.Color.Transparent;
            this.ucConveyor23.ConveyorColor = System.Drawing.Color.DimGray;
            this.ucConveyor23.ConveyorDirection = HZH_Controls.Controls.ConveyorDirection.None;
            this.ucConveyor23.ConveyorHeight = 30;
            this.ucConveyor23.ConveyorSpeed = 100;
            this.ucConveyor23.Inclination = -30D;
            this.ucConveyor23.Location = new System.Drawing.Point(900, 496);
            this.ucConveyor23.Name = "ucConveyor23";
            this.ucConveyor23.Size = new System.Drawing.Size(183, 120);
            this.ucConveyor23.TabIndex = 27;
            // 
            // ucConveyor13
            // 
            this.ucConveyor13.BackColor = System.Drawing.Color.Transparent;
            this.ucConveyor13.ConveyorColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucConveyor13.ConveyorDirection = HZH_Controls.Controls.ConveyorDirection.None;
            this.ucConveyor13.ConveyorHeight = 30;
            this.ucConveyor13.ConveyorSpeed = 100;
            this.ucConveyor13.Inclination = -30D;
            this.ucConveyor13.Location = new System.Drawing.Point(300, 502);
            this.ucConveyor13.Name = "ucConveyor13";
            this.ucConveyor13.Size = new System.Drawing.Size(183, 120);
            this.ucConveyor13.TabIndex = 27;
            // 
            // ucConveyor22
            // 
            this.ucConveyor22.BackColor = System.Drawing.Color.Transparent;
            this.ucConveyor22.ConveyorColor = System.Drawing.Color.DimGray;
            this.ucConveyor22.ConveyorDirection = HZH_Controls.Controls.ConveyorDirection.Forward;
            this.ucConveyor22.ConveyorHeight = 30;
            this.ucConveyor22.ConveyorSpeed = 100;
            this.ucConveyor22.Inclination = 0D;
            this.ucConveyor22.Location = new System.Drawing.Point(702, 227);
            this.ucConveyor22.Name = "ucConveyor22";
            this.ucConveyor22.Size = new System.Drawing.Size(213, 53);
            this.ucConveyor22.TabIndex = 26;
            // 
            // ucConveyor21
            // 
            this.ucConveyor21.BackColor = System.Drawing.Color.Transparent;
            this.ucConveyor21.ConveyorColor = System.Drawing.Color.DimGray;
            this.ucConveyor21.ConveyorDirection = HZH_Controls.Controls.ConveyorDirection.Forward;
            this.ucConveyor21.ConveyorHeight = 30;
            this.ucConveyor21.ConveyorSpeed = 100;
            this.ucConveyor21.Inclination = -30D;
            this.ucConveyor21.Location = new System.Drawing.Point(900, 280);
            this.ucConveyor21.Name = "ucConveyor21";
            this.ucConveyor21.Size = new System.Drawing.Size(183, 120);
            this.ucConveyor21.TabIndex = 27;
            // 
            // ucConveyor8
            // 
            this.ucConveyor8.BackColor = System.Drawing.Color.Transparent;
            this.ucConveyor8.ConveyorColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucConveyor8.ConveyorDirection = HZH_Controls.Controls.ConveyorDirection.Forward;
            this.ucConveyor8.ConveyorHeight = 30;
            this.ucConveyor8.ConveyorSpeed = 100;
            this.ucConveyor8.Inclination = 0D;
            this.ucConveyor8.Location = new System.Drawing.Point(102, 227);
            this.ucConveyor8.Name = "ucConveyor8";
            this.ucConveyor8.Size = new System.Drawing.Size(213, 53);
            this.ucConveyor8.TabIndex = 26;
            // 
            // ucConveyor20
            // 
            this.ucConveyor20.BackColor = System.Drawing.Color.Transparent;
            this.ucConveyor20.ConveyorColor = System.Drawing.Color.DimGray;
            this.ucConveyor20.ConveyorDirection = HZH_Controls.Controls.ConveyorDirection.Backward;
            this.ucConveyor20.ConveyorHeight = 30;
            this.ucConveyor20.ConveyorSpeed = 100;
            this.ucConveyor20.Inclination = 0D;
            this.ucConveyor20.Location = new System.Drawing.Point(702, 13);
            this.ucConveyor20.Name = "ucConveyor20";
            this.ucConveyor20.Size = new System.Drawing.Size(213, 53);
            this.ucConveyor20.TabIndex = 26;
            // 
            // ucConveyor7
            // 
            this.ucConveyor7.BackColor = System.Drawing.Color.Transparent;
            this.ucConveyor7.ConveyorColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucConveyor7.ConveyorDirection = HZH_Controls.Controls.ConveyorDirection.Forward;
            this.ucConveyor7.ConveyorHeight = 30;
            this.ucConveyor7.ConveyorSpeed = 100;
            this.ucConveyor7.Inclination = -30D;
            this.ucConveyor7.Location = new System.Drawing.Point(300, 286);
            this.ucConveyor7.Name = "ucConveyor7";
            this.ucConveyor7.Size = new System.Drawing.Size(183, 120);
            this.ucConveyor7.TabIndex = 27;
            // 
            // ucConveyor19
            // 
            this.ucConveyor19.BackColor = System.Drawing.Color.Transparent;
            this.ucConveyor19.ConveyorColor = System.Drawing.Color.DimGray;
            this.ucConveyor19.ConveyorDirection = HZH_Controls.Controls.ConveyorDirection.Backward;
            this.ucConveyor19.ConveyorHeight = 30;
            this.ucConveyor19.ConveyorSpeed = 100;
            this.ucConveyor19.Inclination = -30D;
            this.ucConveyor19.Location = new System.Drawing.Point(900, 66);
            this.ucConveyor19.Name = "ucConveyor19";
            this.ucConveyor19.Size = new System.Drawing.Size(183, 120);
            this.ucConveyor19.TabIndex = 27;
            // 
            // ucConveyor3
            // 
            this.ucConveyor3.BackColor = System.Drawing.Color.Transparent;
            this.ucConveyor3.ConveyorColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucConveyor3.ConveyorDirection = HZH_Controls.Controls.ConveyorDirection.Backward;
            this.ucConveyor3.ConveyorHeight = 30;
            this.ucConveyor3.ConveyorSpeed = 100;
            this.ucConveyor3.Inclination = 0D;
            this.ucConveyor3.Location = new System.Drawing.Point(102, 13);
            this.ucConveyor3.Name = "ucConveyor3";
            this.ucConveyor3.Size = new System.Drawing.Size(213, 53);
            this.ucConveyor3.TabIndex = 26;
            // 
            // ucConveyor1
            // 
            this.ucConveyor1.BackColor = System.Drawing.Color.Transparent;
            this.ucConveyor1.ConveyorColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucConveyor1.ConveyorDirection = HZH_Controls.Controls.ConveyorDirection.Backward;
            this.ucConveyor1.ConveyorHeight = 30;
            this.ucConveyor1.ConveyorSpeed = 100;
            this.ucConveyor1.Inclination = -30D;
            this.ucConveyor1.Location = new System.Drawing.Point(300, 72);
            this.ucConveyor1.Name = "ucConveyor1";
            this.ucConveyor1.Size = new System.Drawing.Size(183, 120);
            this.ucConveyor1.TabIndex = 27;
            // 
            // UCTestConveyor
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.ucConveyor36);
            this.Controls.Add(this.ucConveyor18);
            this.Controls.Add(this.ucConveyor35);
            this.Controls.Add(this.ucConveyor12);
            this.Controls.Add(this.ucConveyor34);
            this.Controls.Add(this.ucConveyor2);
            this.Controls.Add(this.ucConveyor33);
            this.Controls.Add(this.ucConveyor17);
            this.Controls.Add(this.ucConveyor32);
            this.Controls.Add(this.ucConveyor11);
            this.Controls.Add(this.ucConveyor31);
            this.Controls.Add(this.ucConveyor6);
            this.Controls.Add(this.ucConveyor30);
            this.Controls.Add(this.ucConveyor16);
            this.Controls.Add(this.ucConveyor29);
            this.Controls.Add(this.ucConveyor10);
            this.Controls.Add(this.ucConveyor28);
            this.Controls.Add(this.ucConveyor4);
            this.Controls.Add(this.ucConveyor27);
            this.Controls.Add(this.ucConveyor15);
            this.Controls.Add(this.ucConveyor26);
            this.Controls.Add(this.ucConveyor9);
            this.Controls.Add(this.ucConveyor25);
            this.Controls.Add(this.ucConveyor5);
            this.Controls.Add(this.ucConveyor24);
            this.Controls.Add(this.ucConveyor14);
            this.Controls.Add(this.ucConveyor23);
            this.Controls.Add(this.ucConveyor13);
            this.Controls.Add(this.ucConveyor22);
            this.Controls.Add(this.ucConveyor21);
            this.Controls.Add(this.ucConveyor8);
            this.Controls.Add(this.ucConveyor20);
            this.Controls.Add(this.ucConveyor7);
            this.Controls.Add(this.ucConveyor19);
            this.Controls.Add(this.ucConveyor3);
            this.Controls.Add(this.ucConveyor1);
            this.Name = "UCTestConveyor";
            this.Size = new System.Drawing.Size(1228, 654);
            this.ResumeLayout(false);

        }

        #endregion

        private HZH_Controls.Controls.UCConveyor ucConveyor2;
        private HZH_Controls.Controls.UCConveyor ucConveyor6;
        private HZH_Controls.Controls.UCConveyor ucConveyor4;
        private HZH_Controls.Controls.UCConveyor ucConveyor5;
        private HZH_Controls.Controls.UCConveyor ucConveyor3;
        private HZH_Controls.Controls.UCConveyor ucConveyor1;
        private HZH_Controls.Controls.UCConveyor ucConveyor7;
        private HZH_Controls.Controls.UCConveyor ucConveyor8;
        private HZH_Controls.Controls.UCConveyor ucConveyor9;
        private HZH_Controls.Controls.UCConveyor ucConveyor10;
        private HZH_Controls.Controls.UCConveyor ucConveyor11;
        private HZH_Controls.Controls.UCConveyor ucConveyor12;
        private HZH_Controls.Controls.UCConveyor ucConveyor13;
        private HZH_Controls.Controls.UCConveyor ucConveyor14;
        private HZH_Controls.Controls.UCConveyor ucConveyor15;
        private HZH_Controls.Controls.UCConveyor ucConveyor16;
        private HZH_Controls.Controls.UCConveyor ucConveyor17;
        private HZH_Controls.Controls.UCConveyor ucConveyor18;
        private HZH_Controls.Controls.UCConveyor ucConveyor19;
        private HZH_Controls.Controls.UCConveyor ucConveyor20;
        private HZH_Controls.Controls.UCConveyor ucConveyor21;
        private HZH_Controls.Controls.UCConveyor ucConveyor22;
        private HZH_Controls.Controls.UCConveyor ucConveyor23;
        private HZH_Controls.Controls.UCConveyor ucConveyor24;
        private HZH_Controls.Controls.UCConveyor ucConveyor25;
        private HZH_Controls.Controls.UCConveyor ucConveyor26;
        private HZH_Controls.Controls.UCConveyor ucConveyor27;
        private HZH_Controls.Controls.UCConveyor ucConveyor28;
        private HZH_Controls.Controls.UCConveyor ucConveyor29;
        private HZH_Controls.Controls.UCConveyor ucConveyor30;
        private HZH_Controls.Controls.UCConveyor ucConveyor31;
        private HZH_Controls.Controls.UCConveyor ucConveyor32;
        private HZH_Controls.Controls.UCConveyor ucConveyor33;
        private HZH_Controls.Controls.UCConveyor ucConveyor34;
        private HZH_Controls.Controls.UCConveyor ucConveyor35;
        private HZH_Controls.Controls.UCConveyor ucConveyor36;
    }
}
