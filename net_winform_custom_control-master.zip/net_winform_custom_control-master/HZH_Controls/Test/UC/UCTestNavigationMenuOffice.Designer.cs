﻿namespace Test.UC
{
    partial class UCTestNavigationMenuOffice
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            HZH_Controls.Controls.NavigationMenuItemExt navigationMenuItemExt1 = new HZH_Controls.Controls.NavigationMenuItemExt();
            HZH_Controls.Controls.NavigationMenuItemExt navigationMenuItemExt2 = new HZH_Controls.Controls.NavigationMenuItemExt();
            HZH_Controls.Controls.NavigationMenuItemExt navigationMenuItemExt3 = new HZH_Controls.Controls.NavigationMenuItemExt();
            HZH_Controls.Controls.NavigationMenuItemExt navigationMenuItemExt4 = new HZH_Controls.Controls.NavigationMenuItemExt();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UCTestNavigationMenuOffice));
            HZH_Controls.Controls.NavigationMenuItemExt navigationMenuItemExt5 = new HZH_Controls.Controls.NavigationMenuItemExt();
            HZH_Controls.Controls.NavigationMenuItemExt navigationMenuItemExt6 = new HZH_Controls.Controls.NavigationMenuItemExt();
            HZH_Controls.Controls.NavigationMenuItemExt navigationMenuItemExt7 = new HZH_Controls.Controls.NavigationMenuItemExt();
            HZH_Controls.Controls.NavigationMenuItemExt navigationMenuItemExt8 = new HZH_Controls.Controls.NavigationMenuItemExt();
            HZH_Controls.Controls.NavigationMenuItemExt navigationMenuItemExt9 = new HZH_Controls.Controls.NavigationMenuItemExt();
            HZH_Controls.Controls.NavigationMenuItemExt navigationMenuItemExt10 = new HZH_Controls.Controls.NavigationMenuItemExt();
            HZH_Controls.Controls.NavigationMenuItemExt navigationMenuItemExt11 = new HZH_Controls.Controls.NavigationMenuItemExt();
            HZH_Controls.Controls.NavigationMenuItemExt navigationMenuItemExt12 = new HZH_Controls.Controls.NavigationMenuItemExt();
            HZH_Controls.Controls.NavigationMenuItemExt navigationMenuItemExt13 = new HZH_Controls.Controls.NavigationMenuItemExt();
            HZH_Controls.Controls.NavigationMenuItemExt navigationMenuItemExt14 = new HZH_Controls.Controls.NavigationMenuItemExt();
            HZH_Controls.Controls.NavigationMenuItemExt navigationMenuItemExt15 = new HZH_Controls.Controls.NavigationMenuItemExt();
            HZH_Controls.Controls.NavigationMenuItemExt navigationMenuItemExt16 = new HZH_Controls.Controls.NavigationMenuItemExt();
            this.ucNavigationMenuOffice1 = new HZH_Controls.Controls.UCNavigationMenuOffice();
            this.ucNavigationMenuOffice2 = new HZH_Controls.Controls.UCNavigationMenuOffice();
            this.ucNavigationMenuOffice3 = new HZH_Controls.Controls.UCNavigationMenuOffice();
            this.ucNavigationMenuOffice4 = new HZH_Controls.Controls.UCNavigationMenuOffice();
            this.SuspendLayout();
            // 
            // ucNavigationMenuOffice1
            // 
            this.ucNavigationMenuOffice1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(61)))), ((int)(((byte)(73)))));
            this.ucNavigationMenuOffice1.ExpandHeight = 125;
            this.ucNavigationMenuOffice1.Font = new System.Drawing.Font("微软雅黑", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ucNavigationMenuOffice1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ucNavigationMenuOffice1.IsExpand = true;
            navigationMenuItemExt1.AnchorRight = false;
            navigationMenuItemExt1.DataSource = null;
            navigationMenuItemExt1.Icon = null;
            navigationMenuItemExt1.ItemWidth = 100;
            navigationMenuItemExt1.ShowControl = null;
            navigationMenuItemExt1.ShowTip = true;
            navigationMenuItemExt1.Text = "菜单1";
            navigationMenuItemExt1.TipText = null;
            navigationMenuItemExt2.AnchorRight = false;
            navigationMenuItemExt2.DataSource = null;
            navigationMenuItemExt2.Icon = null;
            navigationMenuItemExt2.ItemWidth = 100;
            navigationMenuItemExt2.ShowControl = null;
            navigationMenuItemExt2.ShowTip = false;
            navigationMenuItemExt2.Text = "菜单2";
            navigationMenuItemExt2.TipText = null;
            navigationMenuItemExt3.AnchorRight = true;
            navigationMenuItemExt3.DataSource = null;
            navigationMenuItemExt3.Icon = null;
            navigationMenuItemExt3.ItemWidth = 100;
            navigationMenuItemExt3.ShowControl = null;
            navigationMenuItemExt3.ShowTip = true;
            navigationMenuItemExt3.Text = "菜单3";
            navigationMenuItemExt3.TipText = "1";
            navigationMenuItemExt4.AnchorRight = true;
            navigationMenuItemExt4.DataSource = null;
            navigationMenuItemExt4.Icon = ((System.Drawing.Image)(resources.GetObject("navigationMenuItemExt4.Icon")));
            navigationMenuItemExt4.ItemWidth = 100;
            navigationMenuItemExt4.ShowControl = null;
            navigationMenuItemExt4.ShowTip = false;
            navigationMenuItemExt4.Text = "菜单4";
            navigationMenuItemExt4.TipText = null;
            this.ucNavigationMenuOffice1.Items = new HZH_Controls.Controls.NavigationMenuItemExt[] {
        navigationMenuItemExt1,
        navigationMenuItemExt2,
        navigationMenuItemExt3,
        navigationMenuItemExt4};
            this.ucNavigationMenuOffice1.Location = new System.Drawing.Point(0, 0);
            this.ucNavigationMenuOffice1.MainMenuHeight = 25;
            this.ucNavigationMenuOffice1.Name = "ucNavigationMenuOffice1";
            this.ucNavigationMenuOffice1.Size = new System.Drawing.Size(783, 125);
            this.ucNavigationMenuOffice1.TabIndex = 0;
            this.ucNavigationMenuOffice1.TipColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(87)))), ((int)(((byte)(34)))));
            // 
            // ucNavigationMenuOffice2
            // 
            this.ucNavigationMenuOffice2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.ucNavigationMenuOffice2.ExpandHeight = 125;
            this.ucNavigationMenuOffice2.Font = new System.Drawing.Font("微软雅黑", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ucNavigationMenuOffice2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ucNavigationMenuOffice2.IsExpand = true;
            navigationMenuItemExt5.AnchorRight = false;
            navigationMenuItemExt5.DataSource = null;
            navigationMenuItemExt5.Icon = ((System.Drawing.Image)(resources.GetObject("navigationMenuItemExt5.Icon")));
            navigationMenuItemExt5.ItemWidth = 100;
            navigationMenuItemExt5.ShowControl = null;
            navigationMenuItemExt5.ShowTip = false;
            navigationMenuItemExt5.Text = "菜单1";
            navigationMenuItemExt5.TipText = null;
            navigationMenuItemExt6.AnchorRight = false;
            navigationMenuItemExt6.DataSource = null;
            navigationMenuItemExt6.Icon = null;
            navigationMenuItemExt6.ItemWidth = 100;
            navigationMenuItemExt6.ShowControl = null;
            navigationMenuItemExt6.ShowTip = false;
            navigationMenuItemExt6.Text = "菜单2";
            navigationMenuItemExt6.TipText = null;
            navigationMenuItemExt7.AnchorRight = true;
            navigationMenuItemExt7.DataSource = null;
            navigationMenuItemExt7.Icon = null;
            navigationMenuItemExt7.ItemWidth = 100;
            navigationMenuItemExt7.ShowControl = null;
            navigationMenuItemExt7.ShowTip = true;
            navigationMenuItemExt7.Text = "菜单3";
            navigationMenuItemExt7.TipText = null;
            navigationMenuItemExt8.AnchorRight = true;
            navigationMenuItemExt8.DataSource = null;
            navigationMenuItemExt8.Icon = null;
            navigationMenuItemExt8.ItemWidth = 100;
            navigationMenuItemExt8.ShowControl = null;
            navigationMenuItemExt8.ShowTip = true;
            navigationMenuItemExt8.Text = "菜单4";
            navigationMenuItemExt8.TipText = "5";
            this.ucNavigationMenuOffice2.Items = new HZH_Controls.Controls.NavigationMenuItemExt[] {
        navigationMenuItemExt5,
        navigationMenuItemExt6,
        navigationMenuItemExt7,
        navigationMenuItemExt8};
            this.ucNavigationMenuOffice2.Location = new System.Drawing.Point(0, 187);
            this.ucNavigationMenuOffice2.MainMenuHeight = 25;
            this.ucNavigationMenuOffice2.Name = "ucNavigationMenuOffice2";
            this.ucNavigationMenuOffice2.Size = new System.Drawing.Size(783, 125);
            this.ucNavigationMenuOffice2.TabIndex = 0;
            this.ucNavigationMenuOffice2.TipColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(87)))), ((int)(((byte)(34)))));
            // 
            // ucNavigationMenuOffice3
            // 
            this.ucNavigationMenuOffice3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(159)))), ((int)(((byte)(255)))));
            this.ucNavigationMenuOffice3.ExpandHeight = 125;
            this.ucNavigationMenuOffice3.Font = new System.Drawing.Font("微软雅黑", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ucNavigationMenuOffice3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ucNavigationMenuOffice3.IsExpand = true;
            navigationMenuItemExt9.AnchorRight = false;
            navigationMenuItemExt9.DataSource = null;
            navigationMenuItemExt9.Icon = null;
            navigationMenuItemExt9.ItemWidth = 100;
            navigationMenuItemExt9.ShowControl = null;
            navigationMenuItemExt9.ShowTip = true;
            navigationMenuItemExt9.Text = "菜单1";
            navigationMenuItemExt9.TipText = null;
            navigationMenuItemExt10.AnchorRight = false;
            navigationMenuItemExt10.DataSource = null;
            navigationMenuItemExt10.Icon = null;
            navigationMenuItemExt10.ItemWidth = 100;
            navigationMenuItemExt10.ShowControl = null;
            navigationMenuItemExt10.ShowTip = true;
            navigationMenuItemExt10.Text = "菜单2";
            navigationMenuItemExt10.TipText = null;
            navigationMenuItemExt11.AnchorRight = true;
            navigationMenuItemExt11.DataSource = null;
            navigationMenuItemExt11.Icon = null;
            navigationMenuItemExt11.ItemWidth = 100;
            navigationMenuItemExt11.ShowControl = null;
            navigationMenuItemExt11.ShowTip = true;
            navigationMenuItemExt11.Text = "菜单3";
            navigationMenuItemExt11.TipText = null;
            navigationMenuItemExt12.AnchorRight = true;
            navigationMenuItemExt12.DataSource = null;
            navigationMenuItemExt12.Icon = null;
            navigationMenuItemExt12.ItemWidth = 100;
            navigationMenuItemExt12.ShowControl = null;
            navigationMenuItemExt12.ShowTip = true;
            navigationMenuItemExt12.Text = "菜单4";
            navigationMenuItemExt12.TipText = null;
            this.ucNavigationMenuOffice3.Items = new HZH_Controls.Controls.NavigationMenuItemExt[] {
        navigationMenuItemExt9,
        navigationMenuItemExt10,
        navigationMenuItemExt11,
        navigationMenuItemExt12};
            this.ucNavigationMenuOffice3.Location = new System.Drawing.Point(0, 382);
            this.ucNavigationMenuOffice3.MainMenuHeight = 25;
            this.ucNavigationMenuOffice3.Name = "ucNavigationMenuOffice3";
            this.ucNavigationMenuOffice3.Size = new System.Drawing.Size(783, 125);
            this.ucNavigationMenuOffice3.TabIndex = 0;
            this.ucNavigationMenuOffice3.TipColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(87)))), ((int)(((byte)(34)))));
            // 
            // ucNavigationMenuOffice4
            // 
            this.ucNavigationMenuOffice4.BackColor = System.Drawing.Color.Gray;
            this.ucNavigationMenuOffice4.ExpandHeight = 125;
            this.ucNavigationMenuOffice4.Font = new System.Drawing.Font("微软雅黑", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ucNavigationMenuOffice4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ucNavigationMenuOffice4.IsExpand = true;
            navigationMenuItemExt13.AnchorRight = false;
            navigationMenuItemExt13.DataSource = null;
            navigationMenuItemExt13.Icon = null;
            navigationMenuItemExt13.ItemWidth = 100;
            navigationMenuItemExt13.ShowControl = null;
            navigationMenuItemExt13.ShowTip = false;
            navigationMenuItemExt13.Text = "菜单1";
            navigationMenuItemExt13.TipText = null;
            navigationMenuItemExt14.AnchorRight = false;
            navigationMenuItemExt14.DataSource = null;
            navigationMenuItemExt14.Icon = null;
            navigationMenuItemExt14.ItemWidth = 100;
            navigationMenuItemExt14.ShowControl = null;
            navigationMenuItemExt14.ShowTip = false;
            navigationMenuItemExt14.Text = "菜单2";
            navigationMenuItemExt14.TipText = null;
            navigationMenuItemExt15.AnchorRight = true;
            navigationMenuItemExt15.DataSource = null;
            navigationMenuItemExt15.Icon = null;
            navigationMenuItemExt15.ItemWidth = 100;
            navigationMenuItemExt15.ShowControl = null;
            navigationMenuItemExt15.ShowTip = false;
            navigationMenuItemExt15.Text = "菜单3";
            navigationMenuItemExt15.TipText = null;
            navigationMenuItemExt16.AnchorRight = true;
            navigationMenuItemExt16.DataSource = null;
            navigationMenuItemExt16.Icon = null;
            navigationMenuItemExt16.ItemWidth = 100;
            navigationMenuItemExt16.ShowControl = null;
            navigationMenuItemExt16.ShowTip = false;
            navigationMenuItemExt16.Text = "菜单4";
            navigationMenuItemExt16.TipText = null;
            this.ucNavigationMenuOffice4.Items = new HZH_Controls.Controls.NavigationMenuItemExt[] {
        navigationMenuItemExt13,
        navigationMenuItemExt14,
        navigationMenuItemExt15,
        navigationMenuItemExt16};
            this.ucNavigationMenuOffice4.Location = new System.Drawing.Point(0, 561);
            this.ucNavigationMenuOffice4.MainMenuHeight = 25;
            this.ucNavigationMenuOffice4.Name = "ucNavigationMenuOffice4";
            this.ucNavigationMenuOffice4.Size = new System.Drawing.Size(783, 125);
            this.ucNavigationMenuOffice4.TabIndex = 0;
            this.ucNavigationMenuOffice4.TipColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(87)))), ((int)(((byte)(34)))));
            // 
            // UCTestNavigationMenuOffice
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.ucNavigationMenuOffice4);
            this.Controls.Add(this.ucNavigationMenuOffice3);
            this.Controls.Add(this.ucNavigationMenuOffice2);
            this.Controls.Add(this.ucNavigationMenuOffice1);
            this.Name = "UCTestNavigationMenuOffice";
            this.Size = new System.Drawing.Size(783, 723);
            this.Load += new System.EventHandler(this.UCTestNavigationMenuOffice_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private HZH_Controls.Controls.UCNavigationMenuOffice ucNavigationMenuOffice1;
        private HZH_Controls.Controls.UCNavigationMenuOffice ucNavigationMenuOffice2;
        private HZH_Controls.Controls.UCNavigationMenuOffice ucNavigationMenuOffice3;
        private HZH_Controls.Controls.UCNavigationMenuOffice ucNavigationMenuOffice4;
    }
}
