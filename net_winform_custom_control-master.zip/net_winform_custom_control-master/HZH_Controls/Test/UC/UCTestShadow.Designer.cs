﻿namespace Test.UC
{
    partial class UCTestShadow
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UCTestShadow));
            this.ucControlBase3 = new HZH_Controls.Controls.UCControlBase();
            this.ucBtnImg21 = new HZH_Controls.Controls.UCBtnImg();
            this.ucSplitLine_V1 = new HZH_Controls.Controls.UCSplitLine_V();
            this.ucBtnImg20 = new HZH_Controls.Controls.UCBtnImg();
            this.ucSplitLine_V2 = new HZH_Controls.Controls.UCSplitLine_V();
            this.ucBtnImg22 = new HZH_Controls.Controls.UCBtnImg();
            this.ucControlBase1 = new HZH_Controls.Controls.UCControlBase();
            this.ucBtnExt3 = new HZH_Controls.Controls.UCBtnExt();
            this.ucBtnExt4 = new HZH_Controls.Controls.UCBtnExt();
            this.ucBtnExt5 = new HZH_Controls.Controls.UCBtnExt();
            this.ucBtnExt33 = new HZH_Controls.Controls.UCBtnExt();
            this.ucBtnExt32 = new HZH_Controls.Controls.UCBtnExt();
            this.ucBtnExt31 = new HZH_Controls.Controls.UCBtnExt();
            this.ucBtnExt30 = new HZH_Controls.Controls.UCBtnExt();
            this.ucBtnExt29 = new HZH_Controls.Controls.UCBtnExt();
            this.ucBtnExt16 = new HZH_Controls.Controls.UCBtnExt();
            this.ucBtnExt17 = new HZH_Controls.Controls.UCBtnExt();
            this.ucBtnExt18 = new HZH_Controls.Controls.UCBtnExt();
            this.ucBtnExt21 = new HZH_Controls.Controls.UCBtnExt();
            this.ucBtnExt22 = new HZH_Controls.Controls.UCBtnExt();
            this.shadowComponent1 = new HZH_Controls.Controls.ShadowComponent(this.components);
            this.ucControlBase3.SuspendLayout();
            this.ucControlBase1.SuspendLayout();
            this.SuspendLayout();
            // 
            // ucControlBase3
            // 
            this.ucControlBase3.BackColor = System.Drawing.Color.White;
            this.ucControlBase3.ConerRadius = 10;
            this.ucControlBase3.Controls.Add(this.ucBtnImg21);
            this.ucControlBase3.Controls.Add(this.ucSplitLine_V1);
            this.ucControlBase3.Controls.Add(this.ucBtnImg20);
            this.ucControlBase3.Controls.Add(this.ucSplitLine_V2);
            this.ucControlBase3.Controls.Add(this.ucBtnImg22);
            this.ucControlBase3.FillColor = System.Drawing.Color.White;
            this.ucControlBase3.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucControlBase3.IsRadius = true;
            this.ucControlBase3.IsShowRect = true;
            this.ucControlBase3.Location = new System.Drawing.Point(223, 319);
            this.ucControlBase3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ucControlBase3.Name = "ucControlBase3";
            this.ucControlBase3.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            this.ucControlBase3.RectWidth = 1;
            this.shadowComponent1.SetShowShadow(this.ucControlBase3, true);
            this.ucControlBase3.Size = new System.Drawing.Size(167, 44);
            this.ucControlBase3.TabIndex = 26;
            // 
            // ucBtnImg21
            // 
            this.ucBtnImg21.BackColor = System.Drawing.Color.Transparent;
            this.ucBtnImg21.BtnBackColor = System.Drawing.Color.Transparent;
            this.ucBtnImg21.BtnFont = new System.Drawing.Font("微软雅黑", 15F);
            this.ucBtnImg21.BtnForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg21.BtnText = "";
            this.ucBtnImg21.ConerRadius = 1;
            this.ucBtnImg21.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnImg21.Dock = System.Windows.Forms.DockStyle.Left;
            this.ucBtnImg21.FillColor = System.Drawing.Color.Transparent;
            this.ucBtnImg21.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnImg21.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg21.Image = ((System.Drawing.Image)(resources.GetObject("ucBtnImg21.Image")));
            this.ucBtnImg21.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg21.ImageFontIcons = ((object)(resources.GetObject("ucBtnImg21.ImageFontIcons")));
            this.ucBtnImg21.IsRadius = false;
            this.ucBtnImg21.IsShowRect = false;
            this.ucBtnImg21.IsShowTips = false;
            this.ucBtnImg21.Location = new System.Drawing.Point(114, 0);
            this.ucBtnImg21.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnImg21.Name = "ucBtnImg21";
            this.ucBtnImg21.RectColor = System.Drawing.Color.Gainsboro;
            this.ucBtnImg21.RectWidth = 1;
            this.shadowComponent1.SetShowShadow(this.ucBtnImg21, false);
            this.ucBtnImg21.Size = new System.Drawing.Size(55, 44);
            this.ucBtnImg21.TabIndex = 20;
            this.ucBtnImg21.TabStop = false;
            this.ucBtnImg21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg21.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnImg21.TipsText = "";
            // 
            // ucSplitLine_V1
            // 
            this.ucSplitLine_V1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(232)))), ((int)(((byte)(232)))));
            this.ucSplitLine_V1.Dock = System.Windows.Forms.DockStyle.Left;
            this.ucSplitLine_V1.Location = new System.Drawing.Point(113, 0);
            this.ucSplitLine_V1.Name = "ucSplitLine_V1";
            this.shadowComponent1.SetShowShadow(this.ucSplitLine_V1, false);
            this.ucSplitLine_V1.Size = new System.Drawing.Size(1, 44);
            this.ucSplitLine_V1.TabIndex = 2;
            this.ucSplitLine_V1.TabStop = false;
            // 
            // ucBtnImg20
            // 
            this.ucBtnImg20.BackColor = System.Drawing.Color.Transparent;
            this.ucBtnImg20.BtnBackColor = System.Drawing.Color.Transparent;
            this.ucBtnImg20.BtnFont = new System.Drawing.Font("微软雅黑", 15F);
            this.ucBtnImg20.BtnForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg20.BtnText = "";
            this.ucBtnImg20.ConerRadius = 1;
            this.ucBtnImg20.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnImg20.Dock = System.Windows.Forms.DockStyle.Left;
            this.ucBtnImg20.FillColor = System.Drawing.Color.Transparent;
            this.ucBtnImg20.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnImg20.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg20.Image = ((System.Drawing.Image)(resources.GetObject("ucBtnImg20.Image")));
            this.ucBtnImg20.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg20.ImageFontIcons = ((object)(resources.GetObject("ucBtnImg20.ImageFontIcons")));
            this.ucBtnImg20.IsRadius = false;
            this.ucBtnImg20.IsShowRect = false;
            this.ucBtnImg20.IsShowTips = false;
            this.ucBtnImg20.Location = new System.Drawing.Point(57, 0);
            this.ucBtnImg20.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnImg20.Name = "ucBtnImg20";
            this.ucBtnImg20.RectColor = System.Drawing.Color.Gainsboro;
            this.ucBtnImg20.RectWidth = 1;
            this.shadowComponent1.SetShowShadow(this.ucBtnImg20, false);
            this.ucBtnImg20.Size = new System.Drawing.Size(56, 44);
            this.ucBtnImg20.TabIndex = 19;
            this.ucBtnImg20.TabStop = false;
            this.ucBtnImg20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg20.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnImg20.TipsText = "";
            // 
            // ucSplitLine_V2
            // 
            this.ucSplitLine_V2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(232)))), ((int)(((byte)(232)))));
            this.ucSplitLine_V2.Dock = System.Windows.Forms.DockStyle.Left;
            this.ucSplitLine_V2.Location = new System.Drawing.Point(56, 0);
            this.ucSplitLine_V2.Name = "ucSplitLine_V2";
            this.shadowComponent1.SetShowShadow(this.ucSplitLine_V2, false);
            this.ucSplitLine_V2.Size = new System.Drawing.Size(1, 44);
            this.ucSplitLine_V2.TabIndex = 21;
            this.ucSplitLine_V2.TabStop = false;
            // 
            // ucBtnImg22
            // 
            this.ucBtnImg22.BackColor = System.Drawing.Color.Transparent;
            this.ucBtnImg22.BtnBackColor = System.Drawing.Color.Transparent;
            this.ucBtnImg22.BtnFont = new System.Drawing.Font("微软雅黑", 15F);
            this.ucBtnImg22.BtnForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg22.BtnText = "";
            this.ucBtnImg22.ConerRadius = 1;
            this.ucBtnImg22.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnImg22.Dock = System.Windows.Forms.DockStyle.Left;
            this.ucBtnImg22.FillColor = System.Drawing.Color.Transparent;
            this.ucBtnImg22.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnImg22.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg22.Image = ((System.Drawing.Image)(resources.GetObject("ucBtnImg22.Image")));
            this.ucBtnImg22.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg22.ImageFontIcons = ((object)(resources.GetObject("ucBtnImg22.ImageFontIcons")));
            this.ucBtnImg22.IsRadius = false;
            this.ucBtnImg22.IsShowRect = false;
            this.ucBtnImg22.IsShowTips = false;
            this.ucBtnImg22.Location = new System.Drawing.Point(0, 0);
            this.ucBtnImg22.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnImg22.Name = "ucBtnImg22";
            this.ucBtnImg22.RectColor = System.Drawing.Color.Gainsboro;
            this.ucBtnImg22.RectWidth = 1;
            this.shadowComponent1.SetShowShadow(this.ucBtnImg22, false);
            this.ucBtnImg22.Size = new System.Drawing.Size(56, 44);
            this.ucBtnImg22.TabIndex = 18;
            this.ucBtnImg22.TabStop = false;
            this.ucBtnImg22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg22.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnImg22.TipsText = "";
            // 
            // ucControlBase1
            // 
            this.ucControlBase1.BackColor = System.Drawing.Color.Transparent;
            this.ucControlBase1.ConerRadius = 10;
            this.ucControlBase1.Controls.Add(this.ucBtnExt3);
            this.ucControlBase1.Controls.Add(this.ucBtnExt4);
            this.ucControlBase1.Controls.Add(this.ucBtnExt5);
            this.ucControlBase1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(58)))));
            this.ucControlBase1.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucControlBase1.IsRadius = true;
            this.ucControlBase1.IsShowRect = true;
            this.ucControlBase1.Location = new System.Drawing.Point(28, 319);
            this.ucControlBase1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ucControlBase1.Name = "ucControlBase1";
            this.ucControlBase1.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            this.ucControlBase1.RectWidth = 1;
            this.shadowComponent1.SetShowShadow(this.ucControlBase1, true);
            this.ucControlBase1.Size = new System.Drawing.Size(167, 44);
            this.ucControlBase1.TabIndex = 27;
            // 
            // ucBtnExt3
            // 
            this.ucBtnExt3.BackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt3.BtnBackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt3.BtnFont = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ucBtnExt3.BtnForeColor = System.Drawing.Color.White;
            this.ucBtnExt3.BtnText = "按钮3";
            this.ucBtnExt3.ConerRadius = 5;
            this.ucBtnExt3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnExt3.Dock = System.Windows.Forms.DockStyle.Left;
            this.ucBtnExt3.FillColor = System.Drawing.Color.Transparent;
            this.ucBtnExt3.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnExt3.IsRadius = false;
            this.ucBtnExt3.IsShowRect = false;
            this.ucBtnExt3.IsShowTips = false;
            this.ucBtnExt3.Location = new System.Drawing.Point(110, 0);
            this.ucBtnExt3.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnExt3.Name = "ucBtnExt3";
            this.ucBtnExt3.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(58)))));
            this.ucBtnExt3.RectWidth = 0;
            this.shadowComponent1.SetShowShadow(this.ucBtnExt3, false);
            this.ucBtnExt3.Size = new System.Drawing.Size(57, 44);
            this.ucBtnExt3.TabIndex = 2;
            this.ucBtnExt3.TabStop = false;
            this.ucBtnExt3.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnExt3.TipsText = "";
            // 
            // ucBtnExt4
            // 
            this.ucBtnExt4.BackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt4.BtnBackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt4.BtnFont = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ucBtnExt4.BtnForeColor = System.Drawing.Color.White;
            this.ucBtnExt4.BtnText = "按钮2";
            this.ucBtnExt4.ConerRadius = 5;
            this.ucBtnExt4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnExt4.Dock = System.Windows.Forms.DockStyle.Left;
            this.ucBtnExt4.FillColor = System.Drawing.Color.Transparent;
            this.ucBtnExt4.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnExt4.IsRadius = false;
            this.ucBtnExt4.IsShowRect = false;
            this.ucBtnExt4.IsShowTips = false;
            this.ucBtnExt4.Location = new System.Drawing.Point(57, 0);
            this.ucBtnExt4.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnExt4.Name = "ucBtnExt4";
            this.ucBtnExt4.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(58)))));
            this.ucBtnExt4.RectWidth = 0;
            this.shadowComponent1.SetShowShadow(this.ucBtnExt4, false);
            this.ucBtnExt4.Size = new System.Drawing.Size(53, 44);
            this.ucBtnExt4.TabIndex = 1;
            this.ucBtnExt4.TabStop = false;
            this.ucBtnExt4.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnExt4.TipsText = "";
            // 
            // ucBtnExt5
            // 
            this.ucBtnExt5.BackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt5.BtnBackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt5.BtnFont = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ucBtnExt5.BtnForeColor = System.Drawing.Color.White;
            this.ucBtnExt5.BtnText = "按钮1";
            this.ucBtnExt5.ConerRadius = 5;
            this.ucBtnExt5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnExt5.Dock = System.Windows.Forms.DockStyle.Left;
            this.ucBtnExt5.FillColor = System.Drawing.Color.Transparent;
            this.ucBtnExt5.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnExt5.IsRadius = false;
            this.ucBtnExt5.IsShowRect = false;
            this.ucBtnExt5.IsShowTips = false;
            this.ucBtnExt5.Location = new System.Drawing.Point(0, 0);
            this.ucBtnExt5.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnExt5.Name = "ucBtnExt5";
            this.ucBtnExt5.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(58)))));
            this.ucBtnExt5.RectWidth = 0;
            this.shadowComponent1.SetShowShadow(this.ucBtnExt5, false);
            this.ucBtnExt5.Size = new System.Drawing.Size(57, 44);
            this.ucBtnExt5.TabIndex = 0;
            this.ucBtnExt5.TabStop = false;
            this.ucBtnExt5.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnExt5.TipsText = "";
            // 
            // ucBtnExt33
            // 
            this.ucBtnExt33.BackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt33.BtnBackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt33.BtnFont = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ucBtnExt33.BtnForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnExt33.BtnText = "椭圆";
            this.ucBtnExt33.ConerRadius = 34;
            this.ucBtnExt33.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnExt33.FillColor = System.Drawing.Color.White;
            this.ucBtnExt33.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnExt33.ForeColor = System.Drawing.Color.White;
            this.ucBtnExt33.IsRadius = true;
            this.ucBtnExt33.IsShowRect = true;
            this.ucBtnExt33.IsShowTips = false;
            this.ucBtnExt33.Location = new System.Drawing.Point(28, 189);
            this.ucBtnExt33.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnExt33.Name = "ucBtnExt33";
            this.ucBtnExt33.RectColor = System.Drawing.Color.Gainsboro;
            this.ucBtnExt33.RectWidth = 1;
            this.shadowComponent1.SetShowShadow(this.ucBtnExt33, true);
            this.ucBtnExt33.Size = new System.Drawing.Size(97, 34);
            this.ucBtnExt33.TabIndex = 21;
            this.ucBtnExt33.TabStop = false;
            this.ucBtnExt33.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnExt33.TipsText = "";
            // 
            // ucBtnExt32
            // 
            this.ucBtnExt32.BackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt32.BtnBackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt32.BtnFont = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ucBtnExt32.BtnForeColor = System.Drawing.Color.White;
            this.ucBtnExt32.BtnText = "椭圆";
            this.ucBtnExt32.ConerRadius = 34;
            this.ucBtnExt32.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnExt32.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.ucBtnExt32.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnExt32.ForeColor = System.Drawing.Color.White;
            this.ucBtnExt32.IsRadius = true;
            this.ucBtnExt32.IsShowRect = false;
            this.ucBtnExt32.IsShowTips = false;
            this.ucBtnExt32.Location = new System.Drawing.Point(137, 189);
            this.ucBtnExt32.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnExt32.Name = "ucBtnExt32";
            this.ucBtnExt32.RectColor = System.Drawing.Color.Gainsboro;
            this.ucBtnExt32.RectWidth = 1;
            this.shadowComponent1.SetShowShadow(this.ucBtnExt32, true);
            this.ucBtnExt32.Size = new System.Drawing.Size(97, 34);
            this.ucBtnExt32.TabIndex = 22;
            this.ucBtnExt32.TabStop = false;
            this.ucBtnExt32.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnExt32.TipsText = "";
            // 
            // ucBtnExt31
            // 
            this.ucBtnExt31.BackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt31.BtnBackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt31.BtnFont = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ucBtnExt31.BtnForeColor = System.Drawing.Color.White;
            this.ucBtnExt31.BtnText = "椭圆";
            this.ucBtnExt31.ConerRadius = 34;
            this.ucBtnExt31.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnExt31.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(87)))), ((int)(((byte)(34)))));
            this.ucBtnExt31.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnExt31.ForeColor = System.Drawing.Color.White;
            this.ucBtnExt31.IsRadius = true;
            this.ucBtnExt31.IsShowRect = false;
            this.ucBtnExt31.IsShowTips = false;
            this.ucBtnExt31.Location = new System.Drawing.Point(490, 189);
            this.ucBtnExt31.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnExt31.Name = "ucBtnExt31";
            this.ucBtnExt31.RectColor = System.Drawing.Color.Gainsboro;
            this.ucBtnExt31.RectWidth = 1;
            this.shadowComponent1.SetShowShadow(this.ucBtnExt31, true);
            this.ucBtnExt31.Size = new System.Drawing.Size(97, 34);
            this.ucBtnExt31.TabIndex = 23;
            this.ucBtnExt31.TabStop = false;
            this.ucBtnExt31.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnExt31.TipsText = "";
            // 
            // ucBtnExt30
            // 
            this.ucBtnExt30.BackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt30.BtnBackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt30.BtnFont = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ucBtnExt30.BtnForeColor = System.Drawing.Color.White;
            this.ucBtnExt30.BtnText = "椭圆";
            this.ucBtnExt30.ConerRadius = 34;
            this.ucBtnExt30.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnExt30.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(159)))), ((int)(((byte)(255)))));
            this.ucBtnExt30.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnExt30.ForeColor = System.Drawing.Color.White;
            this.ucBtnExt30.IsRadius = true;
            this.ucBtnExt30.IsShowRect = false;
            this.ucBtnExt30.IsShowTips = false;
            this.ucBtnExt30.Location = new System.Drawing.Point(250, 189);
            this.ucBtnExt30.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnExt30.Name = "ucBtnExt30";
            this.ucBtnExt30.RectColor = System.Drawing.Color.Gainsboro;
            this.ucBtnExt30.RectWidth = 1;
            this.shadowComponent1.SetShowShadow(this.ucBtnExt30, true);
            this.ucBtnExt30.Size = new System.Drawing.Size(97, 34);
            this.ucBtnExt30.TabIndex = 24;
            this.ucBtnExt30.TabStop = false;
            this.ucBtnExt30.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnExt30.TipsText = "";
            // 
            // ucBtnExt29
            // 
            this.ucBtnExt29.BackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt29.BtnBackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt29.BtnFont = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ucBtnExt29.BtnForeColor = System.Drawing.Color.White;
            this.ucBtnExt29.BtnText = "椭圆";
            this.ucBtnExt29.ConerRadius = 34;
            this.ucBtnExt29.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnExt29.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(184)))), ((int)(((byte)(0)))));
            this.ucBtnExt29.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnExt29.ForeColor = System.Drawing.Color.White;
            this.ucBtnExt29.IsRadius = true;
            this.ucBtnExt29.IsShowRect = false;
            this.ucBtnExt29.IsShowTips = false;
            this.ucBtnExt29.Location = new System.Drawing.Point(366, 189);
            this.ucBtnExt29.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnExt29.Name = "ucBtnExt29";
            this.ucBtnExt29.RectColor = System.Drawing.Color.Gainsboro;
            this.ucBtnExt29.RectWidth = 1;
            this.shadowComponent1.SetShowShadow(this.ucBtnExt29, true);
            this.ucBtnExt29.Size = new System.Drawing.Size(97, 34);
            this.ucBtnExt29.TabIndex = 25;
            this.ucBtnExt29.TabStop = false;
            this.ucBtnExt29.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnExt29.TipsText = "";
            // 
            // ucBtnExt16
            // 
            this.ucBtnExt16.BackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt16.BtnBackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt16.BtnFont = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ucBtnExt16.BtnForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnExt16.BtnText = "大";
            this.ucBtnExt16.ConerRadius = 5;
            this.ucBtnExt16.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnExt16.FillColor = System.Drawing.Color.White;
            this.ucBtnExt16.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnExt16.ForeColor = System.Drawing.Color.White;
            this.ucBtnExt16.IsRadius = true;
            this.ucBtnExt16.IsShowRect = true;
            this.ucBtnExt16.IsShowTips = false;
            this.ucBtnExt16.Location = new System.Drawing.Point(28, 43);
            this.ucBtnExt16.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnExt16.Name = "ucBtnExt16";
            this.ucBtnExt16.RectColor = System.Drawing.Color.Gainsboro;
            this.ucBtnExt16.RectWidth = 1;
            this.shadowComponent1.SetShowShadow(this.ucBtnExt16, true);
            this.ucBtnExt16.Size = new System.Drawing.Size(97, 47);
            this.ucBtnExt16.TabIndex = 16;
            this.ucBtnExt16.TabStop = false;
            this.ucBtnExt16.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnExt16.TipsText = "";
            // 
            // ucBtnExt17
            // 
            this.ucBtnExt17.BackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt17.BtnBackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt17.BtnFont = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ucBtnExt17.BtnForeColor = System.Drawing.Color.White;
            this.ucBtnExt17.BtnText = "大";
            this.ucBtnExt17.ConerRadius = 5;
            this.ucBtnExt17.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnExt17.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.ucBtnExt17.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnExt17.ForeColor = System.Drawing.Color.White;
            this.ucBtnExt17.IsRadius = true;
            this.ucBtnExt17.IsShowRect = false;
            this.ucBtnExt17.IsShowTips = false;
            this.ucBtnExt17.Location = new System.Drawing.Point(137, 43);
            this.ucBtnExt17.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnExt17.Name = "ucBtnExt17";
            this.ucBtnExt17.RectColor = System.Drawing.Color.Gainsboro;
            this.ucBtnExt17.RectWidth = 1;
            this.shadowComponent1.SetShowShadow(this.ucBtnExt17, true);
            this.ucBtnExt17.Size = new System.Drawing.Size(97, 47);
            this.ucBtnExt17.TabIndex = 17;
            this.ucBtnExt17.TabStop = false;
            this.ucBtnExt17.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnExt17.TipsText = "";
            // 
            // ucBtnExt18
            // 
            this.ucBtnExt18.BackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt18.BtnBackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt18.BtnFont = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ucBtnExt18.BtnForeColor = System.Drawing.Color.White;
            this.ucBtnExt18.BtnText = "大";
            this.ucBtnExt18.ConerRadius = 5;
            this.ucBtnExt18.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnExt18.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(87)))), ((int)(((byte)(34)))));
            this.ucBtnExt18.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnExt18.ForeColor = System.Drawing.Color.White;
            this.ucBtnExt18.IsRadius = true;
            this.ucBtnExt18.IsShowRect = false;
            this.ucBtnExt18.IsShowTips = false;
            this.ucBtnExt18.Location = new System.Drawing.Point(490, 43);
            this.ucBtnExt18.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnExt18.Name = "ucBtnExt18";
            this.ucBtnExt18.RectColor = System.Drawing.Color.Gainsboro;
            this.ucBtnExt18.RectWidth = 1;
            this.shadowComponent1.SetShowShadow(this.ucBtnExt18, true);
            this.ucBtnExt18.Size = new System.Drawing.Size(97, 47);
            this.ucBtnExt18.TabIndex = 18;
            this.ucBtnExt18.TabStop = false;
            this.ucBtnExt18.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnExt18.TipsText = "";
            // 
            // ucBtnExt21
            // 
            this.ucBtnExt21.BackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt21.BtnBackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt21.BtnFont = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ucBtnExt21.BtnForeColor = System.Drawing.Color.White;
            this.ucBtnExt21.BtnText = "大";
            this.ucBtnExt21.ConerRadius = 5;
            this.ucBtnExt21.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnExt21.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(159)))), ((int)(((byte)(255)))));
            this.ucBtnExt21.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnExt21.ForeColor = System.Drawing.Color.White;
            this.ucBtnExt21.IsRadius = true;
            this.ucBtnExt21.IsShowRect = false;
            this.ucBtnExt21.IsShowTips = false;
            this.ucBtnExt21.Location = new System.Drawing.Point(250, 43);
            this.ucBtnExt21.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnExt21.Name = "ucBtnExt21";
            this.ucBtnExt21.RectColor = System.Drawing.Color.Gainsboro;
            this.ucBtnExt21.RectWidth = 1;
            this.shadowComponent1.SetShowShadow(this.ucBtnExt21, true);
            this.ucBtnExt21.Size = new System.Drawing.Size(97, 47);
            this.ucBtnExt21.TabIndex = 19;
            this.ucBtnExt21.TabStop = false;
            this.ucBtnExt21.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnExt21.TipsText = "";
            // 
            // ucBtnExt22
            // 
            this.ucBtnExt22.BackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt22.BtnBackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt22.BtnFont = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ucBtnExt22.BtnForeColor = System.Drawing.Color.White;
            this.ucBtnExt22.BtnText = "大";
            this.ucBtnExt22.ConerRadius = 5;
            this.ucBtnExt22.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnExt22.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(184)))), ((int)(((byte)(0)))));
            this.ucBtnExt22.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnExt22.ForeColor = System.Drawing.Color.White;
            this.ucBtnExt22.IsRadius = true;
            this.ucBtnExt22.IsShowRect = false;
            this.ucBtnExt22.IsShowTips = false;
            this.ucBtnExt22.Location = new System.Drawing.Point(366, 43);
            this.ucBtnExt22.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnExt22.Name = "ucBtnExt22";
            this.ucBtnExt22.RectColor = System.Drawing.Color.Gainsboro;
            this.ucBtnExt22.RectWidth = 1;
            this.shadowComponent1.SetShowShadow(this.ucBtnExt22, true);
            this.ucBtnExt22.Size = new System.Drawing.Size(97, 47);
            this.ucBtnExt22.TabIndex = 20;
            this.ucBtnExt22.TabStop = false;
            this.ucBtnExt22.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnExt22.TipsText = "";
            // 
            // shadowComponent1
            // 
            this.shadowComponent1.ShadowHeight = 0.5F;
            // 
            // UCTestShadow
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.ucControlBase3);
            this.Controls.Add(this.ucControlBase1);
            this.Controls.Add(this.ucBtnExt33);
            this.Controls.Add(this.ucBtnExt32);
            this.Controls.Add(this.ucBtnExt31);
            this.Controls.Add(this.ucBtnExt30);
            this.Controls.Add(this.ucBtnExt29);
            this.Controls.Add(this.ucBtnExt16);
            this.Controls.Add(this.ucBtnExt17);
            this.Controls.Add(this.ucBtnExt18);
            this.Controls.Add(this.ucBtnExt21);
            this.Controls.Add(this.ucBtnExt22);
            this.DoubleBuffered = true;
            this.Name = "UCTestShadow";
            this.shadowComponent1.SetShowShadow(this, false);
            this.Size = new System.Drawing.Size(624, 456);
            this.ucControlBase3.ResumeLayout(false);
            this.ucControlBase1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private HZH_Controls.Controls.ShadowComponent shadowComponent1;
        private HZH_Controls.Controls.UCBtnExt ucBtnExt16;
        private HZH_Controls.Controls.UCBtnExt ucBtnExt17;
        private HZH_Controls.Controls.UCBtnExt ucBtnExt18;
        private HZH_Controls.Controls.UCBtnExt ucBtnExt21;
        private HZH_Controls.Controls.UCBtnExt ucBtnExt22;
        private HZH_Controls.Controls.UCBtnExt ucBtnExt33;
        private HZH_Controls.Controls.UCBtnExt ucBtnExt32;
        private HZH_Controls.Controls.UCBtnExt ucBtnExt31;
        private HZH_Controls.Controls.UCBtnExt ucBtnExt30;
        private HZH_Controls.Controls.UCBtnExt ucBtnExt29;
        private HZH_Controls.Controls.UCControlBase ucControlBase3;
        private HZH_Controls.Controls.UCBtnImg ucBtnImg21;
        private HZH_Controls.Controls.UCSplitLine_V ucSplitLine_V1;
        private HZH_Controls.Controls.UCBtnImg ucBtnImg20;
        private HZH_Controls.Controls.UCSplitLine_V ucSplitLine_V2;
        private HZH_Controls.Controls.UCBtnImg ucBtnImg22;
        private HZH_Controls.Controls.UCControlBase ucControlBase1;
        private HZH_Controls.Controls.UCBtnExt ucBtnExt3;
        private HZH_Controls.Controls.UCBtnExt ucBtnExt4;
        private HZH_Controls.Controls.UCBtnExt ucBtnExt5;
    }
}
