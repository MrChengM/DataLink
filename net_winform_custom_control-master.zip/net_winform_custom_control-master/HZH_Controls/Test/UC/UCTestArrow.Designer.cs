﻿namespace Test.UC
{
    partial class UCTestArrow
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.ucArrow5 = new HZH_Controls.Controls.UCArrow();
            this.ucArrow6 = new HZH_Controls.Controls.UCArrow();
            this.ucArrow4 = new HZH_Controls.Controls.UCArrow();
            this.ucArrow2 = new HZH_Controls.Controls.UCArrow();
            this.ucArrow3 = new HZH_Controls.Controls.UCArrow();
            this.ucArrow1 = new HZH_Controls.Controls.UCArrow();
            this.ucArrow7 = new HZH_Controls.Controls.UCArrow();
            this.ucArrow8 = new HZH_Controls.Controls.UCArrow();
            this.ucArrow9 = new HZH_Controls.Controls.UCArrow();
            this.ucArrow10 = new HZH_Controls.Controls.UCArrow();
            this.ucArrow11 = new HZH_Controls.Controls.UCArrow();
            this.ucArrow12 = new HZH_Controls.Controls.UCArrow();
            this.SuspendLayout();
            // 
            // ucArrow5
            // 
            this.ucArrow5.ArrowColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucArrow5.BorderColor = null;
            this.ucArrow5.Direction = HZH_Controls.Controls.ArrowDirection.Bottom;
            this.ucArrow5.ForeColor = System.Drawing.Color.White;
            this.ucArrow5.Location = new System.Drawing.Point(60, 228);
            this.ucArrow5.Name = "ucArrow5";
            this.ucArrow5.Size = new System.Drawing.Size(64, 84);
            this.ucArrow5.TabIndex = 28;
            this.ucArrow5.Text = "下";
            // 
            // ucArrow6
            // 
            this.ucArrow6.ArrowColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucArrow6.BorderColor = null;
            this.ucArrow6.Direction = HZH_Controls.Controls.ArrowDirection.Top_Bottom;
            this.ucArrow6.ForeColor = System.Drawing.Color.White;
            this.ucArrow6.Location = new System.Drawing.Point(134, 139);
            this.ucArrow6.Name = "ucArrow6";
            this.ucArrow6.Size = new System.Drawing.Size(64, 173);
            this.ucArrow6.TabIndex = 29;
            this.ucArrow6.Text = "上下";
            // 
            // ucArrow4
            // 
            this.ucArrow4.ArrowColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucArrow4.BorderColor = null;
            this.ucArrow4.Direction = HZH_Controls.Controls.ArrowDirection.Top;
            this.ucArrow4.ForeColor = System.Drawing.Color.White;
            this.ucArrow4.Location = new System.Drawing.Point(60, 138);
            this.ucArrow4.Name = "ucArrow4";
            this.ucArrow4.Size = new System.Drawing.Size(64, 84);
            this.ucArrow4.TabIndex = 30;
            this.ucArrow4.Text = "上";
            // 
            // ucArrow2
            // 
            this.ucArrow2.ArrowColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucArrow2.BorderColor = null;
            this.ucArrow2.Direction = HZH_Controls.Controls.ArrowDirection.Left;
            this.ucArrow2.ForeColor = System.Drawing.Color.White;
            this.ucArrow2.Location = new System.Drawing.Point(24, 27);
            this.ucArrow2.Name = "ucArrow2";
            this.ucArrow2.Size = new System.Drawing.Size(100, 50);
            this.ucArrow2.TabIndex = 31;
            this.ucArrow2.Text = "左";
            // 
            // ucArrow3
            // 
            this.ucArrow3.ArrowColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucArrow3.BorderColor = null;
            this.ucArrow3.Direction = HZH_Controls.Controls.ArrowDirection.Left_Right;
            this.ucArrow3.ForeColor = System.Drawing.Color.White;
            this.ucArrow3.Location = new System.Drawing.Point(24, 82);
            this.ucArrow3.Name = "ucArrow3";
            this.ucArrow3.Size = new System.Drawing.Size(210, 50);
            this.ucArrow3.TabIndex = 32;
            this.ucArrow3.Text = "左右";
            // 
            // ucArrow1
            // 
            this.ucArrow1.ArrowColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucArrow1.BorderColor = null;
            this.ucArrow1.Direction = HZH_Controls.Controls.ArrowDirection.Right;
            this.ucArrow1.ForeColor = System.Drawing.Color.White;
            this.ucArrow1.Location = new System.Drawing.Point(134, 27);
            this.ucArrow1.Name = "ucArrow1";
            this.ucArrow1.Size = new System.Drawing.Size(100, 50);
            this.ucArrow1.TabIndex = 33;
            this.ucArrow1.Text = "右";
            // 
            // ucArrow7
            // 
            this.ucArrow7.ArrowColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.ucArrow7.BorderColor = null;
            this.ucArrow7.Direction = HZH_Controls.Controls.ArrowDirection.Right;
            this.ucArrow7.ForeColor = System.Drawing.Color.White;
            this.ucArrow7.Location = new System.Drawing.Point(397, 27);
            this.ucArrow7.Name = "ucArrow7";
            this.ucArrow7.Size = new System.Drawing.Size(100, 50);
            this.ucArrow7.TabIndex = 33;
            this.ucArrow7.Text = "右";
            // 
            // ucArrow8
            // 
            this.ucArrow8.ArrowColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.ucArrow8.BorderColor = null;
            this.ucArrow8.Direction = HZH_Controls.Controls.ArrowDirection.Left_Right;
            this.ucArrow8.ForeColor = System.Drawing.Color.White;
            this.ucArrow8.Location = new System.Drawing.Point(287, 82);
            this.ucArrow8.Name = "ucArrow8";
            this.ucArrow8.Size = new System.Drawing.Size(210, 50);
            this.ucArrow8.TabIndex = 32;
            this.ucArrow8.Text = "左右";
            // 
            // ucArrow9
            // 
            this.ucArrow9.ArrowColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.ucArrow9.BorderColor = null;
            this.ucArrow9.Direction = HZH_Controls.Controls.ArrowDirection.Left;
            this.ucArrow9.ForeColor = System.Drawing.Color.White;
            this.ucArrow9.Location = new System.Drawing.Point(287, 27);
            this.ucArrow9.Name = "ucArrow9";
            this.ucArrow9.Size = new System.Drawing.Size(100, 50);
            this.ucArrow9.TabIndex = 31;
            this.ucArrow9.Text = "左";
            // 
            // ucArrow10
            // 
            this.ucArrow10.ArrowColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.ucArrow10.BorderColor = null;
            this.ucArrow10.Direction = HZH_Controls.Controls.ArrowDirection.Top;
            this.ucArrow10.ForeColor = System.Drawing.Color.White;
            this.ucArrow10.Location = new System.Drawing.Point(323, 138);
            this.ucArrow10.Name = "ucArrow10";
            this.ucArrow10.Size = new System.Drawing.Size(64, 84);
            this.ucArrow10.TabIndex = 30;
            this.ucArrow10.Text = "上";
            // 
            // ucArrow11
            // 
            this.ucArrow11.ArrowColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.ucArrow11.BorderColor = null;
            this.ucArrow11.Direction = HZH_Controls.Controls.ArrowDirection.Top_Bottom;
            this.ucArrow11.ForeColor = System.Drawing.Color.White;
            this.ucArrow11.Location = new System.Drawing.Point(397, 139);
            this.ucArrow11.Name = "ucArrow11";
            this.ucArrow11.Size = new System.Drawing.Size(64, 173);
            this.ucArrow11.TabIndex = 29;
            this.ucArrow11.Text = "上下";
            // 
            // ucArrow12
            // 
            this.ucArrow12.ArrowColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.ucArrow12.BorderColor = null;
            this.ucArrow12.Direction = HZH_Controls.Controls.ArrowDirection.Bottom;
            this.ucArrow12.ForeColor = System.Drawing.Color.White;
            this.ucArrow12.Location = new System.Drawing.Point(323, 228);
            this.ucArrow12.Name = "ucArrow12";
            this.ucArrow12.Size = new System.Drawing.Size(64, 84);
            this.ucArrow12.TabIndex = 28;
            this.ucArrow12.Text = "下";
            // 
            // UCTestArrow
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.ucArrow12);
            this.Controls.Add(this.ucArrow5);
            this.Controls.Add(this.ucArrow11);
            this.Controls.Add(this.ucArrow6);
            this.Controls.Add(this.ucArrow10);
            this.Controls.Add(this.ucArrow4);
            this.Controls.Add(this.ucArrow9);
            this.Controls.Add(this.ucArrow8);
            this.Controls.Add(this.ucArrow2);
            this.Controls.Add(this.ucArrow7);
            this.Controls.Add(this.ucArrow3);
            this.Controls.Add(this.ucArrow1);
            this.Name = "UCTestArrow";
            this.Size = new System.Drawing.Size(609, 603);
            this.ResumeLayout(false);

        }

        #endregion

        private HZH_Controls.Controls.UCArrow ucArrow5;
        private HZH_Controls.Controls.UCArrow ucArrow6;
        private HZH_Controls.Controls.UCArrow ucArrow4;
        private HZH_Controls.Controls.UCArrow ucArrow2;
        private HZH_Controls.Controls.UCArrow ucArrow3;
        private HZH_Controls.Controls.UCArrow ucArrow1;
        private HZH_Controls.Controls.UCArrow ucArrow7;
        private HZH_Controls.Controls.UCArrow ucArrow8;
        private HZH_Controls.Controls.UCArrow ucArrow9;
        private HZH_Controls.Controls.UCArrow ucArrow10;
        private HZH_Controls.Controls.UCArrow ucArrow11;
        private HZH_Controls.Controls.UCArrow ucArrow12;
    }
}
