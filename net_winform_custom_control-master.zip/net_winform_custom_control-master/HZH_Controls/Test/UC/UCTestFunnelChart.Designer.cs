﻿namespace Test.UC
{
    partial class UCTestFunnelChart
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            HZH_Controls.Controls.FunelChartItem funelChartItem81 = new HZH_Controls.Controls.FunelChartItem();
            HZH_Controls.Controls.FunelChartItem funelChartItem82 = new HZH_Controls.Controls.FunelChartItem();
            HZH_Controls.Controls.FunelChartItem funelChartItem83 = new HZH_Controls.Controls.FunelChartItem();
            HZH_Controls.Controls.FunelChartItem funelChartItem84 = new HZH_Controls.Controls.FunelChartItem();
            HZH_Controls.Controls.FunelChartItem funelChartItem85 = new HZH_Controls.Controls.FunelChartItem();
            HZH_Controls.Controls.FunelChartItem funelChartItem86 = new HZH_Controls.Controls.FunelChartItem();
            HZH_Controls.Controls.FunelChartItem funelChartItem87 = new HZH_Controls.Controls.FunelChartItem();
            HZH_Controls.Controls.FunelChartItem funelChartItem88 = new HZH_Controls.Controls.FunelChartItem();
            HZH_Controls.Controls.FunelChartItem funelChartItem89 = new HZH_Controls.Controls.FunelChartItem();
            HZH_Controls.Controls.FunelChartItem funelChartItem90 = new HZH_Controls.Controls.FunelChartItem();
            HZH_Controls.Controls.FunelChartItem funelChartItem91 = new HZH_Controls.Controls.FunelChartItem();
            HZH_Controls.Controls.FunelChartItem funelChartItem92 = new HZH_Controls.Controls.FunelChartItem();
            HZH_Controls.Controls.FunelChartItem funelChartItem93 = new HZH_Controls.Controls.FunelChartItem();
            HZH_Controls.Controls.FunelChartItem funelChartItem94 = new HZH_Controls.Controls.FunelChartItem();
            HZH_Controls.Controls.FunelChartItem funelChartItem95 = new HZH_Controls.Controls.FunelChartItem();
            HZH_Controls.Controls.FunelChartItem funelChartItem96 = new HZH_Controls.Controls.FunelChartItem();
            HZH_Controls.Controls.FunelChartItem funelChartItem97 = new HZH_Controls.Controls.FunelChartItem();
            HZH_Controls.Controls.FunelChartItem funelChartItem98 = new HZH_Controls.Controls.FunelChartItem();
            HZH_Controls.Controls.FunelChartItem funelChartItem99 = new HZH_Controls.Controls.FunelChartItem();
            HZH_Controls.Controls.FunelChartItem funelChartItem100 = new HZH_Controls.Controls.FunelChartItem();
            HZH_Controls.Controls.FunelChartItem funelChartItem101 = new HZH_Controls.Controls.FunelChartItem();
            HZH_Controls.Controls.FunelChartItem funelChartItem102 = new HZH_Controls.Controls.FunelChartItem();
            HZH_Controls.Controls.FunelChartItem funelChartItem103 = new HZH_Controls.Controls.FunelChartItem();
            HZH_Controls.Controls.FunelChartItem funelChartItem104 = new HZH_Controls.Controls.FunelChartItem();
            HZH_Controls.Controls.FunelChartItem funelChartItem105 = new HZH_Controls.Controls.FunelChartItem();
            HZH_Controls.Controls.FunelChartItem funelChartItem106 = new HZH_Controls.Controls.FunelChartItem();
            HZH_Controls.Controls.FunelChartItem funelChartItem107 = new HZH_Controls.Controls.FunelChartItem();
            HZH_Controls.Controls.FunelChartItem funelChartItem108 = new HZH_Controls.Controls.FunelChartItem();
            HZH_Controls.Controls.FunelChartItem funelChartItem109 = new HZH_Controls.Controls.FunelChartItem();
            HZH_Controls.Controls.FunelChartItem funelChartItem110 = new HZH_Controls.Controls.FunelChartItem();
            HZH_Controls.Controls.FunelChartItem funelChartItem111 = new HZH_Controls.Controls.FunelChartItem();
            HZH_Controls.Controls.FunelChartItem funelChartItem112 = new HZH_Controls.Controls.FunelChartItem();
            HZH_Controls.Controls.FunelChartItem funelChartItem113 = new HZH_Controls.Controls.FunelChartItem();
            HZH_Controls.Controls.FunelChartItem funelChartItem114 = new HZH_Controls.Controls.FunelChartItem();
            HZH_Controls.Controls.FunelChartItem funelChartItem115 = new HZH_Controls.Controls.FunelChartItem();
            HZH_Controls.Controls.FunelChartItem funelChartItem116 = new HZH_Controls.Controls.FunelChartItem();
            HZH_Controls.Controls.FunelChartItem funelChartItem117 = new HZH_Controls.Controls.FunelChartItem();
            HZH_Controls.Controls.FunelChartItem funelChartItem118 = new HZH_Controls.Controls.FunelChartItem();
            HZH_Controls.Controls.FunelChartItem funelChartItem119 = new HZH_Controls.Controls.FunelChartItem();
            HZH_Controls.Controls.FunelChartItem funelChartItem120 = new HZH_Controls.Controls.FunelChartItem();
            HZH_Controls.Controls.FunelChartItem funelChartItem121 = new HZH_Controls.Controls.FunelChartItem();
            HZH_Controls.Controls.FunelChartItem funelChartItem122 = new HZH_Controls.Controls.FunelChartItem();
            HZH_Controls.Controls.FunelChartItem funelChartItem123 = new HZH_Controls.Controls.FunelChartItem();
            HZH_Controls.Controls.FunelChartItem funelChartItem124 = new HZH_Controls.Controls.FunelChartItem();
            HZH_Controls.Controls.FunelChartItem funelChartItem125 = new HZH_Controls.Controls.FunelChartItem();
            HZH_Controls.Controls.FunelChartItem funelChartItem126 = new HZH_Controls.Controls.FunelChartItem();
            HZH_Controls.Controls.FunelChartItem funelChartItem127 = new HZH_Controls.Controls.FunelChartItem();
            HZH_Controls.Controls.FunelChartItem funelChartItem128 = new HZH_Controls.Controls.FunelChartItem();
            HZH_Controls.Controls.FunelChartItem funelChartItem129 = new HZH_Controls.Controls.FunelChartItem();
            HZH_Controls.Controls.FunelChartItem funelChartItem130 = new HZH_Controls.Controls.FunelChartItem();
            HZH_Controls.Controls.FunelChartItem funelChartItem131 = new HZH_Controls.Controls.FunelChartItem();
            HZH_Controls.Controls.FunelChartItem funelChartItem132 = new HZH_Controls.Controls.FunelChartItem();
            HZH_Controls.Controls.FunelChartItem funelChartItem133 = new HZH_Controls.Controls.FunelChartItem();
            HZH_Controls.Controls.FunelChartItem funelChartItem134 = new HZH_Controls.Controls.FunelChartItem();
            HZH_Controls.Controls.FunelChartItem funelChartItem135 = new HZH_Controls.Controls.FunelChartItem();
            HZH_Controls.Controls.FunelChartItem funelChartItem136 = new HZH_Controls.Controls.FunelChartItem();
            HZH_Controls.Controls.FunelChartItem funelChartItem137 = new HZH_Controls.Controls.FunelChartItem();
            HZH_Controls.Controls.FunelChartItem funelChartItem138 = new HZH_Controls.Controls.FunelChartItem();
            HZH_Controls.Controls.FunelChartItem funelChartItem139 = new HZH_Controls.Controls.FunelChartItem();
            HZH_Controls.Controls.FunelChartItem funelChartItem140 = new HZH_Controls.Controls.FunelChartItem();
            HZH_Controls.Controls.FunelChartItem funelChartItem141 = new HZH_Controls.Controls.FunelChartItem();
            HZH_Controls.Controls.FunelChartItem funelChartItem142 = new HZH_Controls.Controls.FunelChartItem();
            HZH_Controls.Controls.FunelChartItem funelChartItem143 = new HZH_Controls.Controls.FunelChartItem();
            HZH_Controls.Controls.FunelChartItem funelChartItem144 = new HZH_Controls.Controls.FunelChartItem();
            HZH_Controls.Controls.FunelChartItem funelChartItem145 = new HZH_Controls.Controls.FunelChartItem();
            HZH_Controls.Controls.FunelChartItem funelChartItem146 = new HZH_Controls.Controls.FunelChartItem();
            HZH_Controls.Controls.FunelChartItem funelChartItem147 = new HZH_Controls.Controls.FunelChartItem();
            HZH_Controls.Controls.FunelChartItem funelChartItem148 = new HZH_Controls.Controls.FunelChartItem();
            HZH_Controls.Controls.FunelChartItem funelChartItem149 = new HZH_Controls.Controls.FunelChartItem();
            HZH_Controls.Controls.FunelChartItem funelChartItem150 = new HZH_Controls.Controls.FunelChartItem();
            HZH_Controls.Controls.FunelChartItem funelChartItem151 = new HZH_Controls.Controls.FunelChartItem();
            HZH_Controls.Controls.FunelChartItem funelChartItem152 = new HZH_Controls.Controls.FunelChartItem();
            HZH_Controls.Controls.FunelChartItem funelChartItem153 = new HZH_Controls.Controls.FunelChartItem();
            HZH_Controls.Controls.FunelChartItem funelChartItem154 = new HZH_Controls.Controls.FunelChartItem();
            HZH_Controls.Controls.FunelChartItem funelChartItem155 = new HZH_Controls.Controls.FunelChartItem();
            HZH_Controls.Controls.FunelChartItem funelChartItem156 = new HZH_Controls.Controls.FunelChartItem();
            HZH_Controls.Controls.FunelChartItem funelChartItem157 = new HZH_Controls.Controls.FunelChartItem();
            HZH_Controls.Controls.FunelChartItem funelChartItem158 = new HZH_Controls.Controls.FunelChartItem();
            HZH_Controls.Controls.FunelChartItem funelChartItem159 = new HZH_Controls.Controls.FunelChartItem();
            HZH_Controls.Controls.FunelChartItem funelChartItem160 = new HZH_Controls.Controls.FunelChartItem();
            this.ucFunnelChart2 = new HZH_Controls.Controls.UCFunnelChart();
            this.ucFunnelChart1 = new HZH_Controls.Controls.UCFunnelChart();
            this.ucFunnelChart3 = new HZH_Controls.Controls.UCFunnelChart();
            this.ucFunnelChart4 = new HZH_Controls.Controls.UCFunnelChart();
            this.ucFunnelChart5 = new HZH_Controls.Controls.UCFunnelChart();
            this.ucFunnelChart6 = new HZH_Controls.Controls.UCFunnelChart();
            this.ucFunnelChart7 = new HZH_Controls.Controls.UCFunnelChart();
            this.ucFunnelChart8 = new HZH_Controls.Controls.UCFunnelChart();
            this.ucFunnelChart9 = new HZH_Controls.Controls.UCFunnelChart();
            this.ucFunnelChart10 = new HZH_Controls.Controls.UCFunnelChart();
            this.ucFunnelChart11 = new HZH_Controls.Controls.UCFunnelChart();
            this.ucFunnelChart12 = new HZH_Controls.Controls.UCFunnelChart();
            this.ucFunnelChart13 = new HZH_Controls.Controls.UCFunnelChart();
            this.ucFunnelChart14 = new HZH_Controls.Controls.UCFunnelChart();
            this.ucFunnelChart15 = new HZH_Controls.Controls.UCFunnelChart();
            this.ucFunnelChart16 = new HZH_Controls.Controls.UCFunnelChart();
            this.SuspendLayout();
            // 
            // ucFunnelChart2
            // 
            this.ucFunnelChart2.Alignment = HZH_Controls.Controls.FunelChartAlignment.Center;
            this.ucFunnelChart2.Direction = HZH_Controls.Controls.FunelChartDirection.Down;
            this.ucFunnelChart2.Font = new System.Drawing.Font("微软雅黑", 8F);
            this.ucFunnelChart2.ForeColor = System.Drawing.Color.Black;
            funelChartItem81.Text = "item0";
            funelChartItem81.TextForeColor = null;
            funelChartItem81.Value = 10F;
            funelChartItem81.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(162)))), ((int)(((byte)(218)))));
            funelChartItem82.Text = "item1";
            funelChartItem82.TextForeColor = null;
            funelChartItem82.Value = 20F;
            funelChartItem82.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(197)))), ((int)(((byte)(233)))));
            funelChartItem83.Text = "item2";
            funelChartItem83.TextForeColor = null;
            funelChartItem83.Value = 30F;
            funelChartItem83.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(224)))), ((int)(((byte)(227)))));
            funelChartItem84.Text = "item3";
            funelChartItem84.TextForeColor = null;
            funelChartItem84.Value = 40F;
            funelChartItem84.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(159)))), ((int)(((byte)(230)))), ((int)(((byte)(184)))));
            funelChartItem85.Text = "item4";
            funelChartItem85.TextForeColor = null;
            funelChartItem85.Value = 50F;
            funelChartItem85.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(219)))), ((int)(((byte)(92)))));
            this.ucFunnelChart2.Items = new HZH_Controls.Controls.FunelChartItem[] {
        funelChartItem81,
        funelChartItem82,
        funelChartItem83,
        funelChartItem84,
        funelChartItem85};
            this.ucFunnelChart2.ItemTextAlign = HZH_Controls.Controls.FunelChartAlignment.Right;
            this.ucFunnelChart2.Location = new System.Drawing.Point(15, 269);
            this.ucFunnelChart2.Name = "ucFunnelChart2";
            this.ucFunnelChart2.ShowValue = false;
            this.ucFunnelChart2.Size = new System.Drawing.Size(242, 244);
            this.ucFunnelChart2.TabIndex = 0;
            this.ucFunnelChart2.Title = null;
            this.ucFunnelChart2.TitleFont = new System.Drawing.Font("微软雅黑", 12F);
            this.ucFunnelChart2.TitleForeColor = System.Drawing.Color.Black;
            this.ucFunnelChart2.ValueFormat = "0.##";
            // 
            // ucFunnelChart1
            // 
            this.ucFunnelChart1.Alignment = HZH_Controls.Controls.FunelChartAlignment.Center;
            this.ucFunnelChart1.Direction = HZH_Controls.Controls.FunelChartDirection.UP;
            this.ucFunnelChart1.Font = new System.Drawing.Font("微软雅黑", 8F);
            this.ucFunnelChart1.ForeColor = System.Drawing.Color.Black;
            funelChartItem86.Text = "item0";
            funelChartItem86.TextForeColor = null;
            funelChartItem86.Value = 10F;
            funelChartItem86.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(162)))), ((int)(((byte)(218)))));
            funelChartItem87.Text = "item1";
            funelChartItem87.TextForeColor = null;
            funelChartItem87.Value = 20F;
            funelChartItem87.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(197)))), ((int)(((byte)(233)))));
            funelChartItem88.Text = "item2";
            funelChartItem88.TextForeColor = null;
            funelChartItem88.Value = 30F;
            funelChartItem88.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(224)))), ((int)(((byte)(227)))));
            funelChartItem89.Text = "item3";
            funelChartItem89.TextForeColor = null;
            funelChartItem89.Value = 40F;
            funelChartItem89.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(159)))), ((int)(((byte)(230)))), ((int)(((byte)(184)))));
            funelChartItem90.Text = "item4";
            funelChartItem90.TextForeColor = null;
            funelChartItem90.Value = 50F;
            funelChartItem90.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(219)))), ((int)(((byte)(92)))));
            this.ucFunnelChart1.Items = new HZH_Controls.Controls.FunelChartItem[] {
        funelChartItem86,
        funelChartItem87,
        funelChartItem88,
        funelChartItem89,
        funelChartItem90};
            this.ucFunnelChart1.ItemTextAlign = HZH_Controls.Controls.FunelChartAlignment.Right;
            this.ucFunnelChart1.Location = new System.Drawing.Point(15, 19);
            this.ucFunnelChart1.Name = "ucFunnelChart1";
            this.ucFunnelChart1.ShowValue = false;
            this.ucFunnelChart1.Size = new System.Drawing.Size(242, 244);
            this.ucFunnelChart1.TabIndex = 0;
            this.ucFunnelChart1.Title = null;
            this.ucFunnelChart1.TitleFont = new System.Drawing.Font("微软雅黑", 12F);
            this.ucFunnelChart1.TitleForeColor = System.Drawing.Color.Black;
            this.ucFunnelChart1.ValueFormat = "0.##";
            // 
            // ucFunnelChart3
            // 
            this.ucFunnelChart3.Alignment = HZH_Controls.Controls.FunelChartAlignment.Left;
            this.ucFunnelChart3.Direction = HZH_Controls.Controls.FunelChartDirection.UP;
            this.ucFunnelChart3.Font = new System.Drawing.Font("微软雅黑", 8F);
            this.ucFunnelChart3.ForeColor = System.Drawing.Color.Black;
            funelChartItem91.Text = "item0";
            funelChartItem91.TextForeColor = null;
            funelChartItem91.Value = 10F;
            funelChartItem91.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(162)))), ((int)(((byte)(218)))));
            funelChartItem92.Text = "item1";
            funelChartItem92.TextForeColor = null;
            funelChartItem92.Value = 20F;
            funelChartItem92.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(197)))), ((int)(((byte)(233)))));
            funelChartItem93.Text = "item2";
            funelChartItem93.TextForeColor = null;
            funelChartItem93.Value = 30F;
            funelChartItem93.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(224)))), ((int)(((byte)(227)))));
            funelChartItem94.Text = "item3";
            funelChartItem94.TextForeColor = null;
            funelChartItem94.Value = 40F;
            funelChartItem94.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(159)))), ((int)(((byte)(230)))), ((int)(((byte)(184)))));
            funelChartItem95.Text = "item4";
            funelChartItem95.TextForeColor = null;
            funelChartItem95.Value = 50F;
            funelChartItem95.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(219)))), ((int)(((byte)(92)))));
            this.ucFunnelChart3.Items = new HZH_Controls.Controls.FunelChartItem[] {
        funelChartItem91,
        funelChartItem92,
        funelChartItem93,
        funelChartItem94,
        funelChartItem95};
            this.ucFunnelChart3.ItemTextAlign = HZH_Controls.Controls.FunelChartAlignment.Right;
            this.ucFunnelChart3.Location = new System.Drawing.Point(263, 19);
            this.ucFunnelChart3.Name = "ucFunnelChart3";
            this.ucFunnelChart3.ShowValue = false;
            this.ucFunnelChart3.Size = new System.Drawing.Size(242, 244);
            this.ucFunnelChart3.TabIndex = 0;
            this.ucFunnelChart3.Title = null;
            this.ucFunnelChart3.TitleFont = new System.Drawing.Font("微软雅黑", 12F);
            this.ucFunnelChart3.TitleForeColor = System.Drawing.Color.Black;
            this.ucFunnelChart3.ValueFormat = "0.##";
            // 
            // ucFunnelChart4
            // 
            this.ucFunnelChart4.Alignment = HZH_Controls.Controls.FunelChartAlignment.Left;
            this.ucFunnelChart4.Direction = HZH_Controls.Controls.FunelChartDirection.Down;
            this.ucFunnelChart4.Font = new System.Drawing.Font("微软雅黑", 8F);
            this.ucFunnelChart4.ForeColor = System.Drawing.Color.Black;
            funelChartItem96.Text = "item0";
            funelChartItem96.TextForeColor = null;
            funelChartItem96.Value = 10F;
            funelChartItem96.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(162)))), ((int)(((byte)(218)))));
            funelChartItem97.Text = "item1";
            funelChartItem97.TextForeColor = null;
            funelChartItem97.Value = 20F;
            funelChartItem97.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(197)))), ((int)(((byte)(233)))));
            funelChartItem98.Text = "item2";
            funelChartItem98.TextForeColor = null;
            funelChartItem98.Value = 30F;
            funelChartItem98.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(224)))), ((int)(((byte)(227)))));
            funelChartItem99.Text = "item3";
            funelChartItem99.TextForeColor = null;
            funelChartItem99.Value = 40F;
            funelChartItem99.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(159)))), ((int)(((byte)(230)))), ((int)(((byte)(184)))));
            funelChartItem100.Text = "item4";
            funelChartItem100.TextForeColor = null;
            funelChartItem100.Value = 50F;
            funelChartItem100.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(219)))), ((int)(((byte)(92)))));
            this.ucFunnelChart4.Items = new HZH_Controls.Controls.FunelChartItem[] {
        funelChartItem96,
        funelChartItem97,
        funelChartItem98,
        funelChartItem99,
        funelChartItem100};
            this.ucFunnelChart4.ItemTextAlign = HZH_Controls.Controls.FunelChartAlignment.Right;
            this.ucFunnelChart4.Location = new System.Drawing.Point(263, 269);
            this.ucFunnelChart4.Name = "ucFunnelChart4";
            this.ucFunnelChart4.ShowValue = false;
            this.ucFunnelChart4.Size = new System.Drawing.Size(242, 244);
            this.ucFunnelChart4.TabIndex = 0;
            this.ucFunnelChart4.Title = null;
            this.ucFunnelChart4.TitleFont = new System.Drawing.Font("微软雅黑", 12F);
            this.ucFunnelChart4.TitleForeColor = System.Drawing.Color.Black;
            this.ucFunnelChart4.ValueFormat = "0.##";
            // 
            // ucFunnelChart5
            // 
            this.ucFunnelChart5.Alignment = HZH_Controls.Controls.FunelChartAlignment.Right;
            this.ucFunnelChart5.Direction = HZH_Controls.Controls.FunelChartDirection.UP;
            this.ucFunnelChart5.Font = new System.Drawing.Font("微软雅黑", 8F);
            this.ucFunnelChart5.ForeColor = System.Drawing.Color.Black;
            funelChartItem101.Text = "item0";
            funelChartItem101.TextForeColor = null;
            funelChartItem101.Value = 10F;
            funelChartItem101.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(162)))), ((int)(((byte)(218)))));
            funelChartItem102.Text = "item1";
            funelChartItem102.TextForeColor = null;
            funelChartItem102.Value = 20F;
            funelChartItem102.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(197)))), ((int)(((byte)(233)))));
            funelChartItem103.Text = "item2";
            funelChartItem103.TextForeColor = null;
            funelChartItem103.Value = 30F;
            funelChartItem103.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(224)))), ((int)(((byte)(227)))));
            funelChartItem104.Text = "item3";
            funelChartItem104.TextForeColor = null;
            funelChartItem104.Value = 40F;
            funelChartItem104.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(159)))), ((int)(((byte)(230)))), ((int)(((byte)(184)))));
            funelChartItem105.Text = "item4";
            funelChartItem105.TextForeColor = null;
            funelChartItem105.Value = 50F;
            funelChartItem105.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(219)))), ((int)(((byte)(92)))));
            this.ucFunnelChart5.Items = new HZH_Controls.Controls.FunelChartItem[] {
        funelChartItem101,
        funelChartItem102,
        funelChartItem103,
        funelChartItem104,
        funelChartItem105};
            this.ucFunnelChart5.ItemTextAlign = HZH_Controls.Controls.FunelChartAlignment.Left;
            this.ucFunnelChart5.Location = new System.Drawing.Point(511, 19);
            this.ucFunnelChart5.Name = "ucFunnelChart5";
            this.ucFunnelChart5.ShowValue = false;
            this.ucFunnelChart5.Size = new System.Drawing.Size(242, 244);
            this.ucFunnelChart5.TabIndex = 0;
            this.ucFunnelChart5.Title = null;
            this.ucFunnelChart5.TitleFont = new System.Drawing.Font("微软雅黑", 12F);
            this.ucFunnelChart5.TitleForeColor = System.Drawing.Color.Black;
            this.ucFunnelChart5.ValueFormat = "0.##";
            // 
            // ucFunnelChart6
            // 
            this.ucFunnelChart6.Alignment = HZH_Controls.Controls.FunelChartAlignment.Right;
            this.ucFunnelChart6.Direction = HZH_Controls.Controls.FunelChartDirection.Down;
            this.ucFunnelChart6.Font = new System.Drawing.Font("微软雅黑", 8F);
            this.ucFunnelChart6.ForeColor = System.Drawing.Color.Black;
            funelChartItem106.Text = "item0";
            funelChartItem106.TextForeColor = null;
            funelChartItem106.Value = 10F;
            funelChartItem106.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(162)))), ((int)(((byte)(218)))));
            funelChartItem107.Text = "item1";
            funelChartItem107.TextForeColor = null;
            funelChartItem107.Value = 20F;
            funelChartItem107.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(197)))), ((int)(((byte)(233)))));
            funelChartItem108.Text = "item2";
            funelChartItem108.TextForeColor = null;
            funelChartItem108.Value = 30F;
            funelChartItem108.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(224)))), ((int)(((byte)(227)))));
            funelChartItem109.Text = "item3";
            funelChartItem109.TextForeColor = null;
            funelChartItem109.Value = 40F;
            funelChartItem109.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(159)))), ((int)(((byte)(230)))), ((int)(((byte)(184)))));
            funelChartItem110.Text = "item4";
            funelChartItem110.TextForeColor = null;
            funelChartItem110.Value = 50F;
            funelChartItem110.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(219)))), ((int)(((byte)(92)))));
            this.ucFunnelChart6.Items = new HZH_Controls.Controls.FunelChartItem[] {
        funelChartItem106,
        funelChartItem107,
        funelChartItem108,
        funelChartItem109,
        funelChartItem110};
            this.ucFunnelChart6.ItemTextAlign = HZH_Controls.Controls.FunelChartAlignment.Left;
            this.ucFunnelChart6.Location = new System.Drawing.Point(511, 269);
            this.ucFunnelChart6.Name = "ucFunnelChart6";
            this.ucFunnelChart6.ShowValue = false;
            this.ucFunnelChart6.Size = new System.Drawing.Size(242, 244);
            this.ucFunnelChart6.TabIndex = 0;
            this.ucFunnelChart6.Title = null;
            this.ucFunnelChart6.TitleFont = new System.Drawing.Font("微软雅黑", 12F);
            this.ucFunnelChart6.TitleForeColor = System.Drawing.Color.Black;
            this.ucFunnelChart6.ValueFormat = "0.##";
            // 
            // ucFunnelChart7
            // 
            this.ucFunnelChart7.Alignment = HZH_Controls.Controls.FunelChartAlignment.Right;
            this.ucFunnelChart7.Direction = HZH_Controls.Controls.FunelChartDirection.Down;
            this.ucFunnelChart7.Font = new System.Drawing.Font("微软雅黑", 8F);
            this.ucFunnelChart7.ForeColor = System.Drawing.Color.Black;
            funelChartItem111.Text = "item0";
            funelChartItem111.TextForeColor = null;
            funelChartItem111.Value = 10F;
            funelChartItem111.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(162)))), ((int)(((byte)(218)))));
            funelChartItem112.Text = "item1";
            funelChartItem112.TextForeColor = null;
            funelChartItem112.Value = 20F;
            funelChartItem112.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(197)))), ((int)(((byte)(233)))));
            funelChartItem113.Text = "item2";
            funelChartItem113.TextForeColor = null;
            funelChartItem113.Value = 30F;
            funelChartItem113.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(224)))), ((int)(((byte)(227)))));
            funelChartItem114.Text = "item3";
            funelChartItem114.TextForeColor = null;
            funelChartItem114.Value = 40F;
            funelChartItem114.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(159)))), ((int)(((byte)(230)))), ((int)(((byte)(184)))));
            funelChartItem115.Text = "item4";
            funelChartItem115.TextForeColor = null;
            funelChartItem115.Value = 50F;
            funelChartItem115.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(219)))), ((int)(((byte)(92)))));
            this.ucFunnelChart7.Items = new HZH_Controls.Controls.FunelChartItem[] {
        funelChartItem111,
        funelChartItem112,
        funelChartItem113,
        funelChartItem114,
        funelChartItem115};
            this.ucFunnelChart7.ItemTextAlign = HZH_Controls.Controls.FunelChartAlignment.Left;
            this.ucFunnelChart7.Location = new System.Drawing.Point(759, 19);
            this.ucFunnelChart7.Name = "ucFunnelChart7";
            this.ucFunnelChart7.ShowValue = false;
            this.ucFunnelChart7.Size = new System.Drawing.Size(242, 244);
            this.ucFunnelChart7.TabIndex = 0;
            this.ucFunnelChart7.Title = null;
            this.ucFunnelChart7.TitleFont = new System.Drawing.Font("微软雅黑", 12F);
            this.ucFunnelChart7.TitleForeColor = System.Drawing.Color.Black;
            this.ucFunnelChart7.ValueFormat = "0.##";
            // 
            // ucFunnelChart8
            // 
            this.ucFunnelChart8.Alignment = HZH_Controls.Controls.FunelChartAlignment.Right;
            this.ucFunnelChart8.Direction = HZH_Controls.Controls.FunelChartDirection.UP;
            this.ucFunnelChart8.Font = new System.Drawing.Font("微软雅黑", 8F);
            this.ucFunnelChart8.ForeColor = System.Drawing.Color.Black;
            funelChartItem116.Text = "item0";
            funelChartItem116.TextForeColor = null;
            funelChartItem116.Value = 10F;
            funelChartItem116.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(162)))), ((int)(((byte)(218)))));
            funelChartItem117.Text = "item1";
            funelChartItem117.TextForeColor = null;
            funelChartItem117.Value = 20F;
            funelChartItem117.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(197)))), ((int)(((byte)(233)))));
            funelChartItem118.Text = "item2";
            funelChartItem118.TextForeColor = null;
            funelChartItem118.Value = 30F;
            funelChartItem118.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(224)))), ((int)(((byte)(227)))));
            funelChartItem119.Text = "item3";
            funelChartItem119.TextForeColor = null;
            funelChartItem119.Value = 40F;
            funelChartItem119.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(159)))), ((int)(((byte)(230)))), ((int)(((byte)(184)))));
            funelChartItem120.Text = "item4";
            funelChartItem120.TextForeColor = null;
            funelChartItem120.Value = 50F;
            funelChartItem120.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(219)))), ((int)(((byte)(92)))));
            this.ucFunnelChart8.Items = new HZH_Controls.Controls.FunelChartItem[] {
        funelChartItem116,
        funelChartItem117,
        funelChartItem118,
        funelChartItem119,
        funelChartItem120};
            this.ucFunnelChart8.ItemTextAlign = HZH_Controls.Controls.FunelChartAlignment.Left;
            this.ucFunnelChart8.Location = new System.Drawing.Point(759, 269);
            this.ucFunnelChart8.Name = "ucFunnelChart8";
            this.ucFunnelChart8.ShowValue = false;
            this.ucFunnelChart8.Size = new System.Drawing.Size(242, 244);
            this.ucFunnelChart8.TabIndex = 0;
            this.ucFunnelChart8.Title = null;
            this.ucFunnelChart8.TitleFont = new System.Drawing.Font("微软雅黑", 12F);
            this.ucFunnelChart8.TitleForeColor = System.Drawing.Color.Black;
            this.ucFunnelChart8.ValueFormat = "0.##";
            // 
            // ucFunnelChart9
            // 
            this.ucFunnelChart9.Alignment = HZH_Controls.Controls.FunelChartAlignment.Center;
            this.ucFunnelChart9.Direction = HZH_Controls.Controls.FunelChartDirection.UP;
            this.ucFunnelChart9.Font = new System.Drawing.Font("微软雅黑", 8F);
            this.ucFunnelChart9.ForeColor = System.Drawing.Color.Black;
            funelChartItem121.Text = "产品A";
            funelChartItem121.TextForeColor = null;
            funelChartItem121.Value = 10F;
            funelChartItem121.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(162)))), ((int)(((byte)(218)))));
            funelChartItem122.Text = "产品B";
            funelChartItem122.TextForeColor = null;
            funelChartItem122.Value = 30F;
            funelChartItem122.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(197)))), ((int)(((byte)(233)))));
            funelChartItem123.Text = "产品C";
            funelChartItem123.TextForeColor = null;
            funelChartItem123.Value = 60F;
            funelChartItem123.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(224)))), ((int)(((byte)(227)))));
            funelChartItem124.Text = "产品D";
            funelChartItem124.TextForeColor = null;
            funelChartItem124.Value = 80F;
            funelChartItem124.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(159)))), ((int)(((byte)(230)))), ((int)(((byte)(184)))));
            funelChartItem125.Text = "产品E";
            funelChartItem125.TextForeColor = null;
            funelChartItem125.Value = 100F;
            funelChartItem125.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(219)))), ((int)(((byte)(92)))));
            this.ucFunnelChart9.Items = new HZH_Controls.Controls.FunelChartItem[] {
        funelChartItem121,
        funelChartItem122,
        funelChartItem123,
        funelChartItem124,
        funelChartItem125};
            this.ucFunnelChart9.ItemTextAlign = HZH_Controls.Controls.FunelChartAlignment.Right;
            this.ucFunnelChart9.Location = new System.Drawing.Point(15, 535);
            this.ucFunnelChart9.Name = "ucFunnelChart9";
            this.ucFunnelChart9.ShowValue = false;
            this.ucFunnelChart9.Size = new System.Drawing.Size(242, 244);
            this.ucFunnelChart9.TabIndex = 0;
            this.ucFunnelChart9.Title = null;
            this.ucFunnelChart9.TitleFont = new System.Drawing.Font("微软雅黑", 12F);
            this.ucFunnelChart9.TitleForeColor = System.Drawing.Color.Black;
            this.ucFunnelChart9.ValueFormat = "0.##";
            // 
            // ucFunnelChart10
            // 
            this.ucFunnelChart10.Alignment = HZH_Controls.Controls.FunelChartAlignment.Left;
            this.ucFunnelChart10.Direction = HZH_Controls.Controls.FunelChartDirection.UP;
            this.ucFunnelChart10.Font = new System.Drawing.Font("微软雅黑", 8F);
            this.ucFunnelChart10.ForeColor = System.Drawing.Color.Black;
            funelChartItem126.Text = "item0";
            funelChartItem126.TextForeColor = null;
            funelChartItem126.Value = 10F;
            funelChartItem126.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(162)))), ((int)(((byte)(218)))));
            funelChartItem127.Text = "item1";
            funelChartItem127.TextForeColor = null;
            funelChartItem127.Value = 30F;
            funelChartItem127.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(197)))), ((int)(((byte)(233)))));
            funelChartItem128.Text = "item2";
            funelChartItem128.TextForeColor = null;
            funelChartItem128.Value = 60F;
            funelChartItem128.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(224)))), ((int)(((byte)(227)))));
            funelChartItem129.Text = "item3";
            funelChartItem129.TextForeColor = null;
            funelChartItem129.Value = 80F;
            funelChartItem129.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(159)))), ((int)(((byte)(230)))), ((int)(((byte)(184)))));
            funelChartItem130.Text = "item4";
            funelChartItem130.TextForeColor = null;
            funelChartItem130.Value = 100F;
            funelChartItem130.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(219)))), ((int)(((byte)(92)))));
            this.ucFunnelChart10.Items = new HZH_Controls.Controls.FunelChartItem[] {
        funelChartItem126,
        funelChartItem127,
        funelChartItem128,
        funelChartItem129,
        funelChartItem130};
            this.ucFunnelChart10.ItemTextAlign = HZH_Controls.Controls.FunelChartAlignment.Right;
            this.ucFunnelChart10.Location = new System.Drawing.Point(263, 535);
            this.ucFunnelChart10.Name = "ucFunnelChart10";
            this.ucFunnelChart10.ShowValue = false;
            this.ucFunnelChart10.Size = new System.Drawing.Size(242, 244);
            this.ucFunnelChart10.TabIndex = 0;
            this.ucFunnelChart10.Title = null;
            this.ucFunnelChart10.TitleFont = new System.Drawing.Font("微软雅黑", 12F);
            this.ucFunnelChart10.TitleForeColor = System.Drawing.Color.Black;
            this.ucFunnelChart10.ValueFormat = "0.##";
            // 
            // ucFunnelChart11
            // 
            this.ucFunnelChart11.Alignment = HZH_Controls.Controls.FunelChartAlignment.Right;
            this.ucFunnelChart11.Direction = HZH_Controls.Controls.FunelChartDirection.UP;
            this.ucFunnelChart11.Font = new System.Drawing.Font("微软雅黑", 8F);
            this.ucFunnelChart11.ForeColor = System.Drawing.Color.Black;
            funelChartItem131.Text = "item0";
            funelChartItem131.TextForeColor = null;
            funelChartItem131.Value = 10F;
            funelChartItem131.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(162)))), ((int)(((byte)(218)))));
            funelChartItem132.Text = "item1";
            funelChartItem132.TextForeColor = null;
            funelChartItem132.Value = 30F;
            funelChartItem132.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(197)))), ((int)(((byte)(233)))));
            funelChartItem133.Text = "item2";
            funelChartItem133.TextForeColor = null;
            funelChartItem133.Value = 60F;
            funelChartItem133.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(224)))), ((int)(((byte)(227)))));
            funelChartItem134.Text = "item3";
            funelChartItem134.TextForeColor = null;
            funelChartItem134.Value = 80F;
            funelChartItem134.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(159)))), ((int)(((byte)(230)))), ((int)(((byte)(184)))));
            funelChartItem135.Text = "item4";
            funelChartItem135.TextForeColor = null;
            funelChartItem135.Value = 100F;
            funelChartItem135.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(219)))), ((int)(((byte)(92)))));
            this.ucFunnelChart11.Items = new HZH_Controls.Controls.FunelChartItem[] {
        funelChartItem131,
        funelChartItem132,
        funelChartItem133,
        funelChartItem134,
        funelChartItem135};
            this.ucFunnelChart11.ItemTextAlign = HZH_Controls.Controls.FunelChartAlignment.Left;
            this.ucFunnelChart11.Location = new System.Drawing.Point(511, 535);
            this.ucFunnelChart11.Name = "ucFunnelChart11";
            this.ucFunnelChart11.ShowValue = false;
            this.ucFunnelChart11.Size = new System.Drawing.Size(242, 244);
            this.ucFunnelChart11.TabIndex = 0;
            this.ucFunnelChart11.Title = null;
            this.ucFunnelChart11.TitleFont = new System.Drawing.Font("微软雅黑", 12F);
            this.ucFunnelChart11.TitleForeColor = System.Drawing.Color.Black;
            this.ucFunnelChart11.ValueFormat = "0.##";
            // 
            // ucFunnelChart12
            // 
            this.ucFunnelChart12.Alignment = HZH_Controls.Controls.FunelChartAlignment.Center;
            this.ucFunnelChart12.Direction = HZH_Controls.Controls.FunelChartDirection.Down;
            this.ucFunnelChart12.Font = new System.Drawing.Font("微软雅黑", 8F);
            this.ucFunnelChart12.ForeColor = System.Drawing.Color.Black;
            funelChartItem136.Text = "item0";
            funelChartItem136.TextForeColor = null;
            funelChartItem136.Value = 10F;
            funelChartItem136.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(162)))), ((int)(((byte)(218)))));
            funelChartItem137.Text = "item1";
            funelChartItem137.TextForeColor = null;
            funelChartItem137.Value = 30F;
            funelChartItem137.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(197)))), ((int)(((byte)(233)))));
            funelChartItem138.Text = "item2";
            funelChartItem138.TextForeColor = null;
            funelChartItem138.Value = 60F;
            funelChartItem138.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(224)))), ((int)(((byte)(227)))));
            funelChartItem139.Text = "item3";
            funelChartItem139.TextForeColor = null;
            funelChartItem139.Value = 80F;
            funelChartItem139.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(159)))), ((int)(((byte)(230)))), ((int)(((byte)(184)))));
            funelChartItem140.Text = "item4";
            funelChartItem140.TextForeColor = null;
            funelChartItem140.Value = 100F;
            funelChartItem140.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(219)))), ((int)(((byte)(92)))));
            this.ucFunnelChart12.Items = new HZH_Controls.Controls.FunelChartItem[] {
        funelChartItem136,
        funelChartItem137,
        funelChartItem138,
        funelChartItem139,
        funelChartItem140};
            this.ucFunnelChart12.ItemTextAlign = HZH_Controls.Controls.FunelChartAlignment.Right;
            this.ucFunnelChart12.Location = new System.Drawing.Point(15, 785);
            this.ucFunnelChart12.Name = "ucFunnelChart12";
            this.ucFunnelChart12.ShowValue = false;
            this.ucFunnelChart12.Size = new System.Drawing.Size(242, 244);
            this.ucFunnelChart12.TabIndex = 0;
            this.ucFunnelChart12.Title = null;
            this.ucFunnelChart12.TitleFont = new System.Drawing.Font("微软雅黑", 12F);
            this.ucFunnelChart12.TitleForeColor = System.Drawing.Color.Black;
            this.ucFunnelChart12.ValueFormat = "0.##";
            // 
            // ucFunnelChart13
            // 
            this.ucFunnelChart13.Alignment = HZH_Controls.Controls.FunelChartAlignment.Right;
            this.ucFunnelChart13.Direction = HZH_Controls.Controls.FunelChartDirection.Down;
            this.ucFunnelChart13.Font = new System.Drawing.Font("微软雅黑", 8F);
            this.ucFunnelChart13.ForeColor = System.Drawing.Color.Black;
            funelChartItem141.Text = "item0";
            funelChartItem141.TextForeColor = null;
            funelChartItem141.Value = 10F;
            funelChartItem141.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(162)))), ((int)(((byte)(218)))));
            funelChartItem142.Text = "item1";
            funelChartItem142.TextForeColor = null;
            funelChartItem142.Value = 30F;
            funelChartItem142.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(197)))), ((int)(((byte)(233)))));
            funelChartItem143.Text = "item2";
            funelChartItem143.TextForeColor = null;
            funelChartItem143.Value = 60F;
            funelChartItem143.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(224)))), ((int)(((byte)(227)))));
            funelChartItem144.Text = "item3";
            funelChartItem144.TextForeColor = null;
            funelChartItem144.Value = 80F;
            funelChartItem144.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(159)))), ((int)(((byte)(230)))), ((int)(((byte)(184)))));
            funelChartItem145.Text = "item4";
            funelChartItem145.TextForeColor = null;
            funelChartItem145.Value = 100F;
            funelChartItem145.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(219)))), ((int)(((byte)(92)))));
            this.ucFunnelChart13.Items = new HZH_Controls.Controls.FunelChartItem[] {
        funelChartItem141,
        funelChartItem142,
        funelChartItem143,
        funelChartItem144,
        funelChartItem145};
            this.ucFunnelChart13.ItemTextAlign = HZH_Controls.Controls.FunelChartAlignment.Left;
            this.ucFunnelChart13.Location = new System.Drawing.Point(759, 535);
            this.ucFunnelChart13.Name = "ucFunnelChart13";
            this.ucFunnelChart13.ShowValue = false;
            this.ucFunnelChart13.Size = new System.Drawing.Size(242, 244);
            this.ucFunnelChart13.TabIndex = 0;
            this.ucFunnelChart13.Title = null;
            this.ucFunnelChart13.TitleFont = new System.Drawing.Font("微软雅黑", 12F);
            this.ucFunnelChart13.TitleForeColor = System.Drawing.Color.Black;
            this.ucFunnelChart13.ValueFormat = "0.##";
            // 
            // ucFunnelChart14
            // 
            this.ucFunnelChart14.Alignment = HZH_Controls.Controls.FunelChartAlignment.Left;
            this.ucFunnelChart14.Direction = HZH_Controls.Controls.FunelChartDirection.Down;
            this.ucFunnelChart14.Font = new System.Drawing.Font("微软雅黑", 8F);
            this.ucFunnelChart14.ForeColor = System.Drawing.Color.Black;
            funelChartItem146.Text = "item0";
            funelChartItem146.TextForeColor = null;
            funelChartItem146.Value = 10F;
            funelChartItem146.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(162)))), ((int)(((byte)(218)))));
            funelChartItem147.Text = "item1";
            funelChartItem147.TextForeColor = null;
            funelChartItem147.Value = 30F;
            funelChartItem147.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(197)))), ((int)(((byte)(233)))));
            funelChartItem148.Text = "item2";
            funelChartItem148.TextForeColor = null;
            funelChartItem148.Value = 60F;
            funelChartItem148.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(224)))), ((int)(((byte)(227)))));
            funelChartItem149.Text = "item3";
            funelChartItem149.TextForeColor = null;
            funelChartItem149.Value = 80F;
            funelChartItem149.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(159)))), ((int)(((byte)(230)))), ((int)(((byte)(184)))));
            funelChartItem150.Text = "item4";
            funelChartItem150.TextForeColor = null;
            funelChartItem150.Value = 100F;
            funelChartItem150.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(219)))), ((int)(((byte)(92)))));
            this.ucFunnelChart14.Items = new HZH_Controls.Controls.FunelChartItem[] {
        funelChartItem146,
        funelChartItem147,
        funelChartItem148,
        funelChartItem149,
        funelChartItem150};
            this.ucFunnelChart14.ItemTextAlign = HZH_Controls.Controls.FunelChartAlignment.Right;
            this.ucFunnelChart14.Location = new System.Drawing.Point(263, 785);
            this.ucFunnelChart14.Name = "ucFunnelChart14";
            this.ucFunnelChart14.ShowValue = false;
            this.ucFunnelChart14.Size = new System.Drawing.Size(242, 244);
            this.ucFunnelChart14.TabIndex = 0;
            this.ucFunnelChart14.Title = null;
            this.ucFunnelChart14.TitleFont = new System.Drawing.Font("微软雅黑", 12F);
            this.ucFunnelChart14.TitleForeColor = System.Drawing.Color.Black;
            this.ucFunnelChart14.ValueFormat = "0.##";
            // 
            // ucFunnelChart15
            // 
            this.ucFunnelChart15.Alignment = HZH_Controls.Controls.FunelChartAlignment.Right;
            this.ucFunnelChart15.Direction = HZH_Controls.Controls.FunelChartDirection.Down;
            this.ucFunnelChart15.Font = new System.Drawing.Font("微软雅黑", 8F);
            this.ucFunnelChart15.ForeColor = System.Drawing.Color.Black;
            funelChartItem151.Text = "item0";
            funelChartItem151.TextForeColor = null;
            funelChartItem151.Value = 10F;
            funelChartItem151.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(162)))), ((int)(((byte)(218)))));
            funelChartItem152.Text = "item1";
            funelChartItem152.TextForeColor = null;
            funelChartItem152.Value = 30F;
            funelChartItem152.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(197)))), ((int)(((byte)(233)))));
            funelChartItem153.Text = "item2";
            funelChartItem153.TextForeColor = null;
            funelChartItem153.Value = 60F;
            funelChartItem153.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(224)))), ((int)(((byte)(227)))));
            funelChartItem154.Text = "item3";
            funelChartItem154.TextForeColor = null;
            funelChartItem154.Value = 80F;
            funelChartItem154.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(159)))), ((int)(((byte)(230)))), ((int)(((byte)(184)))));
            funelChartItem155.Text = "item4";
            funelChartItem155.TextForeColor = null;
            funelChartItem155.Value = 100F;
            funelChartItem155.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(219)))), ((int)(((byte)(92)))));
            this.ucFunnelChart15.Items = new HZH_Controls.Controls.FunelChartItem[] {
        funelChartItem151,
        funelChartItem152,
        funelChartItem153,
        funelChartItem154,
        funelChartItem155};
            this.ucFunnelChart15.ItemTextAlign = HZH_Controls.Controls.FunelChartAlignment.Left;
            this.ucFunnelChart15.Location = new System.Drawing.Point(511, 785);
            this.ucFunnelChart15.Name = "ucFunnelChart15";
            this.ucFunnelChart15.ShowValue = false;
            this.ucFunnelChart15.Size = new System.Drawing.Size(242, 244);
            this.ucFunnelChart15.TabIndex = 0;
            this.ucFunnelChart15.Title = null;
            this.ucFunnelChart15.TitleFont = new System.Drawing.Font("微软雅黑", 12F);
            this.ucFunnelChart15.TitleForeColor = System.Drawing.Color.Black;
            this.ucFunnelChart15.ValueFormat = "0.##";
            // 
            // ucFunnelChart16
            // 
            this.ucFunnelChart16.Alignment = HZH_Controls.Controls.FunelChartAlignment.Right;
            this.ucFunnelChart16.Direction = HZH_Controls.Controls.FunelChartDirection.UP;
            this.ucFunnelChart16.Font = new System.Drawing.Font("微软雅黑", 8F);
            this.ucFunnelChart16.ForeColor = System.Drawing.Color.Black;
            funelChartItem156.Text = "item0";
            funelChartItem156.TextForeColor = null;
            funelChartItem156.Value = 10F;
            funelChartItem156.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(162)))), ((int)(((byte)(218)))));
            funelChartItem157.Text = "item1";
            funelChartItem157.TextForeColor = null;
            funelChartItem157.Value = 30F;
            funelChartItem157.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(197)))), ((int)(((byte)(233)))));
            funelChartItem158.Text = "item2";
            funelChartItem158.TextForeColor = null;
            funelChartItem158.Value = 60F;
            funelChartItem158.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(224)))), ((int)(((byte)(227)))));
            funelChartItem159.Text = "item3";
            funelChartItem159.TextForeColor = null;
            funelChartItem159.Value = 80F;
            funelChartItem159.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(159)))), ((int)(((byte)(230)))), ((int)(((byte)(184)))));
            funelChartItem160.Text = "item4";
            funelChartItem160.TextForeColor = null;
            funelChartItem160.Value = 100F;
            funelChartItem160.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(219)))), ((int)(((byte)(92)))));
            this.ucFunnelChart16.Items = new HZH_Controls.Controls.FunelChartItem[] {
        funelChartItem156,
        funelChartItem157,
        funelChartItem158,
        funelChartItem159,
        funelChartItem160};
            this.ucFunnelChart16.ItemTextAlign = HZH_Controls.Controls.FunelChartAlignment.Left;
            this.ucFunnelChart16.Location = new System.Drawing.Point(759, 785);
            this.ucFunnelChart16.Name = "ucFunnelChart16";
            this.ucFunnelChart16.ShowValue = false;
            this.ucFunnelChart16.Size = new System.Drawing.Size(242, 244);
            this.ucFunnelChart16.TabIndex = 0;
            this.ucFunnelChart16.Title = null;
            this.ucFunnelChart16.TitleFont = new System.Drawing.Font("微软雅黑", 12F);
            this.ucFunnelChart16.TitleForeColor = System.Drawing.Color.Black;
            this.ucFunnelChart16.ValueFormat = "0.##";
            // 
            // UCTestFunnelChart
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.ucFunnelChart16);
            this.Controls.Add(this.ucFunnelChart8);
            this.Controls.Add(this.ucFunnelChart15);
            this.Controls.Add(this.ucFunnelChart6);
            this.Controls.Add(this.ucFunnelChart14);
            this.Controls.Add(this.ucFunnelChart4);
            this.Controls.Add(this.ucFunnelChart13);
            this.Controls.Add(this.ucFunnelChart7);
            this.Controls.Add(this.ucFunnelChart12);
            this.Controls.Add(this.ucFunnelChart2);
            this.Controls.Add(this.ucFunnelChart11);
            this.Controls.Add(this.ucFunnelChart5);
            this.Controls.Add(this.ucFunnelChart10);
            this.Controls.Add(this.ucFunnelChart3);
            this.Controls.Add(this.ucFunnelChart9);
            this.Controls.Add(this.ucFunnelChart1);
            this.Name = "UCTestFunnelChart";
            this.Size = new System.Drawing.Size(1041, 1082);
            this.ResumeLayout(false);

        }

        #endregion

        private HZH_Controls.Controls.UCFunnelChart ucFunnelChart1;
        private HZH_Controls.Controls.UCFunnelChart ucFunnelChart2;
        private HZH_Controls.Controls.UCFunnelChart ucFunnelChart3;
        private HZH_Controls.Controls.UCFunnelChart ucFunnelChart4;
        private HZH_Controls.Controls.UCFunnelChart ucFunnelChart5;
        private HZH_Controls.Controls.UCFunnelChart ucFunnelChart6;
        private HZH_Controls.Controls.UCFunnelChart ucFunnelChart7;
        private HZH_Controls.Controls.UCFunnelChart ucFunnelChart8;
        private HZH_Controls.Controls.UCFunnelChart ucFunnelChart9;
        private HZH_Controls.Controls.UCFunnelChart ucFunnelChart10;
        private HZH_Controls.Controls.UCFunnelChart ucFunnelChart11;
        private HZH_Controls.Controls.UCFunnelChart ucFunnelChart12;
        private HZH_Controls.Controls.UCFunnelChart ucFunnelChart13;
        private HZH_Controls.Controls.UCFunnelChart ucFunnelChart14;
        private HZH_Controls.Controls.UCFunnelChart ucFunnelChart15;
        private HZH_Controls.Controls.UCFunnelChart ucFunnelChart16;

    }
}
