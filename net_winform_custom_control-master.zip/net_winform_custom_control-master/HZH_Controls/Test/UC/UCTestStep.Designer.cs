﻿namespace Test.UC
{
    partial class UCTestStep
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UCTestStep));
			this.ucStep4 = new HZH_Controls.Controls.UCStep();
			this.ucStep6 = new HZH_Controls.Controls.UCStep();
			this.ucStep5 = new HZH_Controls.Controls.UCStep();
			this.ucStep2 = new HZH_Controls.Controls.UCStep();
			this.ucStep3 = new HZH_Controls.Controls.UCStep();
			this.ucStep1 = new HZH_Controls.Controls.UCStep();
			this.SuspendLayout();
			// 
			// ucStep4
			// 
			this.ucStep4.BackColor = System.Drawing.Color.Transparent;
			this.ucStep4.Font = new System.Drawing.Font("微软雅黑", 12F);
			this.ucStep4.ImgCompleted = null;
			this.ucStep4.LineWidth = 10;
			this.ucStep4.Location = new System.Drawing.Point(409, 133);
			this.ucStep4.Name = "ucStep4";
			this.ucStep4.Size = new System.Drawing.Size(362, 86);
			this.ucStep4.StepBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(189)))), ((int)(((byte)(189)))), ((int)(((byte)(189)))));
			this.ucStep4.StepFontColor = System.Drawing.Color.White;
			this.ucStep4.StepForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(157)))), ((int)(((byte)(144)))));
			this.ucStep4.StepIndex = 2;
			this.ucStep4.Steps = new string[] {
        "step1",
        "step2",
        "step3",
        "step4",
        "step5"};
			this.ucStep4.StepWidth = 35;
			this.ucStep4.TabIndex = 1;
			// 
			// ucStep6
			// 
			this.ucStep6.BackColor = System.Drawing.Color.Transparent;
			this.ucStep6.Font = new System.Drawing.Font("微软雅黑", 12F);
			this.ucStep6.ImgCompleted = null;
			this.ucStep6.LineWidth = 10;
			this.ucStep6.Location = new System.Drawing.Point(29, 340);
			this.ucStep6.Name = "ucStep6";
			this.ucStep6.Size = new System.Drawing.Size(742, 109);
			this.ucStep6.StepBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(189)))), ((int)(((byte)(189)))), ((int)(((byte)(189)))));
			this.ucStep6.StepFontColor = System.Drawing.Color.White;
			this.ucStep6.StepForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(157)))), ((int)(((byte)(144)))));
			this.ucStep6.StepIndex = 2;
			this.ucStep6.Steps = new string[] {
        "step1",
        "step2",
        "step3",
        "step4",
        "step5"};
			this.ucStep6.StepWidth = 35;
			this.ucStep6.TabIndex = 1;
			// 
			// ucStep5
			// 
			this.ucStep5.BackColor = System.Drawing.Color.Transparent;
			this.ucStep5.Font = new System.Drawing.Font("微软雅黑", 12F);
			this.ucStep5.ImgCompleted = null;
			this.ucStep5.LineWidth = 10;
			this.ucStep5.Location = new System.Drawing.Point(29, 225);
			this.ucStep5.Name = "ucStep5";
			this.ucStep5.Size = new System.Drawing.Size(742, 109);
			this.ucStep5.StepBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(189)))), ((int)(((byte)(189)))), ((int)(((byte)(189)))));
			this.ucStep5.StepFontColor = System.Drawing.Color.White;
			this.ucStep5.StepForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
			this.ucStep5.StepIndex = 2;
			this.ucStep5.Steps = new string[] {
        "step1"};
			this.ucStep5.StepWidth = 35;
			this.ucStep5.TabIndex = 1;
			// 
			// ucStep2
			// 
			this.ucStep2.BackColor = System.Drawing.Color.Transparent;
			this.ucStep2.Font = new System.Drawing.Font("微软雅黑", 12F);
			this.ucStep2.ImgCompleted = null;
			this.ucStep2.LineWidth = 10;
			this.ucStep2.Location = new System.Drawing.Point(29, 133);
			this.ucStep2.Name = "ucStep2";
			this.ucStep2.Size = new System.Drawing.Size(362, 86);
			this.ucStep2.StepBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(189)))), ((int)(((byte)(189)))), ((int)(((byte)(189)))));
			this.ucStep2.StepFontColor = System.Drawing.Color.White;
			this.ucStep2.StepForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
			this.ucStep2.StepIndex = 2;
			this.ucStep2.Steps = new string[] {
        "step1",
        "step2",
        "step3",
        "step4",
        "step5"};
			this.ucStep2.StepWidth = 35;
			this.ucStep2.TabIndex = 1;
			// 
			// ucStep3
			// 
			this.ucStep3.BackColor = System.Drawing.Color.Transparent;
			this.ucStep3.Font = new System.Drawing.Font("微软雅黑", 12F);
			this.ucStep3.ImgCompleted = ((System.Drawing.Image)(resources.GetObject("ucStep3.ImgCompleted")));
			this.ucStep3.LineWidth = 10;
			this.ucStep3.Location = new System.Drawing.Point(409, 40);
			this.ucStep3.Name = "ucStep3";
			this.ucStep3.Size = new System.Drawing.Size(362, 77);
			this.ucStep3.StepBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(189)))), ((int)(((byte)(189)))), ((int)(((byte)(189)))));
			this.ucStep3.StepFontColor = System.Drawing.Color.White;
			this.ucStep3.StepForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(157)))), ((int)(((byte)(144)))));
			this.ucStep3.StepIndex = 2;
			this.ucStep3.Steps = new string[] {
        "step1",
        "step2",
        "step3",
        "step4",
        "step5"};
			this.ucStep3.StepWidth = 35;
			this.ucStep3.TabIndex = 2;
			// 
			// ucStep1
			// 
			this.ucStep1.BackColor = System.Drawing.Color.Transparent;
			this.ucStep1.Font = new System.Drawing.Font("微软雅黑", 12F);
			this.ucStep1.ImgCompleted = ((System.Drawing.Image)(resources.GetObject("ucStep1.ImgCompleted")));
			this.ucStep1.LineWidth = 10;
			this.ucStep1.Location = new System.Drawing.Point(29, 40);
			this.ucStep1.Name = "ucStep1";
			this.ucStep1.Size = new System.Drawing.Size(362, 77);
			this.ucStep1.StepBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(189)))), ((int)(((byte)(189)))), ((int)(((byte)(189)))));
			this.ucStep1.StepFontColor = System.Drawing.Color.White;
			this.ucStep1.StepForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
			this.ucStep1.StepIndex = 2;
			this.ucStep1.Steps = new string[] {
        "step1",
        "step2",
        "step3",
        "step4",
        "step5"};
			this.ucStep1.StepWidth = 35;
			this.ucStep1.TabIndex = 2;
			// 
			// UCTestStep
			// 
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
			this.BackColor = System.Drawing.Color.White;
			this.Controls.Add(this.ucStep4);
			this.Controls.Add(this.ucStep6);
			this.Controls.Add(this.ucStep5);
			this.Controls.Add(this.ucStep2);
			this.Controls.Add(this.ucStep3);
			this.Controls.Add(this.ucStep1);
			this.Name = "UCTestStep";
			this.Size = new System.Drawing.Size(1280, 526);
			this.ResumeLayout(false);

        }

        #endregion

        private HZH_Controls.Controls.UCStep ucStep2;
        private HZH_Controls.Controls.UCStep ucStep1;
        private HZH_Controls.Controls.UCStep ucStep3;
        private HZH_Controls.Controls.UCStep ucStep4;
        private HZH_Controls.Controls.UCStep ucStep5;
        private HZH_Controls.Controls.UCStep ucStep6;
    }
}
