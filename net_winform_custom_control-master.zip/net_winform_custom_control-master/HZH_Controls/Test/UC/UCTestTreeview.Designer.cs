﻿namespace Test.UC
{
    partial class UCTestTreeview
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UCTestTreeview));
            System.Windows.Forms.TreeNode treeNode1 = new System.Windows.Forms.TreeNode("节点4");
            System.Windows.Forms.TreeNode treeNode2 = new System.Windows.Forms.TreeNode("节点5");
            System.Windows.Forms.TreeNode treeNode3 = new System.Windows.Forms.TreeNode("节点6");
            System.Windows.Forms.TreeNode treeNode4 = new System.Windows.Forms.TreeNode("节点0", new System.Windows.Forms.TreeNode[] {
            treeNode1,
            treeNode2,
            treeNode3});
            System.Windows.Forms.TreeNode treeNode5 = new System.Windows.Forms.TreeNode("节点7");
            System.Windows.Forms.TreeNode treeNode6 = new System.Windows.Forms.TreeNode("节点8");
            System.Windows.Forms.TreeNode treeNode7 = new System.Windows.Forms.TreeNode("节点9");
            System.Windows.Forms.TreeNode treeNode8 = new System.Windows.Forms.TreeNode("节点1", new System.Windows.Forms.TreeNode[] {
            treeNode5,
            treeNode6,
            treeNode7});
            System.Windows.Forms.TreeNode treeNode9 = new System.Windows.Forms.TreeNode("节点10");
            System.Windows.Forms.TreeNode treeNode10 = new System.Windows.Forms.TreeNode("节点11");
            System.Windows.Forms.TreeNode treeNode11 = new System.Windows.Forms.TreeNode("节点12");
            System.Windows.Forms.TreeNode treeNode12 = new System.Windows.Forms.TreeNode("节点2", new System.Windows.Forms.TreeNode[] {
            treeNode9,
            treeNode10,
            treeNode11});
            System.Windows.Forms.TreeNode treeNode13 = new System.Windows.Forms.TreeNode("节点13");
            System.Windows.Forms.TreeNode treeNode14 = new System.Windows.Forms.TreeNode("节点14");
            System.Windows.Forms.TreeNode treeNode15 = new System.Windows.Forms.TreeNode("节点15");
            System.Windows.Forms.TreeNode treeNode16 = new System.Windows.Forms.TreeNode("节点3", new System.Windows.Forms.TreeNode[] {
            treeNode13,
            treeNode14,
            treeNode15});
            System.Windows.Forms.TreeNode treeNode17 = new System.Windows.Forms.TreeNode("节点4");
            System.Windows.Forms.TreeNode treeNode18 = new System.Windows.Forms.TreeNode("节点5");
            System.Windows.Forms.TreeNode treeNode19 = new System.Windows.Forms.TreeNode("节点6");
            System.Windows.Forms.TreeNode treeNode20 = new System.Windows.Forms.TreeNode("节点0", new System.Windows.Forms.TreeNode[] {
            treeNode17,
            treeNode18,
            treeNode19});
            System.Windows.Forms.TreeNode treeNode21 = new System.Windows.Forms.TreeNode("节点7");
            System.Windows.Forms.TreeNode treeNode22 = new System.Windows.Forms.TreeNode("节点8");
            System.Windows.Forms.TreeNode treeNode23 = new System.Windows.Forms.TreeNode("节点9");
            System.Windows.Forms.TreeNode treeNode24 = new System.Windows.Forms.TreeNode("节点1", new System.Windows.Forms.TreeNode[] {
            treeNode21,
            treeNode22,
            treeNode23});
            System.Windows.Forms.TreeNode treeNode25 = new System.Windows.Forms.TreeNode("节点10");
            System.Windows.Forms.TreeNode treeNode26 = new System.Windows.Forms.TreeNode("节点11");
            System.Windows.Forms.TreeNode treeNode27 = new System.Windows.Forms.TreeNode("节点12");
            System.Windows.Forms.TreeNode treeNode28 = new System.Windows.Forms.TreeNode("节点2", new System.Windows.Forms.TreeNode[] {
            treeNode25,
            treeNode26,
            treeNode27});
            System.Windows.Forms.TreeNode treeNode29 = new System.Windows.Forms.TreeNode("节点13");
            System.Windows.Forms.TreeNode treeNode30 = new System.Windows.Forms.TreeNode("节点14");
            System.Windows.Forms.TreeNode treeNode31 = new System.Windows.Forms.TreeNode("节点15");
            System.Windows.Forms.TreeNode treeNode32 = new System.Windows.Forms.TreeNode("节点3", new System.Windows.Forms.TreeNode[] {
            treeNode29,
            treeNode30,
            treeNode31});
            System.Windows.Forms.TreeNode treeNode33 = new System.Windows.Forms.TreeNode("节点4");
            System.Windows.Forms.TreeNode treeNode34 = new System.Windows.Forms.TreeNode("节点5");
            System.Windows.Forms.TreeNode treeNode35 = new System.Windows.Forms.TreeNode("节点6");
            System.Windows.Forms.TreeNode treeNode36 = new System.Windows.Forms.TreeNode("节点0", new System.Windows.Forms.TreeNode[] {
            treeNode33,
            treeNode34,
            treeNode35});
            System.Windows.Forms.TreeNode treeNode37 = new System.Windows.Forms.TreeNode("节点7");
            System.Windows.Forms.TreeNode treeNode38 = new System.Windows.Forms.TreeNode("节点8");
            System.Windows.Forms.TreeNode treeNode39 = new System.Windows.Forms.TreeNode("节点9");
            System.Windows.Forms.TreeNode treeNode40 = new System.Windows.Forms.TreeNode("节点1", new System.Windows.Forms.TreeNode[] {
            treeNode37,
            treeNode38,
            treeNode39});
            System.Windows.Forms.TreeNode treeNode41 = new System.Windows.Forms.TreeNode("节点10");
            System.Windows.Forms.TreeNode treeNode42 = new System.Windows.Forms.TreeNode("节点11");
            System.Windows.Forms.TreeNode treeNode43 = new System.Windows.Forms.TreeNode("节点12");
            System.Windows.Forms.TreeNode treeNode44 = new System.Windows.Forms.TreeNode("节点2", new System.Windows.Forms.TreeNode[] {
            treeNode41,
            treeNode42,
            treeNode43});
            System.Windows.Forms.TreeNode treeNode45 = new System.Windows.Forms.TreeNode("节点13");
            System.Windows.Forms.TreeNode treeNode46 = new System.Windows.Forms.TreeNode("节点14");
            System.Windows.Forms.TreeNode treeNode47 = new System.Windows.Forms.TreeNode("节点15");
            System.Windows.Forms.TreeNode treeNode48 = new System.Windows.Forms.TreeNode("节点3", new System.Windows.Forms.TreeNode[] {
            treeNode45,
            treeNode46,
            treeNode47});
            this.treeViewEx1 = new HZH_Controls.Controls.TreeViewEx();
            this.ucSplitLine_V2 = new HZH_Controls.Controls.UCSplitLine_V();
            this.treeViewEx2 = new HZH_Controls.Controls.TreeViewEx();
            this.treeViewEx3 = new HZH_Controls.Controls.TreeViewEx();
            this.ucSplitLine_V4 = new HZH_Controls.Controls.UCSplitLine_V();
            this.ucSplitLine_V5 = new HZH_Controls.Controls.UCSplitLine_V();
            this.treeViewEx6 = new HZH_Controls.Controls.TreeViewEx();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.ucSplitLine_V7 = new HZH_Controls.Controls.UCSplitLine_V();
            this.treeViewEx5 = new HZH_Controls.Controls.TreeViewEx();
            this.scrollbarComponent1 = new HZH_Controls.Controls.ScrollbarComponent(this.components);
            this.SuspendLayout();
            // 
            // treeViewEx1
            // 
            this.treeViewEx1.BackColor = System.Drawing.Color.White;
            this.treeViewEx1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.treeViewEx1.Dock = System.Windows.Forms.DockStyle.Left;
            this.treeViewEx1.DrawMode = System.Windows.Forms.TreeViewDrawMode.OwnerDrawAll;
            this.treeViewEx1.FullRowSelect = true;
            this.treeViewEx1.HideSelection = false;
            this.treeViewEx1.IsShowByCustomModel = true;
            this.treeViewEx1.IsShowTip = false;
            this.treeViewEx1.ItemHeight = 50;
            this.treeViewEx1.Location = new System.Drawing.Point(0, 0);
            this.treeViewEx1.LstTips = ((System.Collections.Generic.Dictionary<string, string>)(resources.GetObject("treeViewEx1.LstTips")));
            this.treeViewEx1.Name = "treeViewEx1";
            this.treeViewEx1.NodeBackgroundColor = System.Drawing.Color.White;
            this.treeViewEx1.NodeDownPic = ((System.Drawing.Image)(resources.GetObject("treeViewEx1.NodeDownPic")));
            this.treeViewEx1.NodeForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(62)))), ((int)(((byte)(62)))), ((int)(((byte)(62)))));
            this.treeViewEx1.NodeHeight = 50;
            this.treeViewEx1.NodeIsShowSplitLine = false;
            treeNode1.Name = "节点4";
            treeNode1.Text = "节点4";
            treeNode2.Name = "节点5";
            treeNode2.Text = "节点5";
            treeNode3.Name = "节点6";
            treeNode3.Text = "节点6";
            treeNode4.Name = "节点0";
            treeNode4.Text = "节点0";
            treeNode5.Name = "节点7";
            treeNode5.Text = "节点7";
            treeNode6.Name = "节点8";
            treeNode6.Text = "节点8";
            treeNode7.Name = "节点9";
            treeNode7.Text = "节点9";
            treeNode8.Name = "节点1";
            treeNode8.Text = "节点1";
            treeNode9.Name = "节点10";
            treeNode9.Text = "节点10";
            treeNode10.Name = "节点11";
            treeNode10.Text = "节点11";
            treeNode11.Name = "节点12";
            treeNode11.Text = "节点12";
            treeNode12.Name = "节点2";
            treeNode12.Text = "节点2";
            treeNode13.Name = "节点13";
            treeNode13.Text = "节点13";
            treeNode14.Name = "节点14";
            treeNode14.Text = "节点14";
            treeNode15.Name = "节点15";
            treeNode15.Text = "节点15";
            treeNode16.Name = "节点3";
            treeNode16.Text = "节点3";
            this.treeViewEx1.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode4,
            treeNode8,
            treeNode12,
            treeNode16});
            this.treeViewEx1.NodeSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.treeViewEx1.NodeSelectedForeColor = System.Drawing.Color.White;
            this.treeViewEx1.NodeSplitLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(232)))), ((int)(((byte)(232)))));
            this.treeViewEx1.NodeUpPic = ((System.Drawing.Image)(resources.GetObject("treeViewEx1.NodeUpPic")));
            this.treeViewEx1.ParentNodeCanSelect = true;
            this.treeViewEx1.ShowLines = false;
            this.treeViewEx1.ShowPlusMinus = false;
            this.treeViewEx1.ShowRootLines = false;
            this.treeViewEx1.Size = new System.Drawing.Size(164, 634);
            this.treeViewEx1.TabIndex = 0;
            this.treeViewEx1.TipFont = new System.Drawing.Font("Arial Unicode MS", 12F);
            this.treeViewEx1.TipImage = ((System.Drawing.Image)(resources.GetObject("treeViewEx1.TipImage")));
            this.scrollbarComponent1.SetUserCustomScrollbar(this.treeViewEx1, true);
            // 
            // ucSplitLine_V2
            // 
            this.ucSplitLine_V2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(232)))), ((int)(((byte)(232)))));
            this.ucSplitLine_V2.Dock = System.Windows.Forms.DockStyle.Left;
            this.ucSplitLine_V2.Location = new System.Drawing.Point(328, 0);
            this.ucSplitLine_V2.Name = "ucSplitLine_V2";
            this.ucSplitLine_V2.Size = new System.Drawing.Size(1, 634);
            this.ucSplitLine_V2.TabIndex = 3;
            this.ucSplitLine_V2.TabStop = false;
            // 
            // treeViewEx2
            // 
            this.treeViewEx2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(43)))), ((int)(((byte)(51)))));
            this.treeViewEx2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.treeViewEx2.Dock = System.Windows.Forms.DockStyle.Left;
            this.treeViewEx2.DrawMode = System.Windows.Forms.TreeViewDrawMode.OwnerDrawAll;
            this.treeViewEx2.FullRowSelect = true;
            this.treeViewEx2.HideSelection = false;
            this.treeViewEx2.IsShowByCustomModel = true;
            this.treeViewEx2.IsShowTip = false;
            this.treeViewEx2.ItemHeight = 50;
            this.treeViewEx2.Location = new System.Drawing.Point(164, 0);
            this.treeViewEx2.LstTips = ((System.Collections.Generic.Dictionary<string, string>)(resources.GetObject("treeViewEx2.LstTips")));
            this.treeViewEx2.Name = "treeViewEx2";
            this.treeViewEx2.NodeBackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(43)))), ((int)(((byte)(51)))));
            this.treeViewEx2.NodeDownPic = ((System.Drawing.Image)(resources.GetObject("treeViewEx2.NodeDownPic")));
            this.treeViewEx2.NodeForeColor = System.Drawing.Color.White;
            this.treeViewEx2.NodeHeight = 50;
            this.treeViewEx2.NodeIsShowSplitLine = false;
            treeNode17.Name = "节点4";
            treeNode17.Text = "节点4";
            treeNode18.Name = "节点5";
            treeNode18.Text = "节点5";
            treeNode19.Name = "节点6";
            treeNode19.Text = "节点6";
            treeNode20.Name = "节点0";
            treeNode20.Text = "节点0";
            treeNode21.Name = "节点7";
            treeNode21.Text = "节点7";
            treeNode22.Name = "节点8";
            treeNode22.Text = "节点8";
            treeNode23.Name = "节点9";
            treeNode23.Text = "节点9";
            treeNode24.Name = "节点1";
            treeNode24.Text = "节点1";
            treeNode25.Name = "节点10";
            treeNode25.Text = "节点10";
            treeNode26.Name = "节点11";
            treeNode26.Text = "节点11";
            treeNode27.Name = "节点12";
            treeNode27.Text = "节点12";
            treeNode28.Name = "节点2";
            treeNode28.Text = "节点2";
            treeNode29.Name = "节点13";
            treeNode29.Text = "节点13";
            treeNode30.Name = "节点14";
            treeNode30.Text = "节点14";
            treeNode31.Name = "节点15";
            treeNode31.Text = "节点15";
            treeNode32.Name = "节点3";
            treeNode32.Text = "节点3";
            this.treeViewEx2.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode20,
            treeNode24,
            treeNode28,
            treeNode32});
            this.treeViewEx2.NodeSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.treeViewEx2.NodeSelectedForeColor = System.Drawing.Color.White;
            this.treeViewEx2.NodeSplitLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(232)))), ((int)(((byte)(232)))));
            this.treeViewEx2.NodeUpPic = ((System.Drawing.Image)(resources.GetObject("treeViewEx2.NodeUpPic")));
            this.treeViewEx2.ParentNodeCanSelect = true;
            this.treeViewEx2.ShowLines = false;
            this.treeViewEx2.ShowPlusMinus = false;
            this.treeViewEx2.ShowRootLines = false;
            this.treeViewEx2.Size = new System.Drawing.Size(164, 634);
            this.treeViewEx2.TabIndex = 2;
            this.treeViewEx2.TipFont = new System.Drawing.Font("Arial Unicode MS", 12F);
            this.treeViewEx2.TipImage = ((System.Drawing.Image)(resources.GetObject("treeViewEx2.TipImage")));
            this.scrollbarComponent1.SetUserCustomScrollbar(this.treeViewEx2, true);
            // 
            // treeViewEx3
            // 
            this.treeViewEx3.BackColor = System.Drawing.Color.White;
            this.treeViewEx3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.treeViewEx3.CheckBoxes = true;
            this.treeViewEx3.Dock = System.Windows.Forms.DockStyle.Left;
            this.treeViewEx3.DrawMode = System.Windows.Forms.TreeViewDrawMode.OwnerDrawAll;
            this.treeViewEx3.FullRowSelect = true;
            this.treeViewEx3.HideSelection = false;
            this.treeViewEx3.IsShowByCustomModel = true;
            this.treeViewEx3.IsShowTip = false;
            this.treeViewEx3.ItemHeight = 50;
            this.treeViewEx3.Location = new System.Drawing.Point(494, 0);
            this.treeViewEx3.LstTips = ((System.Collections.Generic.Dictionary<string, string>)(resources.GetObject("treeViewEx3.LstTips")));
            this.treeViewEx3.Name = "treeViewEx3";
            this.treeViewEx3.NodeBackgroundColor = System.Drawing.Color.White;
            this.treeViewEx3.NodeDownPic = ((System.Drawing.Image)(resources.GetObject("treeViewEx3.NodeDownPic")));
            this.treeViewEx3.NodeForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(62)))), ((int)(((byte)(62)))), ((int)(((byte)(62)))));
            this.treeViewEx3.NodeHeight = 50;
            this.treeViewEx3.NodeIsShowSplitLine = false;
            treeNode33.Name = "节点4";
            treeNode33.Text = "节点4";
            treeNode34.Name = "节点5";
            treeNode34.Text = "节点5";
            treeNode35.Name = "节点6";
            treeNode35.Text = "节点6";
            treeNode36.Name = "节点0";
            treeNode36.Text = "节点0";
            treeNode37.Name = "节点7";
            treeNode37.Text = "节点7";
            treeNode38.Name = "节点8";
            treeNode38.Text = "节点8";
            treeNode39.Name = "节点9";
            treeNode39.Text = "节点9";
            treeNode40.Name = "节点1";
            treeNode40.Text = "节点1";
            treeNode41.Name = "节点10";
            treeNode41.Text = "节点10";
            treeNode42.Name = "节点11";
            treeNode42.Text = "节点11";
            treeNode43.Name = "节点12";
            treeNode43.Text = "节点12";
            treeNode44.Name = "节点2";
            treeNode44.Text = "节点2";
            treeNode45.Name = "节点13";
            treeNode45.Text = "节点13";
            treeNode46.Name = "节点14";
            treeNode46.Text = "节点14";
            treeNode47.Name = "节点15";
            treeNode47.Text = "节点15";
            treeNode48.Name = "节点3";
            treeNode48.Text = "节点3";
            this.treeViewEx3.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode36,
            treeNode40,
            treeNode44,
            treeNode48});
            this.treeViewEx3.NodeSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.treeViewEx3.NodeSelectedForeColor = System.Drawing.Color.White;
            this.treeViewEx3.NodeSplitLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(232)))), ((int)(((byte)(232)))));
            this.treeViewEx3.NodeUpPic = ((System.Drawing.Image)(resources.GetObject("treeViewEx3.NodeUpPic")));
            this.treeViewEx3.ParentNodeCanSelect = true;
            this.treeViewEx3.ShowLines = false;
            this.treeViewEx3.ShowPlusMinus = false;
            this.treeViewEx3.ShowRootLines = false;
            this.treeViewEx3.Size = new System.Drawing.Size(164, 634);
            this.treeViewEx3.TabIndex = 4;
            this.treeViewEx3.TipFont = new System.Drawing.Font("Arial Unicode MS", 12F);
            this.treeViewEx3.TipImage = ((System.Drawing.Image)(resources.GetObject("treeViewEx3.TipImage")));
            this.scrollbarComponent1.SetUserCustomScrollbar(this.treeViewEx3, true);
            // 
            // ucSplitLine_V4
            // 
            this.ucSplitLine_V4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(232)))), ((int)(((byte)(232)))));
            this.ucSplitLine_V4.Dock = System.Windows.Forms.DockStyle.Left;
            this.ucSplitLine_V4.Location = new System.Drawing.Point(493, 0);
            this.ucSplitLine_V4.Name = "ucSplitLine_V4";
            this.ucSplitLine_V4.Size = new System.Drawing.Size(1, 634);
            this.ucSplitLine_V4.TabIndex = 7;
            this.ucSplitLine_V4.TabStop = false;
            // 
            // ucSplitLine_V5
            // 
            this.ucSplitLine_V5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(232)))), ((int)(((byte)(232)))));
            this.ucSplitLine_V5.Dock = System.Windows.Forms.DockStyle.Left;
            this.ucSplitLine_V5.Location = new System.Drawing.Point(658, 0);
            this.ucSplitLine_V5.Name = "ucSplitLine_V5";
            this.ucSplitLine_V5.Size = new System.Drawing.Size(1, 634);
            this.ucSplitLine_V5.TabIndex = 11;
            this.ucSplitLine_V5.TabStop = false;
            // 
            // treeViewEx6
            // 
            this.treeViewEx6.BackColor = System.Drawing.Color.White;
            this.treeViewEx6.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.treeViewEx6.Dock = System.Windows.Forms.DockStyle.Left;
            this.treeViewEx6.DrawMode = System.Windows.Forms.TreeViewDrawMode.OwnerDrawAll;
            this.treeViewEx6.FullRowSelect = true;
            this.treeViewEx6.HideSelection = false;
            this.treeViewEx6.ImageIndex = 0;
            this.treeViewEx6.ImageList = this.imageList1;
            this.treeViewEx6.IsShowByCustomModel = true;
            this.treeViewEx6.IsShowTip = false;
            this.treeViewEx6.ItemHeight = 50;
            this.treeViewEx6.Location = new System.Drawing.Point(329, 0);
            this.treeViewEx6.LstTips = ((System.Collections.Generic.Dictionary<string, string>)(resources.GetObject("treeViewEx6.LstTips")));
            this.treeViewEx6.Name = "treeViewEx6";
            this.treeViewEx6.NodeBackgroundColor = System.Drawing.Color.White;
            this.treeViewEx6.NodeDownPic = ((System.Drawing.Image)(resources.GetObject("treeViewEx6.NodeDownPic")));
            this.treeViewEx6.NodeForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(62)))), ((int)(((byte)(62)))), ((int)(((byte)(62)))));
            this.treeViewEx6.NodeHeight = 50;
            this.treeViewEx6.NodeIsShowSplitLine = false;
            this.treeViewEx6.NodeSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.treeViewEx6.NodeSelectedForeColor = System.Drawing.Color.White;
            this.treeViewEx6.NodeSplitLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(232)))), ((int)(((byte)(232)))));
            this.treeViewEx6.NodeUpPic = ((System.Drawing.Image)(resources.GetObject("treeViewEx6.NodeUpPic")));
            this.treeViewEx6.ParentNodeCanSelect = true;
            this.treeViewEx6.SelectedImageIndex = 0;
            this.treeViewEx6.ShowLines = false;
            this.treeViewEx6.ShowPlusMinus = false;
            this.treeViewEx6.ShowRootLines = false;
            this.treeViewEx6.Size = new System.Drawing.Size(164, 634);
            this.treeViewEx6.TabIndex = 8;
            this.treeViewEx6.TipFont = new System.Drawing.Font("Arial Unicode MS", 12F);
            this.treeViewEx6.TipImage = ((System.Drawing.Image)(resources.GetObject("treeViewEx6.TipImage")));
            this.scrollbarComponent1.SetUserCustomScrollbar(this.treeViewEx6, true);
            // 
            // imageList1
            // 
            this.imageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
            this.imageList1.ImageSize = new System.Drawing.Size(24, 24);
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // ucSplitLine_V7
            // 
            this.ucSplitLine_V7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(232)))), ((int)(((byte)(232)))));
            this.ucSplitLine_V7.Dock = System.Windows.Forms.DockStyle.Left;
            this.ucSplitLine_V7.Location = new System.Drawing.Point(823, 0);
            this.ucSplitLine_V7.Name = "ucSplitLine_V7";
            this.ucSplitLine_V7.Size = new System.Drawing.Size(1, 634);
            this.ucSplitLine_V7.TabIndex = 14;
            this.ucSplitLine_V7.TabStop = false;
            // 
            // treeViewEx5
            // 
            this.treeViewEx5.BackColor = System.Drawing.Color.White;
            this.treeViewEx5.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.treeViewEx5.CheckBoxes = true;
            this.treeViewEx5.Dock = System.Windows.Forms.DockStyle.Left;
            this.treeViewEx5.DrawMode = System.Windows.Forms.TreeViewDrawMode.OwnerDrawAll;
            this.treeViewEx5.FullRowSelect = true;
            this.treeViewEx5.HideSelection = false;
            this.treeViewEx5.ImageIndex = 0;
            this.treeViewEx5.ImageList = this.imageList1;
            this.treeViewEx5.IsShowByCustomModel = true;
            this.treeViewEx5.IsShowTip = false;
            this.treeViewEx5.ItemHeight = 50;
            this.treeViewEx5.Location = new System.Drawing.Point(659, 0);
            this.treeViewEx5.LstTips = ((System.Collections.Generic.Dictionary<string, string>)(resources.GetObject("treeViewEx5.LstTips")));
            this.treeViewEx5.Name = "treeViewEx5";
            this.treeViewEx5.NodeBackgroundColor = System.Drawing.Color.White;
            this.treeViewEx5.NodeDownPic = ((System.Drawing.Image)(resources.GetObject("treeViewEx5.NodeDownPic")));
            this.treeViewEx5.NodeForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(62)))), ((int)(((byte)(62)))), ((int)(((byte)(62)))));
            this.treeViewEx5.NodeHeight = 50;
            this.treeViewEx5.NodeIsShowSplitLine = false;
            this.treeViewEx5.NodeSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.treeViewEx5.NodeSelectedForeColor = System.Drawing.Color.White;
            this.treeViewEx5.NodeSplitLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(232)))), ((int)(((byte)(232)))));
            this.treeViewEx5.NodeUpPic = ((System.Drawing.Image)(resources.GetObject("treeViewEx5.NodeUpPic")));
            this.treeViewEx5.ParentNodeCanSelect = true;
            this.treeViewEx5.SelectedImageIndex = 0;
            this.treeViewEx5.ShowLines = false;
            this.treeViewEx5.ShowPlusMinus = false;
            this.treeViewEx5.ShowRootLines = false;
            this.treeViewEx5.Size = new System.Drawing.Size(164, 634);
            this.treeViewEx5.TabIndex = 12;
            this.treeViewEx5.TipFont = new System.Drawing.Font("Arial Unicode MS", 12F);
            this.treeViewEx5.TipImage = ((System.Drawing.Image)(resources.GetObject("treeViewEx5.TipImage")));
            this.scrollbarComponent1.SetUserCustomScrollbar(this.treeViewEx5, true);
            // 
            // UCTestTreeview
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.ucSplitLine_V7);
            this.Controls.Add(this.treeViewEx5);
            this.Controls.Add(this.ucSplitLine_V5);
            this.Controls.Add(this.treeViewEx3);
            this.Controls.Add(this.ucSplitLine_V4);
            this.Controls.Add(this.treeViewEx6);
            this.Controls.Add(this.ucSplitLine_V2);
            this.Controls.Add(this.treeViewEx2);
            this.Controls.Add(this.treeViewEx1);
            this.Name = "UCTestTreeview";
            this.Size = new System.Drawing.Size(1000, 634);
            this.Load += new System.EventHandler(this.UCTestTreeview_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private HZH_Controls.Controls.TreeViewEx treeViewEx1;
        private HZH_Controls.Controls.UCSplitLine_V ucSplitLine_V2;
        private HZH_Controls.Controls.TreeViewEx treeViewEx2;
        private HZH_Controls.Controls.TreeViewEx treeViewEx3;
        private HZH_Controls.Controls.UCSplitLine_V ucSplitLine_V4;
        private HZH_Controls.Controls.UCSplitLine_V ucSplitLine_V5;
        private HZH_Controls.Controls.TreeViewEx treeViewEx6;
        private System.Windows.Forms.ImageList imageList1;
        private HZH_Controls.Controls.UCSplitLine_V ucSplitLine_V7;
        private HZH_Controls.Controls.TreeViewEx treeViewEx5;
        private HZH_Controls.Controls.ScrollbarComponent scrollbarComponent1;
    }
}
