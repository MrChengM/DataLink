﻿namespace Test.UC
{
    partial class UCTestBtns
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UCTestBtns));
            this.ucDropDownBtn1 = new HZH_Controls.Controls.UCDropDownBtn();
            this.ucControlBase1 = new HZH_Controls.Controls.UCControlBase();
            this.ucBtnExt3 = new HZH_Controls.Controls.UCBtnExt();
            this.ucBtnExt4 = new HZH_Controls.Controls.UCBtnExt();
            this.ucBtnExt5 = new HZH_Controls.Controls.UCBtnExt();
            this.ucBtnExt1 = new HZH_Controls.Controls.UCBtnExt();
            this.ucBtnExt6 = new HZH_Controls.Controls.UCBtnExt();
            this.ucBtnExt7 = new HZH_Controls.Controls.UCBtnExt();
            this.ucBtnExt8 = new HZH_Controls.Controls.UCBtnExt();
            this.ucBtnExt9 = new HZH_Controls.Controls.UCBtnExt();
            this.ucBtnExt2 = new HZH_Controls.Controls.UCBtnExt();
            this.ucBtnExt10 = new HZH_Controls.Controls.UCBtnExt();
            this.ucBtnExt11 = new HZH_Controls.Controls.UCBtnExt();
            this.ucBtnExt12 = new HZH_Controls.Controls.UCBtnExt();
            this.ucBtnExt13 = new HZH_Controls.Controls.UCBtnExt();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.ucBtnExt33 = new HZH_Controls.Controls.UCBtnExt();
            this.ucBtnExt32 = new HZH_Controls.Controls.UCBtnExt();
            this.ucBtnExt31 = new HZH_Controls.Controls.UCBtnExt();
            this.ucBtnExt30 = new HZH_Controls.Controls.UCBtnExt();
            this.ucBtnExt29 = new HZH_Controls.Controls.UCBtnExt();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.ucBtnExt28 = new HZH_Controls.Controls.UCBtnExt();
            this.ucBtnExt23 = new HZH_Controls.Controls.UCBtnExt();
            this.ucBtnExt16 = new HZH_Controls.Controls.UCBtnExt();
            this.ucBtnExt27 = new HZH_Controls.Controls.UCBtnExt();
            this.ucBtnExt20 = new HZH_Controls.Controls.UCBtnExt();
            this.ucBtnExt26 = new HZH_Controls.Controls.UCBtnExt();
            this.ucBtnExt19 = new HZH_Controls.Controls.UCBtnExt();
            this.ucBtnExt17 = new HZH_Controls.Controls.UCBtnExt();
            this.ucBtnExt25 = new HZH_Controls.Controls.UCBtnExt();
            this.ucBtnExt15 = new HZH_Controls.Controls.UCBtnExt();
            this.ucBtnExt24 = new HZH_Controls.Controls.UCBtnExt();
            this.ucBtnExt18 = new HZH_Controls.Controls.UCBtnExt();
            this.ucBtnExt14 = new HZH_Controls.Controls.UCBtnExt();
            this.ucBtnExt21 = new HZH_Controls.Controls.UCBtnExt();
            this.ucBtnExt22 = new HZH_Controls.Controls.UCBtnExt();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.ucBtnImg16 = new HZH_Controls.Controls.UCBtnImg();
            this.ucBtnImg11 = new HZH_Controls.Controls.UCBtnImg();
            this.ucBtnImg6 = new HZH_Controls.Controls.UCBtnImg();
            this.ucBtnImg15 = new HZH_Controls.Controls.UCBtnImg();
            this.ucBtnImg10 = new HZH_Controls.Controls.UCBtnImg();
            this.ucBtnImg14 = new HZH_Controls.Controls.UCBtnImg();
            this.ucBtnImg9 = new HZH_Controls.Controls.UCBtnImg();
            this.ucBtnImg5 = new HZH_Controls.Controls.UCBtnImg();
            this.ucBtnImg13 = new HZH_Controls.Controls.UCBtnImg();
            this.ucBtnImg8 = new HZH_Controls.Controls.UCBtnImg();
            this.ucBtnImg12 = new HZH_Controls.Controls.UCBtnImg();
            this.ucBtnImg4 = new HZH_Controls.Controls.UCBtnImg();
            this.ucBtnImg7 = new HZH_Controls.Controls.UCBtnImg();
            this.ucBtnImg3 = new HZH_Controls.Controls.UCBtnImg();
            this.ucBtnImg2 = new HZH_Controls.Controls.UCBtnImg();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.ucControlBase3 = new HZH_Controls.Controls.UCControlBase();
            this.ucBtnImg21 = new HZH_Controls.Controls.UCBtnImg();
            this.ucSplitLine_V1 = new HZH_Controls.Controls.UCSplitLine_V();
            this.ucBtnImg20 = new HZH_Controls.Controls.UCBtnImg();
            this.ucSplitLine_V2 = new HZH_Controls.Controls.UCSplitLine_V();
            this.ucBtnImg22 = new HZH_Controls.Controls.UCBtnImg();
            this.ucControlBase2 = new HZH_Controls.Controls.UCControlBase();
            this.ucBtnImg19 = new HZH_Controls.Controls.UCBtnImg();
            this.ucBtnImg18 = new HZH_Controls.Controls.UCBtnImg();
            this.ucBtnImg17 = new HZH_Controls.Controls.UCBtnImg();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.ucDropDownBtn5 = new HZH_Controls.Controls.UCDropDownBtn();
            this.ucDropDownBtn4 = new HZH_Controls.Controls.UCDropDownBtn();
            this.ucDropDownBtn3 = new HZH_Controls.Controls.UCDropDownBtn();
            this.ucDropDownBtn2 = new HZH_Controls.Controls.UCDropDownBtn();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.ucBtnsGroup2 = new HZH_Controls.Controls.UCBtnsGroup();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.ucBtnsGroup1 = new HZH_Controls.Controls.UCBtnsGroup();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.ucBtnImg1 = new HZH_Controls.Controls.UCBtnImg();
            this.ucBtnImg23 = new HZH_Controls.Controls.UCBtnImg();
            this.ucBtnImg24 = new HZH_Controls.Controls.UCBtnImg();
            this.ucBtnImg25 = new HZH_Controls.Controls.UCBtnImg();
            this.ucBtnImg26 = new HZH_Controls.Controls.UCBtnImg();
            this.ucControlBase1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.ucControlBase3.SuspendLayout();
            this.ucControlBase2.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox13.SuspendLayout();
            this.groupBox12.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.SuspendLayout();
            // 
            // ucDropDownBtn1
            // 
            this.ucDropDownBtn1.BackColor = System.Drawing.Color.White;
            this.ucDropDownBtn1.BtnBackColor = System.Drawing.Color.White;
            this.ucDropDownBtn1.BtnFont = new System.Drawing.Font("微软雅黑", 12F);
            this.ucDropDownBtn1.BtnForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucDropDownBtn1.Btns = new string[] {
        "按钮1",
        "按钮2",
        "按钮3"};
            this.ucDropDownBtn1.BtnText = "下拉按钮";
            this.ucDropDownBtn1.ConerRadius = 5;
            this.ucDropDownBtn1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucDropDownBtn1.DropPanelHeight = -1;
            this.ucDropDownBtn1.EnabledMouseEffect = true;
            this.ucDropDownBtn1.FillColor = System.Drawing.Color.White;
            this.ucDropDownBtn1.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucDropDownBtn1.ForeColor = System.Drawing.Color.White;
            this.ucDropDownBtn1.Image = ((System.Drawing.Image)(resources.GetObject("ucDropDownBtn1.Image")));
            this.ucDropDownBtn1.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.ucDropDownBtn1.ImageFontIcons = null;
            this.ucDropDownBtn1.IsRadius = true;
            this.ucDropDownBtn1.IsShowRect = true;
            this.ucDropDownBtn1.IsShowTips = false;
            this.ucDropDownBtn1.Location = new System.Drawing.Point(15, 30);
            this.ucDropDownBtn1.Margin = new System.Windows.Forms.Padding(2);
            this.ucDropDownBtn1.Name = "ucDropDownBtn1";
            this.ucDropDownBtn1.RectColor = System.Drawing.Color.Gainsboro;
            this.ucDropDownBtn1.RectWidth = 1;
            this.ucDropDownBtn1.Size = new System.Drawing.Size(97, 39);
            this.ucDropDownBtn1.TabIndex = 20;
            this.ucDropDownBtn1.TabStop = false;
            this.ucDropDownBtn1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucDropDownBtn1.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucDropDownBtn1.TipsText = "";
            // 
            // ucControlBase1
            // 
            this.ucControlBase1.BackColor = System.Drawing.Color.Transparent;
            this.ucControlBase1.ConerRadius = 10;
            this.ucControlBase1.Controls.Add(this.ucBtnExt3);
            this.ucControlBase1.Controls.Add(this.ucBtnExt4);
            this.ucControlBase1.Controls.Add(this.ucBtnExt5);
            this.ucControlBase1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(58)))));
            this.ucControlBase1.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucControlBase1.IsRadius = true;
            this.ucControlBase1.IsShowRect = true;
            this.ucControlBase1.Location = new System.Drawing.Point(7, 22);
            this.ucControlBase1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ucControlBase1.Name = "ucControlBase1";
            this.ucControlBase1.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            this.ucControlBase1.RectWidth = 1;
            this.ucControlBase1.Size = new System.Drawing.Size(167, 44);
            this.ucControlBase1.TabIndex = 19;
            // 
            // ucBtnExt3
            // 
            this.ucBtnExt3.BackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt3.BtnBackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt3.BtnFont = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ucBtnExt3.BtnForeColor = System.Drawing.Color.White;
            this.ucBtnExt3.BtnText = "按钮3";
            this.ucBtnExt3.ConerRadius = 5;
            this.ucBtnExt3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnExt3.Dock = System.Windows.Forms.DockStyle.Left;
            this.ucBtnExt3.EnabledMouseEffect = true;
            this.ucBtnExt3.FillColor = System.Drawing.Color.Transparent;
            this.ucBtnExt3.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnExt3.IsRadius = false;
            this.ucBtnExt3.IsShowRect = false;
            this.ucBtnExt3.IsShowTips = false;
            this.ucBtnExt3.Location = new System.Drawing.Point(110, 0);
            this.ucBtnExt3.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnExt3.Name = "ucBtnExt3";
            this.ucBtnExt3.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(58)))));
            this.ucBtnExt3.RectWidth = 0;
            this.ucBtnExt3.Size = new System.Drawing.Size(57, 44);
            this.ucBtnExt3.TabIndex = 2;
            this.ucBtnExt3.TabStop = false;
            this.ucBtnExt3.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnExt3.TipsText = "";
            // 
            // ucBtnExt4
            // 
            this.ucBtnExt4.BackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt4.BtnBackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt4.BtnFont = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ucBtnExt4.BtnForeColor = System.Drawing.Color.White;
            this.ucBtnExt4.BtnText = "按钮2";
            this.ucBtnExt4.ConerRadius = 5;
            this.ucBtnExt4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnExt4.Dock = System.Windows.Forms.DockStyle.Left;
            this.ucBtnExt4.EnabledMouseEffect = true;
            this.ucBtnExt4.FillColor = System.Drawing.Color.Transparent;
            this.ucBtnExt4.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnExt4.IsRadius = false;
            this.ucBtnExt4.IsShowRect = false;
            this.ucBtnExt4.IsShowTips = false;
            this.ucBtnExt4.Location = new System.Drawing.Point(57, 0);
            this.ucBtnExt4.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnExt4.Name = "ucBtnExt4";
            this.ucBtnExt4.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(58)))));
            this.ucBtnExt4.RectWidth = 0;
            this.ucBtnExt4.Size = new System.Drawing.Size(53, 44);
            this.ucBtnExt4.TabIndex = 1;
            this.ucBtnExt4.TabStop = false;
            this.ucBtnExt4.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnExt4.TipsText = "";
            // 
            // ucBtnExt5
            // 
            this.ucBtnExt5.BackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt5.BtnBackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt5.BtnFont = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ucBtnExt5.BtnForeColor = System.Drawing.Color.White;
            this.ucBtnExt5.BtnText = "按钮1";
            this.ucBtnExt5.ConerRadius = 5;
            this.ucBtnExt5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnExt5.Dock = System.Windows.Forms.DockStyle.Left;
            this.ucBtnExt5.EnabledMouseEffect = true;
            this.ucBtnExt5.FillColor = System.Drawing.Color.Transparent;
            this.ucBtnExt5.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnExt5.IsRadius = false;
            this.ucBtnExt5.IsShowRect = false;
            this.ucBtnExt5.IsShowTips = false;
            this.ucBtnExt5.Location = new System.Drawing.Point(0, 0);
            this.ucBtnExt5.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnExt5.Name = "ucBtnExt5";
            this.ucBtnExt5.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(58)))));
            this.ucBtnExt5.RectWidth = 0;
            this.ucBtnExt5.Size = new System.Drawing.Size(57, 44);
            this.ucBtnExt5.TabIndex = 0;
            this.ucBtnExt5.TabStop = false;
            this.ucBtnExt5.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnExt5.TipsText = "";
            // 
            // ucBtnExt1
            // 
            this.ucBtnExt1.BackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt1.BtnBackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt1.BtnFont = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ucBtnExt1.BtnForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnExt1.BtnText = "圆角10";
            this.ucBtnExt1.ConerRadius = 10;
            this.ucBtnExt1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnExt1.EnabledMouseEffect = true;
            this.ucBtnExt1.FillColor = System.Drawing.Color.White;
            this.ucBtnExt1.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnExt1.ForeColor = System.Drawing.Color.White;
            this.ucBtnExt1.IsRadius = true;
            this.ucBtnExt1.IsShowRect = true;
            this.ucBtnExt1.IsShowTips = false;
            this.ucBtnExt1.Location = new System.Drawing.Point(15, 17);
            this.ucBtnExt1.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnExt1.Name = "ucBtnExt1";
            this.ucBtnExt1.RectColor = System.Drawing.Color.Gainsboro;
            this.ucBtnExt1.RectWidth = 1;
            this.ucBtnExt1.Size = new System.Drawing.Size(97, 34);
            this.ucBtnExt1.TabIndex = 15;
            this.ucBtnExt1.TabStop = false;
            this.ucBtnExt1.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnExt1.TipsText = "";
            // 
            // ucBtnExt6
            // 
            this.ucBtnExt6.BackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt6.BtnBackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt6.BtnFont = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ucBtnExt6.BtnForeColor = System.Drawing.Color.White;
            this.ucBtnExt6.BtnText = "圆角10";
            this.ucBtnExt6.ConerRadius = 10;
            this.ucBtnExt6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnExt6.EnabledMouseEffect = true;
            this.ucBtnExt6.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.ucBtnExt6.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnExt6.ForeColor = System.Drawing.Color.White;
            this.ucBtnExt6.IsRadius = true;
            this.ucBtnExt6.IsShowRect = false;
            this.ucBtnExt6.IsShowTips = false;
            this.ucBtnExt6.Location = new System.Drawing.Point(124, 17);
            this.ucBtnExt6.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnExt6.Name = "ucBtnExt6";
            this.ucBtnExt6.RectColor = System.Drawing.Color.Gainsboro;
            this.ucBtnExt6.RectWidth = 1;
            this.ucBtnExt6.Size = new System.Drawing.Size(97, 34);
            this.ucBtnExt6.TabIndex = 15;
            this.ucBtnExt6.TabStop = false;
            this.ucBtnExt6.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnExt6.TipsText = "";
            // 
            // ucBtnExt7
            // 
            this.ucBtnExt7.BackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt7.BtnBackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt7.BtnFont = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ucBtnExt7.BtnForeColor = System.Drawing.Color.White;
            this.ucBtnExt7.BtnText = "圆角10";
            this.ucBtnExt7.ConerRadius = 10;
            this.ucBtnExt7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnExt7.EnabledMouseEffect = true;
            this.ucBtnExt7.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(159)))), ((int)(((byte)(255)))));
            this.ucBtnExt7.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnExt7.ForeColor = System.Drawing.Color.White;
            this.ucBtnExt7.IsRadius = true;
            this.ucBtnExt7.IsShowRect = false;
            this.ucBtnExt7.IsShowTips = false;
            this.ucBtnExt7.Location = new System.Drawing.Point(237, 17);
            this.ucBtnExt7.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnExt7.Name = "ucBtnExt7";
            this.ucBtnExt7.RectColor = System.Drawing.Color.Gainsboro;
            this.ucBtnExt7.RectWidth = 1;
            this.ucBtnExt7.Size = new System.Drawing.Size(97, 34);
            this.ucBtnExt7.TabIndex = 15;
            this.ucBtnExt7.TabStop = false;
            this.ucBtnExt7.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnExt7.TipsText = "";
            // 
            // ucBtnExt8
            // 
            this.ucBtnExt8.BackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt8.BtnBackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt8.BtnFont = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ucBtnExt8.BtnForeColor = System.Drawing.Color.White;
            this.ucBtnExt8.BtnText = "圆角10";
            this.ucBtnExt8.ConerRadius = 10;
            this.ucBtnExt8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnExt8.EnabledMouseEffect = true;
            this.ucBtnExt8.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(184)))), ((int)(((byte)(0)))));
            this.ucBtnExt8.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnExt8.ForeColor = System.Drawing.Color.White;
            this.ucBtnExt8.IsRadius = true;
            this.ucBtnExt8.IsShowRect = false;
            this.ucBtnExt8.IsShowTips = false;
            this.ucBtnExt8.Location = new System.Drawing.Point(353, 17);
            this.ucBtnExt8.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnExt8.Name = "ucBtnExt8";
            this.ucBtnExt8.RectColor = System.Drawing.Color.Gainsboro;
            this.ucBtnExt8.RectWidth = 1;
            this.ucBtnExt8.Size = new System.Drawing.Size(97, 34);
            this.ucBtnExt8.TabIndex = 15;
            this.ucBtnExt8.TabStop = false;
            this.ucBtnExt8.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnExt8.TipsText = "";
            // 
            // ucBtnExt9
            // 
            this.ucBtnExt9.BackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt9.BtnBackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt9.BtnFont = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ucBtnExt9.BtnForeColor = System.Drawing.Color.White;
            this.ucBtnExt9.BtnText = "圆角10";
            this.ucBtnExt9.ConerRadius = 10;
            this.ucBtnExt9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnExt9.EnabledMouseEffect = true;
            this.ucBtnExt9.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(87)))), ((int)(((byte)(34)))));
            this.ucBtnExt9.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnExt9.ForeColor = System.Drawing.Color.White;
            this.ucBtnExt9.IsRadius = true;
            this.ucBtnExt9.IsShowRect = false;
            this.ucBtnExt9.IsShowTips = false;
            this.ucBtnExt9.Location = new System.Drawing.Point(477, 17);
            this.ucBtnExt9.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnExt9.Name = "ucBtnExt9";
            this.ucBtnExt9.RectColor = System.Drawing.Color.Gainsboro;
            this.ucBtnExt9.RectWidth = 1;
            this.ucBtnExt9.Size = new System.Drawing.Size(97, 34);
            this.ucBtnExt9.TabIndex = 15;
            this.ucBtnExt9.TabStop = false;
            this.ucBtnExt9.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnExt9.TipsText = "";
            // 
            // ucBtnExt2
            // 
            this.ucBtnExt2.BackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt2.BtnBackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt2.BtnFont = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ucBtnExt2.BtnForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnExt2.BtnText = "圆角5";
            this.ucBtnExt2.ConerRadius = 5;
            this.ucBtnExt2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnExt2.EnabledMouseEffect = true;
            this.ucBtnExt2.FillColor = System.Drawing.Color.White;
            this.ucBtnExt2.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnExt2.ForeColor = System.Drawing.Color.White;
            this.ucBtnExt2.IsRadius = true;
            this.ucBtnExt2.IsShowRect = true;
            this.ucBtnExt2.IsShowTips = false;
            this.ucBtnExt2.Location = new System.Drawing.Point(15, 62);
            this.ucBtnExt2.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnExt2.Name = "ucBtnExt2";
            this.ucBtnExt2.RectColor = System.Drawing.Color.Gainsboro;
            this.ucBtnExt2.RectWidth = 1;
            this.ucBtnExt2.Size = new System.Drawing.Size(97, 34);
            this.ucBtnExt2.TabIndex = 15;
            this.ucBtnExt2.TabStop = false;
            this.ucBtnExt2.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnExt2.TipsText = "";
            // 
            // ucBtnExt10
            // 
            this.ucBtnExt10.BackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt10.BtnBackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt10.BtnFont = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ucBtnExt10.BtnForeColor = System.Drawing.Color.White;
            this.ucBtnExt10.BtnText = "圆角5";
            this.ucBtnExt10.ConerRadius = 5;
            this.ucBtnExt10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnExt10.EnabledMouseEffect = true;
            this.ucBtnExt10.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.ucBtnExt10.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnExt10.ForeColor = System.Drawing.Color.White;
            this.ucBtnExt10.IsRadius = true;
            this.ucBtnExt10.IsShowRect = false;
            this.ucBtnExt10.IsShowTips = false;
            this.ucBtnExt10.Location = new System.Drawing.Point(124, 62);
            this.ucBtnExt10.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnExt10.Name = "ucBtnExt10";
            this.ucBtnExt10.RectColor = System.Drawing.Color.Gainsboro;
            this.ucBtnExt10.RectWidth = 1;
            this.ucBtnExt10.Size = new System.Drawing.Size(97, 34);
            this.ucBtnExt10.TabIndex = 15;
            this.ucBtnExt10.TabStop = false;
            this.ucBtnExt10.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnExt10.TipsText = "";
            // 
            // ucBtnExt11
            // 
            this.ucBtnExt11.BackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt11.BtnBackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt11.BtnFont = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ucBtnExt11.BtnForeColor = System.Drawing.Color.White;
            this.ucBtnExt11.BtnText = "圆角5";
            this.ucBtnExt11.ConerRadius = 5;
            this.ucBtnExt11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnExt11.EnabledMouseEffect = true;
            this.ucBtnExt11.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(159)))), ((int)(((byte)(255)))));
            this.ucBtnExt11.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnExt11.ForeColor = System.Drawing.Color.White;
            this.ucBtnExt11.IsRadius = true;
            this.ucBtnExt11.IsShowRect = false;
            this.ucBtnExt11.IsShowTips = false;
            this.ucBtnExt11.Location = new System.Drawing.Point(237, 62);
            this.ucBtnExt11.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnExt11.Name = "ucBtnExt11";
            this.ucBtnExt11.RectColor = System.Drawing.Color.Gainsboro;
            this.ucBtnExt11.RectWidth = 1;
            this.ucBtnExt11.Size = new System.Drawing.Size(97, 34);
            this.ucBtnExt11.TabIndex = 15;
            this.ucBtnExt11.TabStop = false;
            this.ucBtnExt11.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnExt11.TipsText = "";
            // 
            // ucBtnExt12
            // 
            this.ucBtnExt12.BackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt12.BtnBackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt12.BtnFont = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ucBtnExt12.BtnForeColor = System.Drawing.Color.White;
            this.ucBtnExt12.BtnText = "圆角5";
            this.ucBtnExt12.ConerRadius = 5;
            this.ucBtnExt12.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnExt12.EnabledMouseEffect = true;
            this.ucBtnExt12.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(184)))), ((int)(((byte)(0)))));
            this.ucBtnExt12.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnExt12.ForeColor = System.Drawing.Color.White;
            this.ucBtnExt12.IsRadius = true;
            this.ucBtnExt12.IsShowRect = false;
            this.ucBtnExt12.IsShowTips = false;
            this.ucBtnExt12.Location = new System.Drawing.Point(353, 62);
            this.ucBtnExt12.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnExt12.Name = "ucBtnExt12";
            this.ucBtnExt12.RectColor = System.Drawing.Color.Gainsboro;
            this.ucBtnExt12.RectWidth = 1;
            this.ucBtnExt12.Size = new System.Drawing.Size(97, 34);
            this.ucBtnExt12.TabIndex = 15;
            this.ucBtnExt12.TabStop = false;
            this.ucBtnExt12.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnExt12.TipsText = "";
            // 
            // ucBtnExt13
            // 
            this.ucBtnExt13.BackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt13.BtnBackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt13.BtnFont = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ucBtnExt13.BtnForeColor = System.Drawing.Color.White;
            this.ucBtnExt13.BtnText = "圆角5";
            this.ucBtnExt13.ConerRadius = 5;
            this.ucBtnExt13.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnExt13.EnabledMouseEffect = true;
            this.ucBtnExt13.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(87)))), ((int)(((byte)(34)))));
            this.ucBtnExt13.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnExt13.ForeColor = System.Drawing.Color.White;
            this.ucBtnExt13.IsRadius = true;
            this.ucBtnExt13.IsShowRect = false;
            this.ucBtnExt13.IsShowTips = false;
            this.ucBtnExt13.Location = new System.Drawing.Point(477, 62);
            this.ucBtnExt13.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnExt13.Name = "ucBtnExt13";
            this.ucBtnExt13.RectColor = System.Drawing.Color.Gainsboro;
            this.ucBtnExt13.RectWidth = 1;
            this.ucBtnExt13.Size = new System.Drawing.Size(97, 34);
            this.ucBtnExt13.TabIndex = 15;
            this.ucBtnExt13.TabStop = false;
            this.ucBtnExt13.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnExt13.TipsText = "";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.ucBtnExt1);
            this.groupBox1.Controls.Add(this.ucBtnExt6);
            this.groupBox1.Controls.Add(this.ucBtnExt33);
            this.groupBox1.Controls.Add(this.ucBtnExt2);
            this.groupBox1.Controls.Add(this.ucBtnExt32);
            this.groupBox1.Controls.Add(this.ucBtnExt10);
            this.groupBox1.Controls.Add(this.ucBtnExt31);
            this.groupBox1.Controls.Add(this.ucBtnExt13);
            this.groupBox1.Controls.Add(this.ucBtnExt7);
            this.groupBox1.Controls.Add(this.ucBtnExt30);
            this.groupBox1.Controls.Add(this.ucBtnExt9);
            this.groupBox1.Controls.Add(this.ucBtnExt29);
            this.groupBox1.Controls.Add(this.ucBtnExt11);
            this.groupBox1.Controls.Add(this.ucBtnExt12);
            this.groupBox1.Controls.Add(this.ucBtnExt8);
            this.groupBox1.Location = new System.Drawing.Point(3, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(617, 152);
            this.groupBox1.TabIndex = 21;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "圆角";
            // 
            // ucBtnExt33
            // 
            this.ucBtnExt33.BackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt33.BtnBackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt33.BtnFont = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ucBtnExt33.BtnForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnExt33.BtnText = "椭圆";
            this.ucBtnExt33.ConerRadius = 34;
            this.ucBtnExt33.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnExt33.EnabledMouseEffect = true;
            this.ucBtnExt33.FillColor = System.Drawing.Color.White;
            this.ucBtnExt33.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnExt33.ForeColor = System.Drawing.Color.White;
            this.ucBtnExt33.IsRadius = true;
            this.ucBtnExt33.IsShowRect = true;
            this.ucBtnExt33.IsShowTips = false;
            this.ucBtnExt33.Location = new System.Drawing.Point(15, 108);
            this.ucBtnExt33.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnExt33.Name = "ucBtnExt33";
            this.ucBtnExt33.RectColor = System.Drawing.Color.Gainsboro;
            this.ucBtnExt33.RectWidth = 1;
            this.ucBtnExt33.Size = new System.Drawing.Size(97, 34);
            this.ucBtnExt33.TabIndex = 15;
            this.ucBtnExt33.TabStop = false;
            this.ucBtnExt33.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnExt33.TipsText = "";
            // 
            // ucBtnExt32
            // 
            this.ucBtnExt32.BackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt32.BtnBackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt32.BtnFont = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ucBtnExt32.BtnForeColor = System.Drawing.Color.White;
            this.ucBtnExt32.BtnText = "椭圆";
            this.ucBtnExt32.ConerRadius = 34;
            this.ucBtnExt32.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnExt32.EnabledMouseEffect = true;
            this.ucBtnExt32.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.ucBtnExt32.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnExt32.ForeColor = System.Drawing.Color.White;
            this.ucBtnExt32.IsRadius = true;
            this.ucBtnExt32.IsShowRect = false;
            this.ucBtnExt32.IsShowTips = false;
            this.ucBtnExt32.Location = new System.Drawing.Point(124, 108);
            this.ucBtnExt32.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnExt32.Name = "ucBtnExt32";
            this.ucBtnExt32.RectColor = System.Drawing.Color.Gainsboro;
            this.ucBtnExt32.RectWidth = 1;
            this.ucBtnExt32.Size = new System.Drawing.Size(97, 34);
            this.ucBtnExt32.TabIndex = 15;
            this.ucBtnExt32.TabStop = false;
            this.ucBtnExt32.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnExt32.TipsText = "";
            // 
            // ucBtnExt31
            // 
            this.ucBtnExt31.BackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt31.BtnBackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt31.BtnFont = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ucBtnExt31.BtnForeColor = System.Drawing.Color.White;
            this.ucBtnExt31.BtnText = "椭圆";
            this.ucBtnExt31.ConerRadius = 34;
            this.ucBtnExt31.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnExt31.EnabledMouseEffect = true;
            this.ucBtnExt31.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(87)))), ((int)(((byte)(34)))));
            this.ucBtnExt31.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnExt31.ForeColor = System.Drawing.Color.White;
            this.ucBtnExt31.IsRadius = true;
            this.ucBtnExt31.IsShowRect = false;
            this.ucBtnExt31.IsShowTips = false;
            this.ucBtnExt31.Location = new System.Drawing.Point(477, 108);
            this.ucBtnExt31.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnExt31.Name = "ucBtnExt31";
            this.ucBtnExt31.RectColor = System.Drawing.Color.Gainsboro;
            this.ucBtnExt31.RectWidth = 1;
            this.ucBtnExt31.Size = new System.Drawing.Size(97, 34);
            this.ucBtnExt31.TabIndex = 15;
            this.ucBtnExt31.TabStop = false;
            this.ucBtnExt31.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnExt31.TipsText = "";
            // 
            // ucBtnExt30
            // 
            this.ucBtnExt30.BackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt30.BtnBackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt30.BtnFont = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ucBtnExt30.BtnForeColor = System.Drawing.Color.White;
            this.ucBtnExt30.BtnText = "椭圆";
            this.ucBtnExt30.ConerRadius = 34;
            this.ucBtnExt30.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnExt30.EnabledMouseEffect = true;
            this.ucBtnExt30.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(159)))), ((int)(((byte)(255)))));
            this.ucBtnExt30.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnExt30.ForeColor = System.Drawing.Color.White;
            this.ucBtnExt30.IsRadius = true;
            this.ucBtnExt30.IsShowRect = false;
            this.ucBtnExt30.IsShowTips = false;
            this.ucBtnExt30.Location = new System.Drawing.Point(237, 108);
            this.ucBtnExt30.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnExt30.Name = "ucBtnExt30";
            this.ucBtnExt30.RectColor = System.Drawing.Color.Gainsboro;
            this.ucBtnExt30.RectWidth = 1;
            this.ucBtnExt30.Size = new System.Drawing.Size(97, 34);
            this.ucBtnExt30.TabIndex = 15;
            this.ucBtnExt30.TabStop = false;
            this.ucBtnExt30.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnExt30.TipsText = "";
            // 
            // ucBtnExt29
            // 
            this.ucBtnExt29.BackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt29.BtnBackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt29.BtnFont = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ucBtnExt29.BtnForeColor = System.Drawing.Color.White;
            this.ucBtnExt29.BtnText = "椭圆";
            this.ucBtnExt29.ConerRadius = 34;
            this.ucBtnExt29.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnExt29.EnabledMouseEffect = true;
            this.ucBtnExt29.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(184)))), ((int)(((byte)(0)))));
            this.ucBtnExt29.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnExt29.ForeColor = System.Drawing.Color.White;
            this.ucBtnExt29.IsRadius = true;
            this.ucBtnExt29.IsShowRect = false;
            this.ucBtnExt29.IsShowTips = false;
            this.ucBtnExt29.Location = new System.Drawing.Point(353, 108);
            this.ucBtnExt29.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnExt29.Name = "ucBtnExt29";
            this.ucBtnExt29.RectColor = System.Drawing.Color.Gainsboro;
            this.ucBtnExt29.RectWidth = 1;
            this.ucBtnExt29.Size = new System.Drawing.Size(97, 34);
            this.ucBtnExt29.TabIndex = 15;
            this.ucBtnExt29.TabStop = false;
            this.ucBtnExt29.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnExt29.TipsText = "";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.ucBtnExt28);
            this.groupBox2.Controls.Add(this.ucBtnExt23);
            this.groupBox2.Controls.Add(this.ucBtnExt16);
            this.groupBox2.Controls.Add(this.ucBtnExt27);
            this.groupBox2.Controls.Add(this.ucBtnExt20);
            this.groupBox2.Controls.Add(this.ucBtnExt26);
            this.groupBox2.Controls.Add(this.ucBtnExt19);
            this.groupBox2.Controls.Add(this.ucBtnExt17);
            this.groupBox2.Controls.Add(this.ucBtnExt25);
            this.groupBox2.Controls.Add(this.ucBtnExt15);
            this.groupBox2.Controls.Add(this.ucBtnExt24);
            this.groupBox2.Controls.Add(this.ucBtnExt18);
            this.groupBox2.Controls.Add(this.ucBtnExt14);
            this.groupBox2.Controls.Add(this.ucBtnExt21);
            this.groupBox2.Controls.Add(this.ucBtnExt22);
            this.groupBox2.Location = new System.Drawing.Point(3, 171);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(617, 168);
            this.groupBox2.TabIndex = 21;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "尺寸";
            // 
            // ucBtnExt28
            // 
            this.ucBtnExt28.BackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt28.BtnBackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt28.BtnFont = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ucBtnExt28.BtnForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnExt28.BtnText = "小";
            this.ucBtnExt28.ConerRadius = 5;
            this.ucBtnExt28.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnExt28.EnabledMouseEffect = true;
            this.ucBtnExt28.FillColor = System.Drawing.Color.White;
            this.ucBtnExt28.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnExt28.ForeColor = System.Drawing.Color.White;
            this.ucBtnExt28.IsRadius = true;
            this.ucBtnExt28.IsShowRect = true;
            this.ucBtnExt28.IsShowTips = false;
            this.ucBtnExt28.Location = new System.Drawing.Point(15, 118);
            this.ucBtnExt28.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnExt28.Name = "ucBtnExt28";
            this.ucBtnExt28.RectColor = System.Drawing.Color.Gainsboro;
            this.ucBtnExt28.RectWidth = 1;
            this.ucBtnExt28.Size = new System.Drawing.Size(56, 31);
            this.ucBtnExt28.TabIndex = 15;
            this.ucBtnExt28.TabStop = false;
            this.ucBtnExt28.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnExt28.TipsText = "";
            // 
            // ucBtnExt23
            // 
            this.ucBtnExt23.BackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt23.BtnBackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt23.BtnFont = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ucBtnExt23.BtnForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnExt23.BtnText = "中";
            this.ucBtnExt23.ConerRadius = 5;
            this.ucBtnExt23.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnExt23.EnabledMouseEffect = true;
            this.ucBtnExt23.FillColor = System.Drawing.Color.White;
            this.ucBtnExt23.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnExt23.ForeColor = System.Drawing.Color.White;
            this.ucBtnExt23.IsRadius = true;
            this.ucBtnExt23.IsShowRect = true;
            this.ucBtnExt23.IsShowTips = false;
            this.ucBtnExt23.Location = new System.Drawing.Point(15, 75);
            this.ucBtnExt23.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnExt23.Name = "ucBtnExt23";
            this.ucBtnExt23.RectColor = System.Drawing.Color.Gainsboro;
            this.ucBtnExt23.RectWidth = 1;
            this.ucBtnExt23.Size = new System.Drawing.Size(80, 31);
            this.ucBtnExt23.TabIndex = 15;
            this.ucBtnExt23.TabStop = false;
            this.ucBtnExt23.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnExt23.TipsText = "";
            // 
            // ucBtnExt16
            // 
            this.ucBtnExt16.BackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt16.BtnBackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt16.BtnFont = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ucBtnExt16.BtnForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnExt16.BtnText = "大";
            this.ucBtnExt16.ConerRadius = 5;
            this.ucBtnExt16.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnExt16.EnabledMouseEffect = true;
            this.ucBtnExt16.FillColor = System.Drawing.Color.White;
            this.ucBtnExt16.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnExt16.ForeColor = System.Drawing.Color.White;
            this.ucBtnExt16.IsRadius = true;
            this.ucBtnExt16.IsShowRect = true;
            this.ucBtnExt16.IsShowTips = false;
            this.ucBtnExt16.Location = new System.Drawing.Point(15, 17);
            this.ucBtnExt16.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnExt16.Name = "ucBtnExt16";
            this.ucBtnExt16.RectColor = System.Drawing.Color.Gainsboro;
            this.ucBtnExt16.RectWidth = 1;
            this.ucBtnExt16.Size = new System.Drawing.Size(97, 47);
            this.ucBtnExt16.TabIndex = 15;
            this.ucBtnExt16.TabStop = false;
            this.ucBtnExt16.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnExt16.TipsText = "";
            // 
            // ucBtnExt27
            // 
            this.ucBtnExt27.BackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt27.BtnBackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt27.BtnFont = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ucBtnExt27.BtnForeColor = System.Drawing.Color.White;
            this.ucBtnExt27.BtnText = "小";
            this.ucBtnExt27.ConerRadius = 5;
            this.ucBtnExt27.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnExt27.EnabledMouseEffect = true;
            this.ucBtnExt27.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.ucBtnExt27.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnExt27.ForeColor = System.Drawing.Color.White;
            this.ucBtnExt27.IsRadius = true;
            this.ucBtnExt27.IsShowRect = false;
            this.ucBtnExt27.IsShowTips = false;
            this.ucBtnExt27.Location = new System.Drawing.Point(124, 118);
            this.ucBtnExt27.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnExt27.Name = "ucBtnExt27";
            this.ucBtnExt27.RectColor = System.Drawing.Color.Gainsboro;
            this.ucBtnExt27.RectWidth = 1;
            this.ucBtnExt27.Size = new System.Drawing.Size(56, 31);
            this.ucBtnExt27.TabIndex = 15;
            this.ucBtnExt27.TabStop = false;
            this.ucBtnExt27.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnExt27.TipsText = "";
            // 
            // ucBtnExt20
            // 
            this.ucBtnExt20.BackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt20.BtnBackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt20.BtnFont = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ucBtnExt20.BtnForeColor = System.Drawing.Color.White;
            this.ucBtnExt20.BtnText = "中";
            this.ucBtnExt20.ConerRadius = 5;
            this.ucBtnExt20.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnExt20.EnabledMouseEffect = true;
            this.ucBtnExt20.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.ucBtnExt20.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnExt20.ForeColor = System.Drawing.Color.White;
            this.ucBtnExt20.IsRadius = true;
            this.ucBtnExt20.IsShowRect = false;
            this.ucBtnExt20.IsShowTips = false;
            this.ucBtnExt20.Location = new System.Drawing.Point(124, 75);
            this.ucBtnExt20.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnExt20.Name = "ucBtnExt20";
            this.ucBtnExt20.RectColor = System.Drawing.Color.Gainsboro;
            this.ucBtnExt20.RectWidth = 1;
            this.ucBtnExt20.Size = new System.Drawing.Size(80, 31);
            this.ucBtnExt20.TabIndex = 15;
            this.ucBtnExt20.TabStop = false;
            this.ucBtnExt20.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnExt20.TipsText = "";
            // 
            // ucBtnExt26
            // 
            this.ucBtnExt26.BackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt26.BtnBackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt26.BtnFont = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ucBtnExt26.BtnForeColor = System.Drawing.Color.White;
            this.ucBtnExt26.BtnText = "小";
            this.ucBtnExt26.ConerRadius = 5;
            this.ucBtnExt26.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnExt26.EnabledMouseEffect = true;
            this.ucBtnExt26.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(87)))), ((int)(((byte)(34)))));
            this.ucBtnExt26.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnExt26.ForeColor = System.Drawing.Color.White;
            this.ucBtnExt26.IsRadius = true;
            this.ucBtnExt26.IsShowRect = false;
            this.ucBtnExt26.IsShowTips = false;
            this.ucBtnExt26.Location = new System.Drawing.Point(477, 118);
            this.ucBtnExt26.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnExt26.Name = "ucBtnExt26";
            this.ucBtnExt26.RectColor = System.Drawing.Color.Gainsboro;
            this.ucBtnExt26.RectWidth = 1;
            this.ucBtnExt26.Size = new System.Drawing.Size(56, 31);
            this.ucBtnExt26.TabIndex = 15;
            this.ucBtnExt26.TabStop = false;
            this.ucBtnExt26.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnExt26.TipsText = "";
            // 
            // ucBtnExt19
            // 
            this.ucBtnExt19.BackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt19.BtnBackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt19.BtnFont = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ucBtnExt19.BtnForeColor = System.Drawing.Color.White;
            this.ucBtnExt19.BtnText = "中";
            this.ucBtnExt19.ConerRadius = 5;
            this.ucBtnExt19.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnExt19.EnabledMouseEffect = true;
            this.ucBtnExt19.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(87)))), ((int)(((byte)(34)))));
            this.ucBtnExt19.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnExt19.ForeColor = System.Drawing.Color.White;
            this.ucBtnExt19.IsRadius = true;
            this.ucBtnExt19.IsShowRect = false;
            this.ucBtnExt19.IsShowTips = false;
            this.ucBtnExt19.Location = new System.Drawing.Point(477, 75);
            this.ucBtnExt19.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnExt19.Name = "ucBtnExt19";
            this.ucBtnExt19.RectColor = System.Drawing.Color.Gainsboro;
            this.ucBtnExt19.RectWidth = 1;
            this.ucBtnExt19.Size = new System.Drawing.Size(80, 31);
            this.ucBtnExt19.TabIndex = 15;
            this.ucBtnExt19.TabStop = false;
            this.ucBtnExt19.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnExt19.TipsText = "";
            // 
            // ucBtnExt17
            // 
            this.ucBtnExt17.BackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt17.BtnBackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt17.BtnFont = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ucBtnExt17.BtnForeColor = System.Drawing.Color.White;
            this.ucBtnExt17.BtnText = "大";
            this.ucBtnExt17.ConerRadius = 5;
            this.ucBtnExt17.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnExt17.EnabledMouseEffect = true;
            this.ucBtnExt17.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.ucBtnExt17.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnExt17.ForeColor = System.Drawing.Color.White;
            this.ucBtnExt17.IsRadius = true;
            this.ucBtnExt17.IsShowRect = false;
            this.ucBtnExt17.IsShowTips = false;
            this.ucBtnExt17.Location = new System.Drawing.Point(124, 17);
            this.ucBtnExt17.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnExt17.Name = "ucBtnExt17";
            this.ucBtnExt17.RectColor = System.Drawing.Color.Gainsboro;
            this.ucBtnExt17.RectWidth = 1;
            this.ucBtnExt17.Size = new System.Drawing.Size(97, 47);
            this.ucBtnExt17.TabIndex = 15;
            this.ucBtnExt17.TabStop = false;
            this.ucBtnExt17.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnExt17.TipsText = "";
            // 
            // ucBtnExt25
            // 
            this.ucBtnExt25.BackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt25.BtnBackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt25.BtnFont = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ucBtnExt25.BtnForeColor = System.Drawing.Color.White;
            this.ucBtnExt25.BtnText = "小";
            this.ucBtnExt25.ConerRadius = 5;
            this.ucBtnExt25.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnExt25.EnabledMouseEffect = true;
            this.ucBtnExt25.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(159)))), ((int)(((byte)(255)))));
            this.ucBtnExt25.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnExt25.ForeColor = System.Drawing.Color.White;
            this.ucBtnExt25.IsRadius = true;
            this.ucBtnExt25.IsShowRect = false;
            this.ucBtnExt25.IsShowTips = false;
            this.ucBtnExt25.Location = new System.Drawing.Point(237, 118);
            this.ucBtnExt25.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnExt25.Name = "ucBtnExt25";
            this.ucBtnExt25.RectColor = System.Drawing.Color.Gainsboro;
            this.ucBtnExt25.RectWidth = 1;
            this.ucBtnExt25.Size = new System.Drawing.Size(56, 31);
            this.ucBtnExt25.TabIndex = 15;
            this.ucBtnExt25.TabStop = false;
            this.ucBtnExt25.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnExt25.TipsText = "";
            // 
            // ucBtnExt15
            // 
            this.ucBtnExt15.BackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt15.BtnBackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt15.BtnFont = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ucBtnExt15.BtnForeColor = System.Drawing.Color.White;
            this.ucBtnExt15.BtnText = "中";
            this.ucBtnExt15.ConerRadius = 5;
            this.ucBtnExt15.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnExt15.EnabledMouseEffect = true;
            this.ucBtnExt15.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(159)))), ((int)(((byte)(255)))));
            this.ucBtnExt15.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnExt15.ForeColor = System.Drawing.Color.White;
            this.ucBtnExt15.IsRadius = true;
            this.ucBtnExt15.IsShowRect = false;
            this.ucBtnExt15.IsShowTips = false;
            this.ucBtnExt15.Location = new System.Drawing.Point(237, 75);
            this.ucBtnExt15.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnExt15.Name = "ucBtnExt15";
            this.ucBtnExt15.RectColor = System.Drawing.Color.Gainsboro;
            this.ucBtnExt15.RectWidth = 1;
            this.ucBtnExt15.Size = new System.Drawing.Size(80, 31);
            this.ucBtnExt15.TabIndex = 15;
            this.ucBtnExt15.TabStop = false;
            this.ucBtnExt15.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnExt15.TipsText = "";
            // 
            // ucBtnExt24
            // 
            this.ucBtnExt24.BackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt24.BtnBackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt24.BtnFont = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ucBtnExt24.BtnForeColor = System.Drawing.Color.White;
            this.ucBtnExt24.BtnText = "小";
            this.ucBtnExt24.ConerRadius = 5;
            this.ucBtnExt24.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnExt24.EnabledMouseEffect = true;
            this.ucBtnExt24.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(184)))), ((int)(((byte)(0)))));
            this.ucBtnExt24.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnExt24.ForeColor = System.Drawing.Color.White;
            this.ucBtnExt24.IsRadius = true;
            this.ucBtnExt24.IsShowRect = false;
            this.ucBtnExt24.IsShowTips = false;
            this.ucBtnExt24.Location = new System.Drawing.Point(353, 118);
            this.ucBtnExt24.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnExt24.Name = "ucBtnExt24";
            this.ucBtnExt24.RectColor = System.Drawing.Color.Gainsboro;
            this.ucBtnExt24.RectWidth = 1;
            this.ucBtnExt24.Size = new System.Drawing.Size(56, 31);
            this.ucBtnExt24.TabIndex = 15;
            this.ucBtnExt24.TabStop = false;
            this.ucBtnExt24.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnExt24.TipsText = "";
            // 
            // ucBtnExt18
            // 
            this.ucBtnExt18.BackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt18.BtnBackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt18.BtnFont = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ucBtnExt18.BtnForeColor = System.Drawing.Color.White;
            this.ucBtnExt18.BtnText = "大";
            this.ucBtnExt18.ConerRadius = 5;
            this.ucBtnExt18.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnExt18.EnabledMouseEffect = true;
            this.ucBtnExt18.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(87)))), ((int)(((byte)(34)))));
            this.ucBtnExt18.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnExt18.ForeColor = System.Drawing.Color.White;
            this.ucBtnExt18.IsRadius = true;
            this.ucBtnExt18.IsShowRect = false;
            this.ucBtnExt18.IsShowTips = false;
            this.ucBtnExt18.Location = new System.Drawing.Point(477, 17);
            this.ucBtnExt18.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnExt18.Name = "ucBtnExt18";
            this.ucBtnExt18.RectColor = System.Drawing.Color.Gainsboro;
            this.ucBtnExt18.RectWidth = 1;
            this.ucBtnExt18.Size = new System.Drawing.Size(97, 47);
            this.ucBtnExt18.TabIndex = 15;
            this.ucBtnExt18.TabStop = false;
            this.ucBtnExt18.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnExt18.TipsText = "";
            // 
            // ucBtnExt14
            // 
            this.ucBtnExt14.BackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt14.BtnBackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt14.BtnFont = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ucBtnExt14.BtnForeColor = System.Drawing.Color.White;
            this.ucBtnExt14.BtnText = "中";
            this.ucBtnExt14.ConerRadius = 5;
            this.ucBtnExt14.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnExt14.EnabledMouseEffect = true;
            this.ucBtnExt14.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(184)))), ((int)(((byte)(0)))));
            this.ucBtnExt14.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnExt14.ForeColor = System.Drawing.Color.White;
            this.ucBtnExt14.IsRadius = true;
            this.ucBtnExt14.IsShowRect = false;
            this.ucBtnExt14.IsShowTips = false;
            this.ucBtnExt14.Location = new System.Drawing.Point(353, 75);
            this.ucBtnExt14.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnExt14.Name = "ucBtnExt14";
            this.ucBtnExt14.RectColor = System.Drawing.Color.Gainsboro;
            this.ucBtnExt14.RectWidth = 1;
            this.ucBtnExt14.Size = new System.Drawing.Size(80, 31);
            this.ucBtnExt14.TabIndex = 15;
            this.ucBtnExt14.TabStop = false;
            this.ucBtnExt14.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnExt14.TipsText = "";
            // 
            // ucBtnExt21
            // 
            this.ucBtnExt21.BackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt21.BtnBackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt21.BtnFont = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ucBtnExt21.BtnForeColor = System.Drawing.Color.White;
            this.ucBtnExt21.BtnText = "大";
            this.ucBtnExt21.ConerRadius = 5;
            this.ucBtnExt21.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnExt21.EnabledMouseEffect = true;
            this.ucBtnExt21.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(159)))), ((int)(((byte)(255)))));
            this.ucBtnExt21.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnExt21.ForeColor = System.Drawing.Color.White;
            this.ucBtnExt21.IsRadius = true;
            this.ucBtnExt21.IsShowRect = false;
            this.ucBtnExt21.IsShowTips = false;
            this.ucBtnExt21.Location = new System.Drawing.Point(237, 17);
            this.ucBtnExt21.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnExt21.Name = "ucBtnExt21";
            this.ucBtnExt21.RectColor = System.Drawing.Color.Gainsboro;
            this.ucBtnExt21.RectWidth = 1;
            this.ucBtnExt21.Size = new System.Drawing.Size(97, 47);
            this.ucBtnExt21.TabIndex = 15;
            this.ucBtnExt21.TabStop = false;
            this.ucBtnExt21.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnExt21.TipsText = "";
            // 
            // ucBtnExt22
            // 
            this.ucBtnExt22.BackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt22.BtnBackColor = System.Drawing.Color.Transparent;
            this.ucBtnExt22.BtnFont = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ucBtnExt22.BtnForeColor = System.Drawing.Color.White;
            this.ucBtnExt22.BtnText = "大";
            this.ucBtnExt22.ConerRadius = 5;
            this.ucBtnExt22.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnExt22.EnabledMouseEffect = true;
            this.ucBtnExt22.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(184)))), ((int)(((byte)(0)))));
            this.ucBtnExt22.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnExt22.ForeColor = System.Drawing.Color.White;
            this.ucBtnExt22.IsRadius = true;
            this.ucBtnExt22.IsShowRect = false;
            this.ucBtnExt22.IsShowTips = false;
            this.ucBtnExt22.Location = new System.Drawing.Point(353, 17);
            this.ucBtnExt22.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnExt22.Name = "ucBtnExt22";
            this.ucBtnExt22.RectColor = System.Drawing.Color.Gainsboro;
            this.ucBtnExt22.RectWidth = 1;
            this.ucBtnExt22.Size = new System.Drawing.Size(97, 47);
            this.ucBtnExt22.TabIndex = 15;
            this.ucBtnExt22.TabStop = false;
            this.ucBtnExt22.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnExt22.TipsText = "";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.ucBtnImg16);
            this.groupBox3.Controls.Add(this.ucBtnImg11);
            this.groupBox3.Controls.Add(this.ucBtnImg6);
            this.groupBox3.Controls.Add(this.ucBtnImg15);
            this.groupBox3.Controls.Add(this.ucBtnImg10);
            this.groupBox3.Controls.Add(this.ucBtnImg14);
            this.groupBox3.Controls.Add(this.ucBtnImg9);
            this.groupBox3.Controls.Add(this.ucBtnImg5);
            this.groupBox3.Controls.Add(this.ucBtnImg13);
            this.groupBox3.Controls.Add(this.ucBtnImg8);
            this.groupBox3.Controls.Add(this.ucBtnImg12);
            this.groupBox3.Controls.Add(this.ucBtnImg4);
            this.groupBox3.Controls.Add(this.ucBtnImg7);
            this.groupBox3.Controls.Add(this.ucBtnImg3);
            this.groupBox3.Controls.Add(this.ucBtnImg2);
            this.groupBox3.Location = new System.Drawing.Point(3, 345);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(617, 168);
            this.groupBox3.TabIndex = 21;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "图标";
            // 
            // ucBtnImg16
            // 
            this.ucBtnImg16.BackColor = System.Drawing.Color.White;
            this.ucBtnImg16.BtnBackColor = System.Drawing.Color.White;
            this.ucBtnImg16.BtnFont = new System.Drawing.Font("微软雅黑", 15F);
            this.ucBtnImg16.BtnForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg16.BtnText = "";
            this.ucBtnImg16.ConerRadius = 10;
            this.ucBtnImg16.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnImg16.EnabledMouseEffect = true;
            this.ucBtnImg16.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(87)))), ((int)(((byte)(34)))));
            this.ucBtnImg16.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnImg16.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg16.Image = ((System.Drawing.Image)(resources.GetObject("ucBtnImg16.Image")));
            this.ucBtnImg16.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg16.ImageFontIcons = ((object)(resources.GetObject("ucBtnImg16.ImageFontIcons")));
            this.ucBtnImg16.IsRadius = true;
            this.ucBtnImg16.IsShowRect = false;
            this.ucBtnImg16.IsShowTips = false;
            this.ucBtnImg16.Location = new System.Drawing.Point(477, 119);
            this.ucBtnImg16.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnImg16.Name = "ucBtnImg16";
            this.ucBtnImg16.RectColor = System.Drawing.Color.Gainsboro;
            this.ucBtnImg16.RectWidth = 1;
            this.ucBtnImg16.Size = new System.Drawing.Size(56, 31);
            this.ucBtnImg16.TabIndex = 18;
            this.ucBtnImg16.TabStop = false;
            this.ucBtnImg16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg16.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnImg16.TipsText = "";
            // 
            // ucBtnImg11
            // 
            this.ucBtnImg11.BackColor = System.Drawing.Color.White;
            this.ucBtnImg11.BtnBackColor = System.Drawing.Color.White;
            this.ucBtnImg11.BtnFont = new System.Drawing.Font("微软雅黑", 15F);
            this.ucBtnImg11.BtnForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg11.BtnText = "";
            this.ucBtnImg11.ConerRadius = 10;
            this.ucBtnImg11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnImg11.EnabledMouseEffect = true;
            this.ucBtnImg11.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(87)))), ((int)(((byte)(34)))));
            this.ucBtnImg11.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnImg11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg11.Image = ((System.Drawing.Image)(resources.GetObject("ucBtnImg11.Image")));
            this.ucBtnImg11.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg11.ImageFontIcons = ((object)(resources.GetObject("ucBtnImg11.ImageFontIcons")));
            this.ucBtnImg11.IsRadius = true;
            this.ucBtnImg11.IsShowRect = false;
            this.ucBtnImg11.IsShowTips = false;
            this.ucBtnImg11.Location = new System.Drawing.Point(477, 76);
            this.ucBtnImg11.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnImg11.Name = "ucBtnImg11";
            this.ucBtnImg11.RectColor = System.Drawing.Color.Gainsboro;
            this.ucBtnImg11.RectWidth = 1;
            this.ucBtnImg11.Size = new System.Drawing.Size(80, 31);
            this.ucBtnImg11.TabIndex = 18;
            this.ucBtnImg11.TabStop = false;
            this.ucBtnImg11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg11.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnImg11.TipsText = "";
            // 
            // ucBtnImg6
            // 
            this.ucBtnImg6.BackColor = System.Drawing.Color.White;
            this.ucBtnImg6.BtnBackColor = System.Drawing.Color.White;
            this.ucBtnImg6.BtnFont = new System.Drawing.Font("微软雅黑", 15F);
            this.ucBtnImg6.BtnForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg6.BtnText = "";
            this.ucBtnImg6.ConerRadius = 10;
            this.ucBtnImg6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnImg6.EnabledMouseEffect = true;
            this.ucBtnImg6.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(87)))), ((int)(((byte)(34)))));
            this.ucBtnImg6.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnImg6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg6.Image = ((System.Drawing.Image)(resources.GetObject("ucBtnImg6.Image")));
            this.ucBtnImg6.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg6.ImageFontIcons = ((object)(resources.GetObject("ucBtnImg6.ImageFontIcons")));
            this.ucBtnImg6.IsRadius = true;
            this.ucBtnImg6.IsShowRect = false;
            this.ucBtnImg6.IsShowTips = false;
            this.ucBtnImg6.Location = new System.Drawing.Point(477, 17);
            this.ucBtnImg6.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnImg6.Name = "ucBtnImg6";
            this.ucBtnImg6.RectColor = System.Drawing.Color.Gainsboro;
            this.ucBtnImg6.RectWidth = 1;
            this.ucBtnImg6.Size = new System.Drawing.Size(97, 47);
            this.ucBtnImg6.TabIndex = 18;
            this.ucBtnImg6.TabStop = false;
            this.ucBtnImg6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg6.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnImg6.TipsText = "";
            // 
            // ucBtnImg15
            // 
            this.ucBtnImg15.BackColor = System.Drawing.Color.White;
            this.ucBtnImg15.BtnBackColor = System.Drawing.Color.White;
            this.ucBtnImg15.BtnFont = new System.Drawing.Font("微软雅黑", 15F);
            this.ucBtnImg15.BtnForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg15.BtnText = "";
            this.ucBtnImg15.ConerRadius = 10;
            this.ucBtnImg15.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnImg15.EnabledMouseEffect = true;
            this.ucBtnImg15.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(184)))), ((int)(((byte)(0)))));
            this.ucBtnImg15.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnImg15.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg15.Image = ((System.Drawing.Image)(resources.GetObject("ucBtnImg15.Image")));
            this.ucBtnImg15.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg15.ImageFontIcons = ((object)(resources.GetObject("ucBtnImg15.ImageFontIcons")));
            this.ucBtnImg15.IsRadius = true;
            this.ucBtnImg15.IsShowRect = false;
            this.ucBtnImg15.IsShowTips = false;
            this.ucBtnImg15.Location = new System.Drawing.Point(353, 119);
            this.ucBtnImg15.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnImg15.Name = "ucBtnImg15";
            this.ucBtnImg15.RectColor = System.Drawing.Color.Gainsboro;
            this.ucBtnImg15.RectWidth = 1;
            this.ucBtnImg15.Size = new System.Drawing.Size(56, 31);
            this.ucBtnImg15.TabIndex = 18;
            this.ucBtnImg15.TabStop = false;
            this.ucBtnImg15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg15.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnImg15.TipsText = "";
            // 
            // ucBtnImg10
            // 
            this.ucBtnImg10.BackColor = System.Drawing.Color.White;
            this.ucBtnImg10.BtnBackColor = System.Drawing.Color.White;
            this.ucBtnImg10.BtnFont = new System.Drawing.Font("微软雅黑", 15F);
            this.ucBtnImg10.BtnForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg10.BtnText = "";
            this.ucBtnImg10.ConerRadius = 10;
            this.ucBtnImg10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnImg10.EnabledMouseEffect = true;
            this.ucBtnImg10.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(184)))), ((int)(((byte)(0)))));
            this.ucBtnImg10.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnImg10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg10.Image = ((System.Drawing.Image)(resources.GetObject("ucBtnImg10.Image")));
            this.ucBtnImg10.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg10.ImageFontIcons = ((object)(resources.GetObject("ucBtnImg10.ImageFontIcons")));
            this.ucBtnImg10.IsRadius = true;
            this.ucBtnImg10.IsShowRect = false;
            this.ucBtnImg10.IsShowTips = false;
            this.ucBtnImg10.Location = new System.Drawing.Point(353, 76);
            this.ucBtnImg10.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnImg10.Name = "ucBtnImg10";
            this.ucBtnImg10.RectColor = System.Drawing.Color.Gainsboro;
            this.ucBtnImg10.RectWidth = 1;
            this.ucBtnImg10.Size = new System.Drawing.Size(80, 31);
            this.ucBtnImg10.TabIndex = 18;
            this.ucBtnImg10.TabStop = false;
            this.ucBtnImg10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg10.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnImg10.TipsText = "";
            // 
            // ucBtnImg14
            // 
            this.ucBtnImg14.BackColor = System.Drawing.Color.White;
            this.ucBtnImg14.BtnBackColor = System.Drawing.Color.White;
            this.ucBtnImg14.BtnFont = new System.Drawing.Font("微软雅黑", 15F);
            this.ucBtnImg14.BtnForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg14.BtnText = "";
            this.ucBtnImg14.ConerRadius = 10;
            this.ucBtnImg14.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnImg14.EnabledMouseEffect = true;
            this.ucBtnImg14.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(159)))), ((int)(((byte)(255)))));
            this.ucBtnImg14.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnImg14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg14.Image = ((System.Drawing.Image)(resources.GetObject("ucBtnImg14.Image")));
            this.ucBtnImg14.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg14.ImageFontIcons = ((object)(resources.GetObject("ucBtnImg14.ImageFontIcons")));
            this.ucBtnImg14.IsRadius = true;
            this.ucBtnImg14.IsShowRect = false;
            this.ucBtnImg14.IsShowTips = false;
            this.ucBtnImg14.Location = new System.Drawing.Point(237, 119);
            this.ucBtnImg14.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnImg14.Name = "ucBtnImg14";
            this.ucBtnImg14.RectColor = System.Drawing.Color.Gainsboro;
            this.ucBtnImg14.RectWidth = 1;
            this.ucBtnImg14.Size = new System.Drawing.Size(56, 31);
            this.ucBtnImg14.TabIndex = 18;
            this.ucBtnImg14.TabStop = false;
            this.ucBtnImg14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg14.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnImg14.TipsText = "";
            // 
            // ucBtnImg9
            // 
            this.ucBtnImg9.BackColor = System.Drawing.Color.White;
            this.ucBtnImg9.BtnBackColor = System.Drawing.Color.White;
            this.ucBtnImg9.BtnFont = new System.Drawing.Font("微软雅黑", 15F);
            this.ucBtnImg9.BtnForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg9.BtnText = "";
            this.ucBtnImg9.ConerRadius = 10;
            this.ucBtnImg9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnImg9.EnabledMouseEffect = true;
            this.ucBtnImg9.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(159)))), ((int)(((byte)(255)))));
            this.ucBtnImg9.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnImg9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg9.Image = ((System.Drawing.Image)(resources.GetObject("ucBtnImg9.Image")));
            this.ucBtnImg9.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg9.ImageFontIcons = ((object)(resources.GetObject("ucBtnImg9.ImageFontIcons")));
            this.ucBtnImg9.IsRadius = true;
            this.ucBtnImg9.IsShowRect = false;
            this.ucBtnImg9.IsShowTips = false;
            this.ucBtnImg9.Location = new System.Drawing.Point(237, 76);
            this.ucBtnImg9.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnImg9.Name = "ucBtnImg9";
            this.ucBtnImg9.RectColor = System.Drawing.Color.Gainsboro;
            this.ucBtnImg9.RectWidth = 1;
            this.ucBtnImg9.Size = new System.Drawing.Size(80, 31);
            this.ucBtnImg9.TabIndex = 18;
            this.ucBtnImg9.TabStop = false;
            this.ucBtnImg9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg9.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnImg9.TipsText = "";
            // 
            // ucBtnImg5
            // 
            this.ucBtnImg5.BackColor = System.Drawing.Color.White;
            this.ucBtnImg5.BtnBackColor = System.Drawing.Color.White;
            this.ucBtnImg5.BtnFont = new System.Drawing.Font("微软雅黑", 15F);
            this.ucBtnImg5.BtnForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg5.BtnText = "";
            this.ucBtnImg5.ConerRadius = 10;
            this.ucBtnImg5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnImg5.EnabledMouseEffect = true;
            this.ucBtnImg5.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(184)))), ((int)(((byte)(0)))));
            this.ucBtnImg5.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnImg5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg5.Image = ((System.Drawing.Image)(resources.GetObject("ucBtnImg5.Image")));
            this.ucBtnImg5.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg5.ImageFontIcons = ((object)(resources.GetObject("ucBtnImg5.ImageFontIcons")));
            this.ucBtnImg5.IsRadius = true;
            this.ucBtnImg5.IsShowRect = false;
            this.ucBtnImg5.IsShowTips = false;
            this.ucBtnImg5.Location = new System.Drawing.Point(353, 17);
            this.ucBtnImg5.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnImg5.Name = "ucBtnImg5";
            this.ucBtnImg5.RectColor = System.Drawing.Color.Gainsboro;
            this.ucBtnImg5.RectWidth = 1;
            this.ucBtnImg5.Size = new System.Drawing.Size(97, 47);
            this.ucBtnImg5.TabIndex = 18;
            this.ucBtnImg5.TabStop = false;
            this.ucBtnImg5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg5.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnImg5.TipsText = "";
            // 
            // ucBtnImg13
            // 
            this.ucBtnImg13.BackColor = System.Drawing.Color.White;
            this.ucBtnImg13.BtnBackColor = System.Drawing.Color.White;
            this.ucBtnImg13.BtnFont = new System.Drawing.Font("微软雅黑", 15F);
            this.ucBtnImg13.BtnForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg13.BtnText = "";
            this.ucBtnImg13.ConerRadius = 10;
            this.ucBtnImg13.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnImg13.EnabledMouseEffect = true;
            this.ucBtnImg13.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.ucBtnImg13.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnImg13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg13.Image = ((System.Drawing.Image)(resources.GetObject("ucBtnImg13.Image")));
            this.ucBtnImg13.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg13.ImageFontIcons = ((object)(resources.GetObject("ucBtnImg13.ImageFontIcons")));
            this.ucBtnImg13.IsRadius = true;
            this.ucBtnImg13.IsShowRect = false;
            this.ucBtnImg13.IsShowTips = false;
            this.ucBtnImg13.Location = new System.Drawing.Point(124, 119);
            this.ucBtnImg13.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnImg13.Name = "ucBtnImg13";
            this.ucBtnImg13.RectColor = System.Drawing.Color.Gainsboro;
            this.ucBtnImg13.RectWidth = 1;
            this.ucBtnImg13.Size = new System.Drawing.Size(56, 31);
            this.ucBtnImg13.TabIndex = 18;
            this.ucBtnImg13.TabStop = false;
            this.ucBtnImg13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg13.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnImg13.TipsText = "";
            // 
            // ucBtnImg8
            // 
            this.ucBtnImg8.BackColor = System.Drawing.Color.White;
            this.ucBtnImg8.BtnBackColor = System.Drawing.Color.White;
            this.ucBtnImg8.BtnFont = new System.Drawing.Font("微软雅黑", 15F);
            this.ucBtnImg8.BtnForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg8.BtnText = "";
            this.ucBtnImg8.ConerRadius = 10;
            this.ucBtnImg8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnImg8.EnabledMouseEffect = true;
            this.ucBtnImg8.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.ucBtnImg8.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnImg8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg8.Image = ((System.Drawing.Image)(resources.GetObject("ucBtnImg8.Image")));
            this.ucBtnImg8.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg8.ImageFontIcons = ((object)(resources.GetObject("ucBtnImg8.ImageFontIcons")));
            this.ucBtnImg8.IsRadius = true;
            this.ucBtnImg8.IsShowRect = false;
            this.ucBtnImg8.IsShowTips = false;
            this.ucBtnImg8.Location = new System.Drawing.Point(124, 76);
            this.ucBtnImg8.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnImg8.Name = "ucBtnImg8";
            this.ucBtnImg8.RectColor = System.Drawing.Color.Gainsboro;
            this.ucBtnImg8.RectWidth = 1;
            this.ucBtnImg8.Size = new System.Drawing.Size(80, 31);
            this.ucBtnImg8.TabIndex = 18;
            this.ucBtnImg8.TabStop = false;
            this.ucBtnImg8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg8.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnImg8.TipsText = "";
            // 
            // ucBtnImg12
            // 
            this.ucBtnImg12.BackColor = System.Drawing.Color.White;
            this.ucBtnImg12.BtnBackColor = System.Drawing.Color.White;
            this.ucBtnImg12.BtnFont = new System.Drawing.Font("微软雅黑", 15F);
            this.ucBtnImg12.BtnForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg12.BtnText = "";
            this.ucBtnImg12.ConerRadius = 10;
            this.ucBtnImg12.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnImg12.EnabledMouseEffect = true;
            this.ucBtnImg12.FillColor = System.Drawing.Color.White;
            this.ucBtnImg12.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnImg12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg12.Image = ((System.Drawing.Image)(resources.GetObject("ucBtnImg12.Image")));
            this.ucBtnImg12.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg12.ImageFontIcons = ((object)(resources.GetObject("ucBtnImg12.ImageFontIcons")));
            this.ucBtnImg12.IsRadius = true;
            this.ucBtnImg12.IsShowRect = true;
            this.ucBtnImg12.IsShowTips = false;
            this.ucBtnImg12.Location = new System.Drawing.Point(15, 119);
            this.ucBtnImg12.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnImg12.Name = "ucBtnImg12";
            this.ucBtnImg12.RectColor = System.Drawing.Color.Gainsboro;
            this.ucBtnImg12.RectWidth = 1;
            this.ucBtnImg12.Size = new System.Drawing.Size(56, 31);
            this.ucBtnImg12.TabIndex = 18;
            this.ucBtnImg12.TabStop = false;
            this.ucBtnImg12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg12.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnImg12.TipsText = "";
            // 
            // ucBtnImg4
            // 
            this.ucBtnImg4.BackColor = System.Drawing.Color.White;
            this.ucBtnImg4.BtnBackColor = System.Drawing.Color.White;
            this.ucBtnImg4.BtnFont = new System.Drawing.Font("微软雅黑", 15F);
            this.ucBtnImg4.BtnForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg4.BtnText = "";
            this.ucBtnImg4.ConerRadius = 10;
            this.ucBtnImg4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnImg4.EnabledMouseEffect = true;
            this.ucBtnImg4.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(159)))), ((int)(((byte)(255)))));
            this.ucBtnImg4.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnImg4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg4.Image = ((System.Drawing.Image)(resources.GetObject("ucBtnImg4.Image")));
            this.ucBtnImg4.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg4.ImageFontIcons = ((object)(resources.GetObject("ucBtnImg4.ImageFontIcons")));
            this.ucBtnImg4.IsRadius = true;
            this.ucBtnImg4.IsShowRect = false;
            this.ucBtnImg4.IsShowTips = false;
            this.ucBtnImg4.Location = new System.Drawing.Point(237, 17);
            this.ucBtnImg4.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnImg4.Name = "ucBtnImg4";
            this.ucBtnImg4.RectColor = System.Drawing.Color.Gainsboro;
            this.ucBtnImg4.RectWidth = 1;
            this.ucBtnImg4.Size = new System.Drawing.Size(97, 47);
            this.ucBtnImg4.TabIndex = 18;
            this.ucBtnImg4.TabStop = false;
            this.ucBtnImg4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg4.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnImg4.TipsText = "";
            // 
            // ucBtnImg7
            // 
            this.ucBtnImg7.BackColor = System.Drawing.Color.White;
            this.ucBtnImg7.BtnBackColor = System.Drawing.Color.White;
            this.ucBtnImg7.BtnFont = new System.Drawing.Font("微软雅黑", 15F);
            this.ucBtnImg7.BtnForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg7.BtnText = "";
            this.ucBtnImg7.ConerRadius = 10;
            this.ucBtnImg7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnImg7.EnabledMouseEffect = true;
            this.ucBtnImg7.FillColor = System.Drawing.Color.White;
            this.ucBtnImg7.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnImg7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg7.Image = ((System.Drawing.Image)(resources.GetObject("ucBtnImg7.Image")));
            this.ucBtnImg7.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg7.ImageFontIcons = ((object)(resources.GetObject("ucBtnImg7.ImageFontIcons")));
            this.ucBtnImg7.IsRadius = true;
            this.ucBtnImg7.IsShowRect = true;
            this.ucBtnImg7.IsShowTips = false;
            this.ucBtnImg7.Location = new System.Drawing.Point(15, 76);
            this.ucBtnImg7.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnImg7.Name = "ucBtnImg7";
            this.ucBtnImg7.RectColor = System.Drawing.Color.Gainsboro;
            this.ucBtnImg7.RectWidth = 1;
            this.ucBtnImg7.Size = new System.Drawing.Size(80, 31);
            this.ucBtnImg7.TabIndex = 18;
            this.ucBtnImg7.TabStop = false;
            this.ucBtnImg7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg7.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnImg7.TipsText = "";
            // 
            // ucBtnImg3
            // 
            this.ucBtnImg3.BackColor = System.Drawing.Color.White;
            this.ucBtnImg3.BtnBackColor = System.Drawing.Color.White;
            this.ucBtnImg3.BtnFont = new System.Drawing.Font("微软雅黑", 15F);
            this.ucBtnImg3.BtnForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg3.BtnText = "";
            this.ucBtnImg3.ConerRadius = 10;
            this.ucBtnImg3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnImg3.EnabledMouseEffect = true;
            this.ucBtnImg3.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.ucBtnImg3.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnImg3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg3.Image = ((System.Drawing.Image)(resources.GetObject("ucBtnImg3.Image")));
            this.ucBtnImg3.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg3.ImageFontIcons = ((object)(resources.GetObject("ucBtnImg3.ImageFontIcons")));
            this.ucBtnImg3.IsRadius = true;
            this.ucBtnImg3.IsShowRect = false;
            this.ucBtnImg3.IsShowTips = false;
            this.ucBtnImg3.Location = new System.Drawing.Point(124, 17);
            this.ucBtnImg3.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnImg3.Name = "ucBtnImg3";
            this.ucBtnImg3.RectColor = System.Drawing.Color.Gainsboro;
            this.ucBtnImg3.RectWidth = 1;
            this.ucBtnImg3.Size = new System.Drawing.Size(97, 47);
            this.ucBtnImg3.TabIndex = 18;
            this.ucBtnImg3.TabStop = false;
            this.ucBtnImg3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg3.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnImg3.TipsText = "";
            // 
            // ucBtnImg2
            // 
            this.ucBtnImg2.BackColor = System.Drawing.Color.White;
            this.ucBtnImg2.BtnBackColor = System.Drawing.Color.White;
            this.ucBtnImg2.BtnFont = new System.Drawing.Font("微软雅黑", 15F);
            this.ucBtnImg2.BtnForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg2.BtnText = "";
            this.ucBtnImg2.ConerRadius = 10;
            this.ucBtnImg2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnImg2.EnabledMouseEffect = true;
            this.ucBtnImg2.FillColor = System.Drawing.Color.White;
            this.ucBtnImg2.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnImg2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg2.Image = ((System.Drawing.Image)(resources.GetObject("ucBtnImg2.Image")));
            this.ucBtnImg2.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg2.ImageFontIcons = ((object)(resources.GetObject("ucBtnImg2.ImageFontIcons")));
            this.ucBtnImg2.IsRadius = true;
            this.ucBtnImg2.IsShowRect = true;
            this.ucBtnImg2.IsShowTips = false;
            this.ucBtnImg2.Location = new System.Drawing.Point(15, 17);
            this.ucBtnImg2.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnImg2.Name = "ucBtnImg2";
            this.ucBtnImg2.RectColor = System.Drawing.Color.Gainsboro;
            this.ucBtnImg2.RectWidth = 1;
            this.ucBtnImg2.Size = new System.Drawing.Size(97, 47);
            this.ucBtnImg2.TabIndex = 18;
            this.ucBtnImg2.TabStop = false;
            this.ucBtnImg2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg2.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnImg2.TipsText = "";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.ucControlBase3);
            this.groupBox4.Controls.Add(this.ucControlBase2);
            this.groupBox4.Controls.Add(this.ucControlBase1);
            this.groupBox4.Location = new System.Drawing.Point(3, 519);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(617, 84);
            this.groupBox4.TabIndex = 21;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "按钮组";
            // 
            // ucControlBase3
            // 
            this.ucControlBase3.BackColor = System.Drawing.Color.White;
            this.ucControlBase3.ConerRadius = 10;
            this.ucControlBase3.Controls.Add(this.ucBtnImg21);
            this.ucControlBase3.Controls.Add(this.ucSplitLine_V1);
            this.ucControlBase3.Controls.Add(this.ucBtnImg20);
            this.ucControlBase3.Controls.Add(this.ucSplitLine_V2);
            this.ucControlBase3.Controls.Add(this.ucBtnImg22);
            this.ucControlBase3.FillColor = System.Drawing.Color.White;
            this.ucControlBase3.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucControlBase3.IsRadius = true;
            this.ucControlBase3.IsShowRect = true;
            this.ucControlBase3.Location = new System.Drawing.Point(202, 22);
            this.ucControlBase3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ucControlBase3.Name = "ucControlBase3";
            this.ucControlBase3.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            this.ucControlBase3.RectWidth = 1;
            this.ucControlBase3.Size = new System.Drawing.Size(167, 44);
            this.ucControlBase3.TabIndex = 19;
            // 
            // ucBtnImg21
            // 
            this.ucBtnImg21.BackColor = System.Drawing.Color.Transparent;
            this.ucBtnImg21.BtnBackColor = System.Drawing.Color.Transparent;
            this.ucBtnImg21.BtnFont = new System.Drawing.Font("微软雅黑", 15F);
            this.ucBtnImg21.BtnForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg21.BtnText = "";
            this.ucBtnImg21.ConerRadius = 1;
            this.ucBtnImg21.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnImg21.Dock = System.Windows.Forms.DockStyle.Left;
            this.ucBtnImg21.EnabledMouseEffect = true;
            this.ucBtnImg21.FillColor = System.Drawing.Color.Transparent;
            this.ucBtnImg21.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnImg21.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg21.Image = ((System.Drawing.Image)(resources.GetObject("ucBtnImg21.Image")));
            this.ucBtnImg21.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg21.ImageFontIcons = ((object)(resources.GetObject("ucBtnImg21.ImageFontIcons")));
            this.ucBtnImg21.IsRadius = false;
            this.ucBtnImg21.IsShowRect = false;
            this.ucBtnImg21.IsShowTips = false;
            this.ucBtnImg21.Location = new System.Drawing.Point(114, 0);
            this.ucBtnImg21.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnImg21.Name = "ucBtnImg21";
            this.ucBtnImg21.RectColor = System.Drawing.Color.Gainsboro;
            this.ucBtnImg21.RectWidth = 1;
            this.ucBtnImg21.Size = new System.Drawing.Size(55, 44);
            this.ucBtnImg21.TabIndex = 20;
            this.ucBtnImg21.TabStop = false;
            this.ucBtnImg21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg21.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnImg21.TipsText = "";
            // 
            // ucSplitLine_V1
            // 
            this.ucSplitLine_V1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(232)))), ((int)(((byte)(232)))));
            this.ucSplitLine_V1.Dock = System.Windows.Forms.DockStyle.Left;
            this.ucSplitLine_V1.Location = new System.Drawing.Point(113, 0);
            this.ucSplitLine_V1.Name = "ucSplitLine_V1";
            this.ucSplitLine_V1.Size = new System.Drawing.Size(1, 44);
            this.ucSplitLine_V1.TabIndex = 2;
            this.ucSplitLine_V1.TabStop = false;
            // 
            // ucBtnImg20
            // 
            this.ucBtnImg20.BackColor = System.Drawing.Color.Transparent;
            this.ucBtnImg20.BtnBackColor = System.Drawing.Color.Transparent;
            this.ucBtnImg20.BtnFont = new System.Drawing.Font("微软雅黑", 15F);
            this.ucBtnImg20.BtnForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg20.BtnText = "";
            this.ucBtnImg20.ConerRadius = 1;
            this.ucBtnImg20.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnImg20.Dock = System.Windows.Forms.DockStyle.Left;
            this.ucBtnImg20.EnabledMouseEffect = true;
            this.ucBtnImg20.FillColor = System.Drawing.Color.Transparent;
            this.ucBtnImg20.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnImg20.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg20.Image = ((System.Drawing.Image)(resources.GetObject("ucBtnImg20.Image")));
            this.ucBtnImg20.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg20.ImageFontIcons = ((object)(resources.GetObject("ucBtnImg20.ImageFontIcons")));
            this.ucBtnImg20.IsRadius = false;
            this.ucBtnImg20.IsShowRect = false;
            this.ucBtnImg20.IsShowTips = false;
            this.ucBtnImg20.Location = new System.Drawing.Point(57, 0);
            this.ucBtnImg20.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnImg20.Name = "ucBtnImg20";
            this.ucBtnImg20.RectColor = System.Drawing.Color.Gainsboro;
            this.ucBtnImg20.RectWidth = 1;
            this.ucBtnImg20.Size = new System.Drawing.Size(56, 44);
            this.ucBtnImg20.TabIndex = 19;
            this.ucBtnImg20.TabStop = false;
            this.ucBtnImg20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg20.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnImg20.TipsText = "";
            // 
            // ucSplitLine_V2
            // 
            this.ucSplitLine_V2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(232)))), ((int)(((byte)(232)))));
            this.ucSplitLine_V2.Dock = System.Windows.Forms.DockStyle.Left;
            this.ucSplitLine_V2.Location = new System.Drawing.Point(56, 0);
            this.ucSplitLine_V2.Name = "ucSplitLine_V2";
            this.ucSplitLine_V2.Size = new System.Drawing.Size(1, 44);
            this.ucSplitLine_V2.TabIndex = 21;
            this.ucSplitLine_V2.TabStop = false;
            // 
            // ucBtnImg22
            // 
            this.ucBtnImg22.BackColor = System.Drawing.Color.Transparent;
            this.ucBtnImg22.BtnBackColor = System.Drawing.Color.Transparent;
            this.ucBtnImg22.BtnFont = new System.Drawing.Font("微软雅黑", 15F);
            this.ucBtnImg22.BtnForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg22.BtnText = "";
            this.ucBtnImg22.ConerRadius = 1;
            this.ucBtnImg22.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnImg22.Dock = System.Windows.Forms.DockStyle.Left;
            this.ucBtnImg22.EnabledMouseEffect = true;
            this.ucBtnImg22.FillColor = System.Drawing.Color.Transparent;
            this.ucBtnImg22.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnImg22.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg22.Image = ((System.Drawing.Image)(resources.GetObject("ucBtnImg22.Image")));
            this.ucBtnImg22.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg22.ImageFontIcons = ((object)(resources.GetObject("ucBtnImg22.ImageFontIcons")));
            this.ucBtnImg22.IsRadius = false;
            this.ucBtnImg22.IsShowRect = false;
            this.ucBtnImg22.IsShowTips = false;
            this.ucBtnImg22.Location = new System.Drawing.Point(0, 0);
            this.ucBtnImg22.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnImg22.Name = "ucBtnImg22";
            this.ucBtnImg22.RectColor = System.Drawing.Color.Gainsboro;
            this.ucBtnImg22.RectWidth = 1;
            this.ucBtnImg22.Size = new System.Drawing.Size(56, 44);
            this.ucBtnImg22.TabIndex = 18;
            this.ucBtnImg22.TabStop = false;
            this.ucBtnImg22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg22.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnImg22.TipsText = "";
            // 
            // ucControlBase2
            // 
            this.ucControlBase2.BackColor = System.Drawing.Color.Transparent;
            this.ucControlBase2.ConerRadius = 10;
            this.ucControlBase2.Controls.Add(this.ucBtnImg19);
            this.ucControlBase2.Controls.Add(this.ucBtnImg18);
            this.ucControlBase2.Controls.Add(this.ucBtnImg17);
            this.ucControlBase2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.ucControlBase2.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucControlBase2.IsRadius = true;
            this.ucControlBase2.IsShowRect = true;
            this.ucControlBase2.Location = new System.Drawing.Point(407, 22);
            this.ucControlBase2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ucControlBase2.Name = "ucControlBase2";
            this.ucControlBase2.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            this.ucControlBase2.RectWidth = 1;
            this.ucControlBase2.Size = new System.Drawing.Size(167, 44);
            this.ucControlBase2.TabIndex = 19;
            // 
            // ucBtnImg19
            // 
            this.ucBtnImg19.BackColor = System.Drawing.Color.White;
            this.ucBtnImg19.BtnBackColor = System.Drawing.Color.White;
            this.ucBtnImg19.BtnFont = new System.Drawing.Font("微软雅黑", 15F);
            this.ucBtnImg19.BtnForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg19.BtnText = "";
            this.ucBtnImg19.ConerRadius = 10;
            this.ucBtnImg19.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnImg19.Dock = System.Windows.Forms.DockStyle.Left;
            this.ucBtnImg19.EnabledMouseEffect = true;
            this.ucBtnImg19.FillColor = System.Drawing.Color.Transparent;
            this.ucBtnImg19.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnImg19.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg19.Image = ((System.Drawing.Image)(resources.GetObject("ucBtnImg19.Image")));
            this.ucBtnImg19.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg19.ImageFontIcons = ((object)(resources.GetObject("ucBtnImg19.ImageFontIcons")));
            this.ucBtnImg19.IsRadius = false;
            this.ucBtnImg19.IsShowRect = false;
            this.ucBtnImg19.IsShowTips = false;
            this.ucBtnImg19.Location = new System.Drawing.Point(112, 0);
            this.ucBtnImg19.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnImg19.Name = "ucBtnImg19";
            this.ucBtnImg19.RectColor = System.Drawing.Color.Gainsboro;
            this.ucBtnImg19.RectWidth = 1;
            this.ucBtnImg19.Size = new System.Drawing.Size(56, 44);
            this.ucBtnImg19.TabIndex = 20;
            this.ucBtnImg19.TabStop = false;
            this.ucBtnImg19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg19.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnImg19.TipsText = "";
            // 
            // ucBtnImg18
            // 
            this.ucBtnImg18.BackColor = System.Drawing.Color.White;
            this.ucBtnImg18.BtnBackColor = System.Drawing.Color.White;
            this.ucBtnImg18.BtnFont = new System.Drawing.Font("微软雅黑", 15F);
            this.ucBtnImg18.BtnForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg18.BtnText = "";
            this.ucBtnImg18.ConerRadius = 10;
            this.ucBtnImg18.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnImg18.Dock = System.Windows.Forms.DockStyle.Left;
            this.ucBtnImg18.EnabledMouseEffect = true;
            this.ucBtnImg18.FillColor = System.Drawing.Color.Transparent;
            this.ucBtnImg18.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnImg18.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg18.Image = ((System.Drawing.Image)(resources.GetObject("ucBtnImg18.Image")));
            this.ucBtnImg18.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg18.ImageFontIcons = ((object)(resources.GetObject("ucBtnImg18.ImageFontIcons")));
            this.ucBtnImg18.IsRadius = false;
            this.ucBtnImg18.IsShowRect = false;
            this.ucBtnImg18.IsShowTips = false;
            this.ucBtnImg18.Location = new System.Drawing.Point(56, 0);
            this.ucBtnImg18.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnImg18.Name = "ucBtnImg18";
            this.ucBtnImg18.RectColor = System.Drawing.Color.Gainsboro;
            this.ucBtnImg18.RectWidth = 1;
            this.ucBtnImg18.Size = new System.Drawing.Size(56, 44);
            this.ucBtnImg18.TabIndex = 19;
            this.ucBtnImg18.TabStop = false;
            this.ucBtnImg18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg18.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnImg18.TipsText = "";
            // 
            // ucBtnImg17
            // 
            this.ucBtnImg17.BackColor = System.Drawing.Color.White;
            this.ucBtnImg17.BtnBackColor = System.Drawing.Color.White;
            this.ucBtnImg17.BtnFont = new System.Drawing.Font("微软雅黑", 15F);
            this.ucBtnImg17.BtnForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg17.BtnText = "";
            this.ucBtnImg17.ConerRadius = 10;
            this.ucBtnImg17.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnImg17.Dock = System.Windows.Forms.DockStyle.Left;
            this.ucBtnImg17.EnabledMouseEffect = true;
            this.ucBtnImg17.FillColor = System.Drawing.Color.Transparent;
            this.ucBtnImg17.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnImg17.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg17.Image = ((System.Drawing.Image)(resources.GetObject("ucBtnImg17.Image")));
            this.ucBtnImg17.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg17.ImageFontIcons = ((object)(resources.GetObject("ucBtnImg17.ImageFontIcons")));
            this.ucBtnImg17.IsRadius = false;
            this.ucBtnImg17.IsShowRect = false;
            this.ucBtnImg17.IsShowTips = false;
            this.ucBtnImg17.Location = new System.Drawing.Point(0, 0);
            this.ucBtnImg17.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnImg17.Name = "ucBtnImg17";
            this.ucBtnImg17.RectColor = System.Drawing.Color.Gainsboro;
            this.ucBtnImg17.RectWidth = 1;
            this.ucBtnImg17.Size = new System.Drawing.Size(56, 44);
            this.ucBtnImg17.TabIndex = 18;
            this.ucBtnImg17.TabStop = false;
            this.ucBtnImg17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg17.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnImg17.TipsText = "";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.ucDropDownBtn5);
            this.groupBox5.Controls.Add(this.ucDropDownBtn4);
            this.groupBox5.Controls.Add(this.ucDropDownBtn3);
            this.groupBox5.Controls.Add(this.ucDropDownBtn2);
            this.groupBox5.Controls.Add(this.ucDropDownBtn1);
            this.groupBox5.Location = new System.Drawing.Point(3, 609);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(617, 84);
            this.groupBox5.TabIndex = 21;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "下拉按钮";
            // 
            // ucDropDownBtn5
            // 
            this.ucDropDownBtn5.BackColor = System.Drawing.Color.White;
            this.ucDropDownBtn5.BtnBackColor = System.Drawing.Color.White;
            this.ucDropDownBtn5.BtnFont = new System.Drawing.Font("微软雅黑", 12F);
            this.ucDropDownBtn5.BtnForeColor = System.Drawing.Color.White;
            this.ucDropDownBtn5.Btns = new string[] {
        "按钮1",
        "按钮2",
        "按钮3"};
            this.ucDropDownBtn5.BtnText = "下拉按钮";
            this.ucDropDownBtn5.ConerRadius = 5;
            this.ucDropDownBtn5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucDropDownBtn5.DropPanelHeight = -1;
            this.ucDropDownBtn5.EnabledMouseEffect = true;
            this.ucDropDownBtn5.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(87)))), ((int)(((byte)(34)))));
            this.ucDropDownBtn5.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucDropDownBtn5.ForeColor = System.Drawing.Color.White;
            this.ucDropDownBtn5.Image = ((System.Drawing.Image)(resources.GetObject("ucDropDownBtn5.Image")));
            this.ucDropDownBtn5.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.ucDropDownBtn5.ImageFontIcons = null;
            this.ucDropDownBtn5.IsRadius = true;
            this.ucDropDownBtn5.IsShowRect = false;
            this.ucDropDownBtn5.IsShowTips = false;
            this.ucDropDownBtn5.Location = new System.Drawing.Point(477, 32);
            this.ucDropDownBtn5.Margin = new System.Windows.Forms.Padding(2);
            this.ucDropDownBtn5.Name = "ucDropDownBtn5";
            this.ucDropDownBtn5.RectColor = System.Drawing.Color.Gainsboro;
            this.ucDropDownBtn5.RectWidth = 1;
            this.ucDropDownBtn5.Size = new System.Drawing.Size(105, 39);
            this.ucDropDownBtn5.TabIndex = 20;
            this.ucDropDownBtn5.TabStop = false;
            this.ucDropDownBtn5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucDropDownBtn5.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucDropDownBtn5.TipsText = "";
            // 
            // ucDropDownBtn4
            // 
            this.ucDropDownBtn4.BackColor = System.Drawing.Color.White;
            this.ucDropDownBtn4.BtnBackColor = System.Drawing.Color.White;
            this.ucDropDownBtn4.BtnFont = new System.Drawing.Font("微软雅黑", 12F);
            this.ucDropDownBtn4.BtnForeColor = System.Drawing.Color.White;
            this.ucDropDownBtn4.Btns = new string[] {
        "按钮1",
        "按钮2",
        "按钮3"};
            this.ucDropDownBtn4.BtnText = "下拉按钮";
            this.ucDropDownBtn4.ConerRadius = 5;
            this.ucDropDownBtn4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucDropDownBtn4.DropPanelHeight = -1;
            this.ucDropDownBtn4.EnabledMouseEffect = true;
            this.ucDropDownBtn4.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(184)))), ((int)(((byte)(0)))));
            this.ucDropDownBtn4.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucDropDownBtn4.ForeColor = System.Drawing.Color.White;
            this.ucDropDownBtn4.Image = ((System.Drawing.Image)(resources.GetObject("ucDropDownBtn4.Image")));
            this.ucDropDownBtn4.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.ucDropDownBtn4.ImageFontIcons = null;
            this.ucDropDownBtn4.IsRadius = true;
            this.ucDropDownBtn4.IsShowRect = false;
            this.ucDropDownBtn4.IsShowTips = false;
            this.ucDropDownBtn4.Location = new System.Drawing.Point(353, 32);
            this.ucDropDownBtn4.Margin = new System.Windows.Forms.Padding(2);
            this.ucDropDownBtn4.Name = "ucDropDownBtn4";
            this.ucDropDownBtn4.RectColor = System.Drawing.Color.Gainsboro;
            this.ucDropDownBtn4.RectWidth = 1;
            this.ucDropDownBtn4.Size = new System.Drawing.Size(105, 39);
            this.ucDropDownBtn4.TabIndex = 20;
            this.ucDropDownBtn4.TabStop = false;
            this.ucDropDownBtn4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucDropDownBtn4.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucDropDownBtn4.TipsText = "";
            // 
            // ucDropDownBtn3
            // 
            this.ucDropDownBtn3.BackColor = System.Drawing.Color.White;
            this.ucDropDownBtn3.BtnBackColor = System.Drawing.Color.White;
            this.ucDropDownBtn3.BtnFont = new System.Drawing.Font("微软雅黑", 12F);
            this.ucDropDownBtn3.BtnForeColor = System.Drawing.Color.White;
            this.ucDropDownBtn3.Btns = new string[] {
        "按钮1",
        "按钮2",
        "按钮3"};
            this.ucDropDownBtn3.BtnText = "下拉按钮";
            this.ucDropDownBtn3.ConerRadius = 5;
            this.ucDropDownBtn3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucDropDownBtn3.DropPanelHeight = -1;
            this.ucDropDownBtn3.EnabledMouseEffect = true;
            this.ucDropDownBtn3.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(159)))), ((int)(((byte)(255)))));
            this.ucDropDownBtn3.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucDropDownBtn3.ForeColor = System.Drawing.Color.White;
            this.ucDropDownBtn3.Image = ((System.Drawing.Image)(resources.GetObject("ucDropDownBtn3.Image")));
            this.ucDropDownBtn3.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.ucDropDownBtn3.ImageFontIcons = null;
            this.ucDropDownBtn3.IsRadius = true;
            this.ucDropDownBtn3.IsShowRect = false;
            this.ucDropDownBtn3.IsShowTips = false;
            this.ucDropDownBtn3.Location = new System.Drawing.Point(237, 32);
            this.ucDropDownBtn3.Margin = new System.Windows.Forms.Padding(2);
            this.ucDropDownBtn3.Name = "ucDropDownBtn3";
            this.ucDropDownBtn3.RectColor = System.Drawing.Color.Gainsboro;
            this.ucDropDownBtn3.RectWidth = 1;
            this.ucDropDownBtn3.Size = new System.Drawing.Size(105, 39);
            this.ucDropDownBtn3.TabIndex = 20;
            this.ucDropDownBtn3.TabStop = false;
            this.ucDropDownBtn3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucDropDownBtn3.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucDropDownBtn3.TipsText = "";
            // 
            // ucDropDownBtn2
            // 
            this.ucDropDownBtn2.BackColor = System.Drawing.Color.White;
            this.ucDropDownBtn2.BtnBackColor = System.Drawing.Color.White;
            this.ucDropDownBtn2.BtnFont = new System.Drawing.Font("微软雅黑", 12F);
            this.ucDropDownBtn2.BtnForeColor = System.Drawing.Color.White;
            this.ucDropDownBtn2.Btns = new string[] {
        "按钮1",
        "按钮2",
        "按钮3"};
            this.ucDropDownBtn2.BtnText = "下拉按钮";
            this.ucDropDownBtn2.ConerRadius = 5;
            this.ucDropDownBtn2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucDropDownBtn2.DropPanelHeight = -1;
            this.ucDropDownBtn2.EnabledMouseEffect = true;
            this.ucDropDownBtn2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.ucDropDownBtn2.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucDropDownBtn2.ForeColor = System.Drawing.Color.White;
            this.ucDropDownBtn2.Image = ((System.Drawing.Image)(resources.GetObject("ucDropDownBtn2.Image")));
            this.ucDropDownBtn2.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.ucDropDownBtn2.ImageFontIcons = null;
            this.ucDropDownBtn2.IsRadius = true;
            this.ucDropDownBtn2.IsShowRect = false;
            this.ucDropDownBtn2.IsShowTips = false;
            this.ucDropDownBtn2.Location = new System.Drawing.Point(124, 32);
            this.ucDropDownBtn2.Margin = new System.Windows.Forms.Padding(2);
            this.ucDropDownBtn2.Name = "ucDropDownBtn2";
            this.ucDropDownBtn2.RectColor = System.Drawing.Color.Gainsboro;
            this.ucDropDownBtn2.RectWidth = 1;
            this.ucDropDownBtn2.Size = new System.Drawing.Size(97, 39);
            this.ucDropDownBtn2.TabIndex = 20;
            this.ucDropDownBtn2.TabStop = false;
            this.ucDropDownBtn2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucDropDownBtn2.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucDropDownBtn2.TipsText = "";
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.ucBtnsGroup2);
            this.groupBox13.Location = new System.Drawing.Point(253, 699);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(367, 68);
            this.groupBox13.TabIndex = 22;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "多选按钮组";
            // 
            // ucBtnsGroup2
            // 
            this.ucBtnsGroup2.BackColor = System.Drawing.Color.White;
            this.ucBtnsGroup2.DataSource = ((System.Collections.Generic.Dictionary<string, string>)(resources.GetObject("ucBtnsGroup2.DataSource")));
            this.ucBtnsGroup2.IsMultiple = false;
            this.ucBtnsGroup2.Location = new System.Drawing.Point(6, 14);
            this.ucBtnsGroup2.MinimumSize = new System.Drawing.Size(0, 50);
            this.ucBtnsGroup2.Name = "ucBtnsGroup2";
            this.ucBtnsGroup2.SelectItem = ((System.Collections.Generic.List<string>)(resources.GetObject("ucBtnsGroup2.SelectItem")));
            this.ucBtnsGroup2.Size = new System.Drawing.Size(355, 50);
            this.ucBtnsGroup2.TabIndex = 0;
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.ucBtnsGroup1);
            this.groupBox12.Location = new System.Drawing.Point(3, 699);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(226, 68);
            this.groupBox12.TabIndex = 23;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "单选按钮组";
            // 
            // ucBtnsGroup1
            // 
            this.ucBtnsGroup1.BackColor = System.Drawing.Color.White;
            this.ucBtnsGroup1.DataSource = ((System.Collections.Generic.Dictionary<string, string>)(resources.GetObject("ucBtnsGroup1.DataSource")));
            this.ucBtnsGroup1.IsMultiple = false;
            this.ucBtnsGroup1.Location = new System.Drawing.Point(6, 14);
            this.ucBtnsGroup1.MinimumSize = new System.Drawing.Size(0, 50);
            this.ucBtnsGroup1.Name = "ucBtnsGroup1";
            this.ucBtnsGroup1.SelectItem = ((System.Collections.Generic.List<string>)(resources.GetObject("ucBtnsGroup1.SelectItem")));
            this.ucBtnsGroup1.Size = new System.Drawing.Size(194, 50);
            this.ucBtnsGroup1.TabIndex = 0;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.ucBtnImg26);
            this.groupBox6.Controls.Add(this.ucBtnImg25);
            this.groupBox6.Controls.Add(this.ucBtnImg24);
            this.groupBox6.Controls.Add(this.ucBtnImg23);
            this.groupBox6.Controls.Add(this.ucBtnImg1);
            this.groupBox6.Location = new System.Drawing.Point(3, 773);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(617, 75);
            this.groupBox6.TabIndex = 21;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "鼠标效果及自定义效果";
            // 
            // ucBtnImg1
            // 
            this.ucBtnImg1.BackColor = System.Drawing.Color.White;
            this.ucBtnImg1.BtnBackColor = System.Drawing.Color.White;
            this.ucBtnImg1.BtnFont = new System.Drawing.Font("微软雅黑", 15F);
            this.ucBtnImg1.BtnForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg1.BtnText = "";
            this.ucBtnImg1.ConerRadius = 10;
            this.ucBtnImg1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnImg1.EnabledMouseEffect = true;
            this.ucBtnImg1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.ucBtnImg1.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnImg1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg1.Image = ((System.Drawing.Image)(resources.GetObject("ucBtnImg1.Image")));
            this.ucBtnImg1.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg1.ImageFontIcons = ((object)(resources.GetObject("ucBtnImg1.ImageFontIcons")));
            this.ucBtnImg1.IsRadius = true;
            this.ucBtnImg1.IsShowRect = false;
            this.ucBtnImg1.IsShowTips = false;
            this.ucBtnImg1.Location = new System.Drawing.Point(15, 26);
            this.ucBtnImg1.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnImg1.Name = "ucBtnImg1";
            this.ucBtnImg1.RectColor = System.Drawing.Color.Gainsboro;
            this.ucBtnImg1.RectWidth = 1;
            this.ucBtnImg1.Size = new System.Drawing.Size(80, 31);
            this.ucBtnImg1.TabIndex = 19;
            this.ucBtnImg1.TabStop = false;
            this.ucBtnImg1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg1.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnImg1.TipsText = "";
            this.ucBtnImg1.MouseEffecting += new System.EventHandler(this.ucBtnImg1_MouseEffecting);
            this.ucBtnImg1.MouseEffected += new System.EventHandler(this.ucBtnImg1_MouseEffected);
            // 
            // ucBtnImg23
            // 
            this.ucBtnImg23.BackColor = System.Drawing.Color.White;
            this.ucBtnImg23.BtnBackColor = System.Drawing.Color.White;
            this.ucBtnImg23.BtnFont = new System.Drawing.Font("微软雅黑", 15F);
            this.ucBtnImg23.BtnForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg23.BtnText = "";
            this.ucBtnImg23.ConerRadius = 10;
            this.ucBtnImg23.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnImg23.EnabledMouseEffect = true;
            this.ucBtnImg23.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.ucBtnImg23.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnImg23.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg23.Image = ((System.Drawing.Image)(resources.GetObject("ucBtnImg23.Image")));
            this.ucBtnImg23.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg23.ImageFontIcons = ((object)(resources.GetObject("ucBtnImg23.ImageFontIcons")));
            this.ucBtnImg23.IsRadius = true;
            this.ucBtnImg23.IsShowRect = false;
            this.ucBtnImg23.IsShowTips = false;
            this.ucBtnImg23.Location = new System.Drawing.Point(141, 26);
            this.ucBtnImg23.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnImg23.Name = "ucBtnImg23";
            this.ucBtnImg23.RectColor = System.Drawing.Color.Gainsboro;
            this.ucBtnImg23.RectWidth = 1;
            this.ucBtnImg23.Size = new System.Drawing.Size(80, 31);
            this.ucBtnImg23.TabIndex = 19;
            this.ucBtnImg23.TabStop = false;
            this.ucBtnImg23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg23.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnImg23.TipsText = "";
            this.ucBtnImg23.MouseEffecting += new System.EventHandler(this.ucBtnImg1_MouseEffecting);
            this.ucBtnImg23.MouseEffected += new System.EventHandler(this.ucBtnImg1_MouseEffected);
            // 
            // ucBtnImg24
            // 
            this.ucBtnImg24.BackColor = System.Drawing.Color.White;
            this.ucBtnImg24.BtnBackColor = System.Drawing.Color.White;
            this.ucBtnImg24.BtnFont = new System.Drawing.Font("微软雅黑", 15F);
            this.ucBtnImg24.BtnForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg24.BtnText = "";
            this.ucBtnImg24.ConerRadius = 10;
            this.ucBtnImg24.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnImg24.EnabledMouseEffect = true;
            this.ucBtnImg24.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.ucBtnImg24.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnImg24.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg24.Image = ((System.Drawing.Image)(resources.GetObject("ucBtnImg24.Image")));
            this.ucBtnImg24.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg24.ImageFontIcons = ((object)(resources.GetObject("ucBtnImg24.ImageFontIcons")));
            this.ucBtnImg24.IsRadius = true;
            this.ucBtnImg24.IsShowRect = false;
            this.ucBtnImg24.IsShowTips = false;
            this.ucBtnImg24.Location = new System.Drawing.Point(256, 26);
            this.ucBtnImg24.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnImg24.Name = "ucBtnImg24";
            this.ucBtnImg24.RectColor = System.Drawing.Color.Gainsboro;
            this.ucBtnImg24.RectWidth = 1;
            this.ucBtnImg24.Size = new System.Drawing.Size(80, 31);
            this.ucBtnImg24.TabIndex = 19;
            this.ucBtnImg24.TabStop = false;
            this.ucBtnImg24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg24.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnImg24.TipsText = "";
            this.ucBtnImg24.MouseEffecting += new System.EventHandler(this.ucBtnImg1_MouseEffecting);
            this.ucBtnImg24.MouseEffected += new System.EventHandler(this.ucBtnImg1_MouseEffected);
            // 
            // ucBtnImg25
            // 
            this.ucBtnImg25.BackColor = System.Drawing.Color.White;
            this.ucBtnImg25.BtnBackColor = System.Drawing.Color.White;
            this.ucBtnImg25.BtnFont = new System.Drawing.Font("微软雅黑", 15F);
            this.ucBtnImg25.BtnForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg25.BtnText = "";
            this.ucBtnImg25.ConerRadius = 10;
            this.ucBtnImg25.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnImg25.EnabledMouseEffect = true;
            this.ucBtnImg25.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.ucBtnImg25.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnImg25.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg25.Image = ((System.Drawing.Image)(resources.GetObject("ucBtnImg25.Image")));
            this.ucBtnImg25.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg25.ImageFontIcons = ((object)(resources.GetObject("ucBtnImg25.ImageFontIcons")));
            this.ucBtnImg25.IsRadius = true;
            this.ucBtnImg25.IsShowRect = false;
            this.ucBtnImg25.IsShowTips = false;
            this.ucBtnImg25.Location = new System.Drawing.Point(370, 26);
            this.ucBtnImg25.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnImg25.Name = "ucBtnImg25";
            this.ucBtnImg25.RectColor = System.Drawing.Color.Gainsboro;
            this.ucBtnImg25.RectWidth = 1;
            this.ucBtnImg25.Size = new System.Drawing.Size(80, 31);
            this.ucBtnImg25.TabIndex = 19;
            this.ucBtnImg25.TabStop = false;
            this.ucBtnImg25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg25.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnImg25.TipsText = "";
            this.ucBtnImg25.MouseEffecting += new System.EventHandler(this.ucBtnImg1_MouseEffecting);
            this.ucBtnImg25.MouseEffected += new System.EventHandler(this.ucBtnImg1_MouseEffected);
            // 
            // ucBtnImg26
            // 
            this.ucBtnImg26.BackColor = System.Drawing.Color.White;
            this.ucBtnImg26.BtnBackColor = System.Drawing.Color.White;
            this.ucBtnImg26.BtnFont = new System.Drawing.Font("微软雅黑", 15F);
            this.ucBtnImg26.BtnForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg26.BtnText = "";
            this.ucBtnImg26.ConerRadius = 10;
            this.ucBtnImg26.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ucBtnImg26.EnabledMouseEffect = true;
            this.ucBtnImg26.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.ucBtnImg26.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucBtnImg26.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.ucBtnImg26.Image = ((System.Drawing.Image)(resources.GetObject("ucBtnImg26.Image")));
            this.ucBtnImg26.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg26.ImageFontIcons = ((object)(resources.GetObject("ucBtnImg26.ImageFontIcons")));
            this.ucBtnImg26.IsRadius = true;
            this.ucBtnImg26.IsShowRect = false;
            this.ucBtnImg26.IsShowTips = false;
            this.ucBtnImg26.Location = new System.Drawing.Point(502, 26);
            this.ucBtnImg26.Margin = new System.Windows.Forms.Padding(0);
            this.ucBtnImg26.Name = "ucBtnImg26";
            this.ucBtnImg26.RectColor = System.Drawing.Color.Gainsboro;
            this.ucBtnImg26.RectWidth = 1;
            this.ucBtnImg26.Size = new System.Drawing.Size(80, 31);
            this.ucBtnImg26.TabIndex = 19;
            this.ucBtnImg26.TabStop = false;
            this.ucBtnImg26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ucBtnImg26.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.ucBtnImg26.TipsText = "";
            this.ucBtnImg26.MouseEffecting += new System.EventHandler(this.ucBtnImg1_MouseEffecting);
            this.ucBtnImg26.MouseEffected += new System.EventHandler(this.ucBtnImg1_MouseEffected);
            // 
            // UCTestBtns
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.groupBox13);
            this.Controls.Add(this.groupBox12);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "UCTestBtns";
            this.Size = new System.Drawing.Size(635, 885);
            this.Load += new System.EventHandler(this.UCTestBtns_Load);
            this.ucControlBase1.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.ucControlBase3.ResumeLayout(false);
            this.ucControlBase2.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox13.ResumeLayout(false);
            this.groupBox12.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private HZH_Controls.Controls.UCDropDownBtn ucDropDownBtn1;
        private HZH_Controls.Controls.UCControlBase ucControlBase1;
        private HZH_Controls.Controls.UCBtnExt ucBtnExt3;
        private HZH_Controls.Controls.UCBtnExt ucBtnExt4;
        private HZH_Controls.Controls.UCBtnExt ucBtnExt5;
        private HZH_Controls.Controls.UCBtnExt ucBtnExt1;
        private HZH_Controls.Controls.UCBtnExt ucBtnExt6;
        private HZH_Controls.Controls.UCBtnExt ucBtnExt7;
        private HZH_Controls.Controls.UCBtnExt ucBtnExt8;
        private HZH_Controls.Controls.UCBtnExt ucBtnExt9;
        private HZH_Controls.Controls.UCBtnExt ucBtnExt2;
        private HZH_Controls.Controls.UCBtnExt ucBtnExt10;
        private HZH_Controls.Controls.UCBtnExt ucBtnExt11;
        private HZH_Controls.Controls.UCBtnExt ucBtnExt12;
        private HZH_Controls.Controls.UCBtnExt ucBtnExt13;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private HZH_Controls.Controls.UCBtnExt ucBtnExt28;
        private HZH_Controls.Controls.UCBtnExt ucBtnExt23;
        private HZH_Controls.Controls.UCBtnExt ucBtnExt16;
        private HZH_Controls.Controls.UCBtnExt ucBtnExt27;
        private HZH_Controls.Controls.UCBtnExt ucBtnExt20;
        private HZH_Controls.Controls.UCBtnExt ucBtnExt26;
        private HZH_Controls.Controls.UCBtnExt ucBtnExt19;
        private HZH_Controls.Controls.UCBtnExt ucBtnExt17;
        private HZH_Controls.Controls.UCBtnExt ucBtnExt25;
        private HZH_Controls.Controls.UCBtnExt ucBtnExt15;
        private HZH_Controls.Controls.UCBtnExt ucBtnExt24;
        private HZH_Controls.Controls.UCBtnExt ucBtnExt18;
        private HZH_Controls.Controls.UCBtnExt ucBtnExt14;
        private HZH_Controls.Controls.UCBtnExt ucBtnExt21;
        private HZH_Controls.Controls.UCBtnExt ucBtnExt22;
        private System.Windows.Forms.GroupBox groupBox3;
        private HZH_Controls.Controls.UCBtnImg ucBtnImg2;
        private HZH_Controls.Controls.UCBtnExt ucBtnExt33;
        private HZH_Controls.Controls.UCBtnExt ucBtnExt32;
        private HZH_Controls.Controls.UCBtnExt ucBtnExt31;
        private HZH_Controls.Controls.UCBtnExt ucBtnExt30;
        private HZH_Controls.Controls.UCBtnExt ucBtnExt29;
        private HZH_Controls.Controls.UCBtnImg ucBtnImg16;
        private HZH_Controls.Controls.UCBtnImg ucBtnImg11;
        private HZH_Controls.Controls.UCBtnImg ucBtnImg6;
        private HZH_Controls.Controls.UCBtnImg ucBtnImg15;
        private HZH_Controls.Controls.UCBtnImg ucBtnImg10;
        private HZH_Controls.Controls.UCBtnImg ucBtnImg14;
        private HZH_Controls.Controls.UCBtnImg ucBtnImg9;
        private HZH_Controls.Controls.UCBtnImg ucBtnImg5;
        private HZH_Controls.Controls.UCBtnImg ucBtnImg13;
        private HZH_Controls.Controls.UCBtnImg ucBtnImg8;
        private HZH_Controls.Controls.UCBtnImg ucBtnImg12;
        private HZH_Controls.Controls.UCBtnImg ucBtnImg4;
        private HZH_Controls.Controls.UCBtnImg ucBtnImg7;
        private HZH_Controls.Controls.UCBtnImg ucBtnImg3;
        private System.Windows.Forms.GroupBox groupBox4;
        private HZH_Controls.Controls.UCControlBase ucControlBase3;
        private HZH_Controls.Controls.UCBtnImg ucBtnImg21;
        private HZH_Controls.Controls.UCSplitLine_V ucSplitLine_V1;
        private HZH_Controls.Controls.UCBtnImg ucBtnImg20;
        private HZH_Controls.Controls.UCSplitLine_V ucSplitLine_V2;
        private HZH_Controls.Controls.UCBtnImg ucBtnImg22;
        private HZH_Controls.Controls.UCControlBase ucControlBase2;
        private HZH_Controls.Controls.UCBtnImg ucBtnImg19;
        private HZH_Controls.Controls.UCBtnImg ucBtnImg18;
        private HZH_Controls.Controls.UCBtnImg ucBtnImg17;
        private System.Windows.Forms.GroupBox groupBox5;
        private HZH_Controls.Controls.UCDropDownBtn ucDropDownBtn5;
        private HZH_Controls.Controls.UCDropDownBtn ucDropDownBtn4;
        private HZH_Controls.Controls.UCDropDownBtn ucDropDownBtn3;
        private HZH_Controls.Controls.UCDropDownBtn ucDropDownBtn2;
        private System.Windows.Forms.GroupBox groupBox13;
        private HZH_Controls.Controls.UCBtnsGroup ucBtnsGroup2;
        private System.Windows.Forms.GroupBox groupBox12;
        private HZH_Controls.Controls.UCBtnsGroup ucBtnsGroup1;
        private System.Windows.Forms.GroupBox groupBox6;
        private HZH_Controls.Controls.UCBtnImg ucBtnImg26;
        private HZH_Controls.Controls.UCBtnImg ucBtnImg25;
        private HZH_Controls.Controls.UCBtnImg ucBtnImg24;
        private HZH_Controls.Controls.UCBtnImg ucBtnImg23;
        private HZH_Controls.Controls.UCBtnImg ucBtnImg1;
    }
}
