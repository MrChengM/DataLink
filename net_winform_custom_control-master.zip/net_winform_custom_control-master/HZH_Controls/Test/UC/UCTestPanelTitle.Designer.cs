﻿namespace Test.UC
{
    partial class UCTestPanelTitle
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.ucPanelTitle5 = new HZH_Controls.Controls.UCPanelTitle();
            this.ucPanelTitle3 = new HZH_Controls.Controls.UCPanelTitle();
            this.ucPanelTitle6 = new HZH_Controls.Controls.UCPanelTitle();
            this.ucPanelTitle4 = new HZH_Controls.Controls.UCPanelTitle();
            this.ucPanelTitle1 = new HZH_Controls.Controls.UCPanelTitle();
            this.ucPanelTitle2 = new HZH_Controls.Controls.UCPanelTitle();
            this.SuspendLayout();
            // 
            // ucPanelTitle5
            // 
            this.ucPanelTitle5.BackColor = System.Drawing.Color.Transparent;
            this.ucPanelTitle5.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.ucPanelTitle5.ConerRadius = 10;
            this.ucPanelTitle5.FillColor = System.Drawing.Color.White;
            this.ucPanelTitle5.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucPanelTitle5.IsCanExpand = true;
            this.ucPanelTitle5.IsExpand = true;
            this.ucPanelTitle5.IsRadius = true;
            this.ucPanelTitle5.IsShowRect = true;
            this.ucPanelTitle5.Location = new System.Drawing.Point(366, 389);
            this.ucPanelTitle5.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ucPanelTitle5.Name = "ucPanelTitle5";
            this.ucPanelTitle5.Padding = new System.Windows.Forms.Padding(1);
            this.ucPanelTitle5.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.ucPanelTitle5.RectWidth = 1;
            this.ucPanelTitle5.Size = new System.Drawing.Size(316, 34);
            this.ucPanelTitle5.TabIndex = 2;
            this.ucPanelTitle5.Title = "收起的折叠面板";
            // 
            // ucPanelTitle3
            // 
            this.ucPanelTitle3.BackColor = System.Drawing.Color.White;
            this.ucPanelTitle3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.ucPanelTitle3.ConerRadius = 10;
            this.ucPanelTitle3.FillColor = System.Drawing.Color.White;
            this.ucPanelTitle3.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucPanelTitle3.IsCanExpand = true;
            this.ucPanelTitle3.IsExpand = false;
            this.ucPanelTitle3.IsRadius = true;
            this.ucPanelTitle3.IsShowRect = true;
            this.ucPanelTitle3.Location = new System.Drawing.Point(366, 197);
            this.ucPanelTitle3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ucPanelTitle3.Name = "ucPanelTitle3";
            this.ucPanelTitle3.Padding = new System.Windows.Forms.Padding(1);
            this.ucPanelTitle3.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.ucPanelTitle3.RectWidth = 1;
            this.ucPanelTitle3.Size = new System.Drawing.Size(316, 182);
            this.ucPanelTitle3.TabIndex = 2;
            this.ucPanelTitle3.Title = "展开的折叠面板";
            // 
            // ucPanelTitle6
            // 
            this.ucPanelTitle6.BackColor = System.Drawing.Color.Transparent;
            this.ucPanelTitle6.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.ucPanelTitle6.ConerRadius = 10;
            this.ucPanelTitle6.FillColor = System.Drawing.Color.White;
            this.ucPanelTitle6.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucPanelTitle6.IsCanExpand = false;
            this.ucPanelTitle6.IsExpand = false;
            this.ucPanelTitle6.IsRadius = true;
            this.ucPanelTitle6.IsShowRect = true;
            this.ucPanelTitle6.Location = new System.Drawing.Point(366, 5);
            this.ucPanelTitle6.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ucPanelTitle6.Name = "ucPanelTitle6";
            this.ucPanelTitle6.Padding = new System.Windows.Forms.Padding(1);
            this.ucPanelTitle6.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.ucPanelTitle6.RectWidth = 1;
            this.ucPanelTitle6.Size = new System.Drawing.Size(316, 182);
            this.ucPanelTitle6.TabIndex = 2;
            this.ucPanelTitle6.Title = "不可折叠面板";
            // 
            // ucPanelTitle4
            // 
            this.ucPanelTitle4.BackColor = System.Drawing.Color.Transparent;
            this.ucPanelTitle4.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucPanelTitle4.ConerRadius = 10;
            this.ucPanelTitle4.FillColor = System.Drawing.Color.White;
            this.ucPanelTitle4.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucPanelTitle4.IsCanExpand = true;
            this.ucPanelTitle4.IsExpand = true;
            this.ucPanelTitle4.IsRadius = true;
            this.ucPanelTitle4.IsShowRect = true;
            this.ucPanelTitle4.Location = new System.Drawing.Point(13, 389);
            this.ucPanelTitle4.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ucPanelTitle4.Name = "ucPanelTitle4";
            this.ucPanelTitle4.Padding = new System.Windows.Forms.Padding(1);
            this.ucPanelTitle4.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucPanelTitle4.RectWidth = 1;
            this.ucPanelTitle4.Size = new System.Drawing.Size(316, 34);
            this.ucPanelTitle4.TabIndex = 2;
            this.ucPanelTitle4.Title = "收起的折叠面板";
            // 
            // ucPanelTitle1
            // 
            this.ucPanelTitle1.BackColor = System.Drawing.Color.White;
            this.ucPanelTitle1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucPanelTitle1.ConerRadius = 10;
            this.ucPanelTitle1.FillColor = System.Drawing.Color.White;
            this.ucPanelTitle1.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucPanelTitle1.IsCanExpand = true;
            this.ucPanelTitle1.IsExpand = false;
            this.ucPanelTitle1.IsRadius = true;
            this.ucPanelTitle1.IsShowRect = true;
            this.ucPanelTitle1.Location = new System.Drawing.Point(13, 197);
            this.ucPanelTitle1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ucPanelTitle1.Name = "ucPanelTitle1";
            this.ucPanelTitle1.Padding = new System.Windows.Forms.Padding(1);
            this.ucPanelTitle1.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucPanelTitle1.RectWidth = 1;
            this.ucPanelTitle1.Size = new System.Drawing.Size(316, 182);
            this.ucPanelTitle1.TabIndex = 2;
            this.ucPanelTitle1.Title = "展开的折叠面板";
            // 
            // ucPanelTitle2
            // 
            this.ucPanelTitle2.BackColor = System.Drawing.Color.White;
            this.ucPanelTitle2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucPanelTitle2.ConerRadius = 10;
            this.ucPanelTitle2.FillColor = System.Drawing.Color.White;
            this.ucPanelTitle2.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucPanelTitle2.IsCanExpand = false;
            this.ucPanelTitle2.IsExpand = false;
            this.ucPanelTitle2.IsRadius = true;
            this.ucPanelTitle2.IsShowRect = true;
            this.ucPanelTitle2.Location = new System.Drawing.Point(13, 5);
            this.ucPanelTitle2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ucPanelTitle2.Name = "ucPanelTitle2";
            this.ucPanelTitle2.Padding = new System.Windows.Forms.Padding(1);
            this.ucPanelTitle2.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucPanelTitle2.RectWidth = 1;
            this.ucPanelTitle2.Size = new System.Drawing.Size(316, 182);
            this.ucPanelTitle2.TabIndex = 2;
            this.ucPanelTitle2.Title = "不可折叠面板";
            // 
            // UCTestPanelTitle
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.ucPanelTitle5);
            this.Controls.Add(this.ucPanelTitle3);
            this.Controls.Add(this.ucPanelTitle6);
            this.Controls.Add(this.ucPanelTitle4);
            this.Controls.Add(this.ucPanelTitle1);
            this.Controls.Add(this.ucPanelTitle2);
            this.Name = "UCTestPanelTitle";
            this.Size = new System.Drawing.Size(833, 615);
            this.ResumeLayout(false);

        }

        #endregion

        private HZH_Controls.Controls.UCPanelTitle ucPanelTitle2;
        private HZH_Controls.Controls.UCPanelTitle ucPanelTitle6;
        private HZH_Controls.Controls.UCPanelTitle ucPanelTitle1;
        private HZH_Controls.Controls.UCPanelTitle ucPanelTitle3;
        private HZH_Controls.Controls.UCPanelTitle ucPanelTitle4;
        private HZH_Controls.Controls.UCPanelTitle ucPanelTitle5;
    }
}
