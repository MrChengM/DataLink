﻿namespace Test.UC
{
    partial class UCTestLED
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.ucledNum27 = new HZH_Controls.Controls.UCLEDNum();
            this.ucledNum26 = new HZH_Controls.Controls.UCLEDNum();
            this.ucledNum25 = new HZH_Controls.Controls.UCLEDNum();
            this.ucledNum24 = new HZH_Controls.Controls.UCLEDNum();
            this.ucledNum23 = new HZH_Controls.Controls.UCLEDNum();
            this.ucledNum22 = new HZH_Controls.Controls.UCLEDNum();
            this.ucledNum21 = new HZH_Controls.Controls.UCLEDNum();
            this.ucledNum20 = new HZH_Controls.Controls.UCLEDNum();
            this.ucledNum19 = new HZH_Controls.Controls.UCLEDNum();
            this.ucledNum18 = new HZH_Controls.Controls.UCLEDNum();
            this.ucledNum17 = new HZH_Controls.Controls.UCLEDNum();
            this.ucledNum16 = new HZH_Controls.Controls.UCLEDNum();
            this.ucledNum15 = new HZH_Controls.Controls.UCLEDNum();
            this.ucledNum14 = new HZH_Controls.Controls.UCLEDNum();
            this.ucledNum13 = new HZH_Controls.Controls.UCLEDNum();
            this.ucledNum12 = new HZH_Controls.Controls.UCLEDNum();
            this.ucledNum11 = new HZH_Controls.Controls.UCLEDNum();
            this.ucledNum10 = new HZH_Controls.Controls.UCLEDNum();
            this.ucledNum9 = new HZH_Controls.Controls.UCLEDNum();
            this.ucledNum8 = new HZH_Controls.Controls.UCLEDNum();
            this.ucledNum7 = new HZH_Controls.Controls.UCLEDNum();
            this.ucledNum6 = new HZH_Controls.Controls.UCLEDNum();
            this.ucledNum5 = new HZH_Controls.Controls.UCLEDNum();
            this.ucledNum4 = new HZH_Controls.Controls.UCLEDNum();
            this.ucledNum3 = new HZH_Controls.Controls.UCLEDNum();
            this.ucledNum2 = new HZH_Controls.Controls.UCLEDNum();
            this.ucledNum1 = new HZH_Controls.Controls.UCLEDNum();
            this.ledNum1 = new HZH_Controls.Controls.UCLEDNum();
            this.ucledNums2 = new HZH_Controls.Controls.UCLEDNums();
            this.ucledNums1 = new HZH_Controls.Controls.UCLEDNums();
            this.ucledDataTime1 = new HZH_Controls.Controls.UCLEDDataTime();
            this.ucledTime2 = new HZH_Controls.Controls.UCLEDTime();
            this.ucledDate1 = new HZH_Controls.Controls.UCLEDData();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.ucledNum28 = new HZH_Controls.Controls.UCLEDNum();
            this.ucledNum29 = new HZH_Controls.Controls.UCLEDNum();
            this.ucledNum30 = new HZH_Controls.Controls.UCLEDNum();
            this.ucledNum31 = new HZH_Controls.Controls.UCLEDNum();
            this.ucledNum32 = new HZH_Controls.Controls.UCLEDNum();
            this.ucledNum33 = new HZH_Controls.Controls.UCLEDNum();
            this.ucledNum34 = new HZH_Controls.Controls.UCLEDNum();
            this.ucledNum35 = new HZH_Controls.Controls.UCLEDNum();
            this.ucledNum36 = new HZH_Controls.Controls.UCLEDNum();
            this.ucledNum37 = new HZH_Controls.Controls.UCLEDNum();
            this.ucledNum38 = new HZH_Controls.Controls.UCLEDNum();
            this.ucledNum39 = new HZH_Controls.Controls.UCLEDNum();
            this.ucledNum40 = new HZH_Controls.Controls.UCLEDNum();
            this.ucledNum41 = new HZH_Controls.Controls.UCLEDNum();
            this.ucledNum42 = new HZH_Controls.Controls.UCLEDNum();
            this.ucledNum43 = new HZH_Controls.Controls.UCLEDNum();
            this.ucledNum44 = new HZH_Controls.Controls.UCLEDNum();
            this.ucledNum45 = new HZH_Controls.Controls.UCLEDNum();
            this.ucledNum46 = new HZH_Controls.Controls.UCLEDNum();
            this.ucledNum47 = new HZH_Controls.Controls.UCLEDNum();
            this.ucledNum48 = new HZH_Controls.Controls.UCLEDNum();
            this.ucledNum49 = new HZH_Controls.Controls.UCLEDNum();
            this.ucledNum50 = new HZH_Controls.Controls.UCLEDNum();
            this.ucledNum51 = new HZH_Controls.Controls.UCLEDNum();
            this.ucledNum52 = new HZH_Controls.Controls.UCLEDNum();
            this.ucledNum53 = new HZH_Controls.Controls.UCLEDNum();
            this.ucledNum54 = new HZH_Controls.Controls.UCLEDNum();
            this.ucledNum55 = new HZH_Controls.Controls.UCLEDNum();
            this.SuspendLayout();
            // 
            // ucledNum27
            // 
            this.ucledNum27.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucledNum27.LineWidth = 8;
            this.ucledNum27.Location = new System.Drawing.Point(621, 96);
            this.ucledNum27.Name = "ucledNum27";
            this.ucledNum27.Size = new System.Drawing.Size(40, 60);
            this.ucledNum27.TabIndex = 15;
            this.ucledNum27.Value = 'U';
            this.ucledNum27.ValueChar = HZH_Controls.Controls.LEDNumChar.CHAR_U;
            // 
            // ucledNum26
            // 
            this.ucledNum26.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucledNum26.LineWidth = 8;
            this.ucledNum26.Location = new System.Drawing.Point(575, 96);
            this.ucledNum26.Name = "ucledNum26";
            this.ucledNum26.Size = new System.Drawing.Size(40, 60);
            this.ucledNum26.TabIndex = 40;
            this.ucledNum26.Value = 'r';
            this.ucledNum26.ValueChar = HZH_Controls.Controls.LEDNumChar.CHAR_r;
            // 
            // ucledNum25
            // 
            this.ucledNum25.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucledNum25.LineWidth = 8;
            this.ucledNum25.Location = new System.Drawing.Point(529, 96);
            this.ucledNum25.Name = "ucledNum25";
            this.ucledNum25.Size = new System.Drawing.Size(40, 60);
            this.ucledNum25.TabIndex = 39;
            this.ucledNum25.Value = 'P';
            this.ucledNum25.ValueChar = HZH_Controls.Controls.LEDNumChar.CHAR_P;
            // 
            // ucledNum24
            // 
            this.ucledNum24.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucledNum24.LineWidth = 8;
            this.ucledNum24.Location = new System.Drawing.Point(483, 96);
            this.ucledNum24.Name = "ucledNum24";
            this.ucledNum24.Size = new System.Drawing.Size(40, 60);
            this.ucledNum24.TabIndex = 38;
            this.ucledNum24.Value = 'o';
            this.ucledNum24.ValueChar = HZH_Controls.Controls.LEDNumChar.CHAR_o;
            // 
            // ucledNum23
            // 
            this.ucledNum23.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucledNum23.LineWidth = 8;
            this.ucledNum23.Location = new System.Drawing.Point(428, 96);
            this.ucledNum23.Name = "ucledNum23";
            this.ucledNum23.Size = new System.Drawing.Size(40, 60);
            this.ucledNum23.TabIndex = 37;
            this.ucledNum23.Value = 'L';
            this.ucledNum23.ValueChar = HZH_Controls.Controls.LEDNumChar.CHAR_L;
            // 
            // ucledNum22
            // 
            this.ucledNum22.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucledNum22.LineWidth = 8;
            this.ucledNum22.Location = new System.Drawing.Point(382, 96);
            this.ucledNum22.Name = "ucledNum22";
            this.ucledNum22.Size = new System.Drawing.Size(40, 60);
            this.ucledNum22.TabIndex = 36;
            this.ucledNum22.Value = 'J';
            this.ucledNum22.ValueChar = HZH_Controls.Controls.LEDNumChar.CHAR_J;
            // 
            // ucledNum21
            // 
            this.ucledNum21.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucledNum21.LineWidth = 8;
            this.ucledNum21.Location = new System.Drawing.Point(336, 96);
            this.ucledNum21.Name = "ucledNum21";
            this.ucledNum21.Size = new System.Drawing.Size(40, 60);
            this.ucledNum21.TabIndex = 35;
            this.ucledNum21.Value = 'h';
            this.ucledNum21.ValueChar = HZH_Controls.Controls.LEDNumChar.CHAR_h;
            // 
            // ucledNum20
            // 
            this.ucledNum20.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucledNum20.LineWidth = 8;
            this.ucledNum20.Location = new System.Drawing.Point(290, 96);
            this.ucledNum20.Name = "ucledNum20";
            this.ucledNum20.Size = new System.Drawing.Size(40, 60);
            this.ucledNum20.TabIndex = 34;
            this.ucledNum20.Value = 'H';
            this.ucledNum20.ValueChar = HZH_Controls.Controls.LEDNumChar.CHAR_H;
            // 
            // ucledNum19
            // 
            this.ucledNum19.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucledNum19.LineWidth = 8;
            this.ucledNum19.Location = new System.Drawing.Point(244, 96);
            this.ucledNum19.Name = "ucledNum19";
            this.ucledNum19.Size = new System.Drawing.Size(40, 60);
            this.ucledNum19.TabIndex = 33;
            this.ucledNum19.Value = 'F';
            this.ucledNum19.ValueChar = HZH_Controls.Controls.LEDNumChar.CHAR_F;
            // 
            // ucledNum18
            // 
            this.ucledNum18.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucledNum18.LineWidth = 8;
            this.ucledNum18.Location = new System.Drawing.Point(198, 96);
            this.ucledNum18.Name = "ucledNum18";
            this.ucledNum18.Size = new System.Drawing.Size(40, 60);
            this.ucledNum18.TabIndex = 32;
            this.ucledNum18.Value = 'E';
            this.ucledNum18.ValueChar = HZH_Controls.Controls.LEDNumChar.CHAR_E;
            // 
            // ucledNum17
            // 
            this.ucledNum17.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucledNum17.LineWidth = 8;
            this.ucledNum17.Location = new System.Drawing.Point(152, 96);
            this.ucledNum17.Name = "ucledNum17";
            this.ucledNum17.Size = new System.Drawing.Size(40, 60);
            this.ucledNum17.TabIndex = 31;
            this.ucledNum17.Value = 'd';
            this.ucledNum17.ValueChar = HZH_Controls.Controls.LEDNumChar.CHAR_d;
            // 
            // ucledNum16
            // 
            this.ucledNum16.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucledNum16.LineWidth = 8;
            this.ucledNum16.Location = new System.Drawing.Point(106, 96);
            this.ucledNum16.Name = "ucledNum16";
            this.ucledNum16.Size = new System.Drawing.Size(40, 60);
            this.ucledNum16.TabIndex = 30;
            this.ucledNum16.Value = 'c';
            this.ucledNum16.ValueChar = HZH_Controls.Controls.LEDNumChar.CHAR_c;
            // 
            // ucledNum15
            // 
            this.ucledNum15.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucledNum15.LineWidth = 8;
            this.ucledNum15.Location = new System.Drawing.Point(60, 96);
            this.ucledNum15.Name = "ucledNum15";
            this.ucledNum15.Size = new System.Drawing.Size(40, 60);
            this.ucledNum15.TabIndex = 29;
            this.ucledNum15.Value = 'C';
            this.ucledNum15.ValueChar = HZH_Controls.Controls.LEDNumChar.CHAR_C;
            // 
            // ucledNum14
            // 
            this.ucledNum14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucledNum14.LineWidth = 8;
            this.ucledNum14.Location = new System.Drawing.Point(14, 96);
            this.ucledNum14.Name = "ucledNum14";
            this.ucledNum14.Size = new System.Drawing.Size(40, 60);
            this.ucledNum14.TabIndex = 28;
            this.ucledNum14.Value = 'b';
            this.ucledNum14.ValueChar = HZH_Controls.Controls.LEDNumChar.CHAR_b;
            // 
            // ucledNum13
            // 
            this.ucledNum13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucledNum13.LineWidth = 8;
            this.ucledNum13.Location = new System.Drawing.Point(612, 18);
            this.ucledNum13.Name = "ucledNum13";
            this.ucledNum13.Size = new System.Drawing.Size(40, 60);
            this.ucledNum13.TabIndex = 27;
            this.ucledNum13.Value = 'A';
            this.ucledNum13.ValueChar = HZH_Controls.Controls.LEDNumChar.CHAR_A;
            // 
            // ucledNum12
            // 
            this.ucledNum12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucledNum12.LineWidth = 8;
            this.ucledNum12.Location = new System.Drawing.Point(566, 18);
            this.ucledNum12.Name = "ucledNum12";
            this.ucledNum12.Size = new System.Drawing.Size(40, 60);
            this.ucledNum12.TabIndex = 26;
            this.ucledNum12.Value = '-';
            this.ucledNum12.ValueChar = HZH_Controls.Controls.LEDNumChar.CHAR_HorizontalLine;
            // 
            // ucledNum11
            // 
            this.ucledNum11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucledNum11.LineWidth = 8;
            this.ucledNum11.Location = new System.Drawing.Point(520, 18);
            this.ucledNum11.Name = "ucledNum11";
            this.ucledNum11.Size = new System.Drawing.Size(40, 60);
            this.ucledNum11.TabIndex = 25;
            this.ucledNum11.Value = '.';
            this.ucledNum11.ValueChar = HZH_Controls.Controls.LEDNumChar.CHAR_Dot;
            // 
            // ucledNum10
            // 
            this.ucledNum10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucledNum10.LineWidth = 8;
            this.ucledNum10.Location = new System.Drawing.Point(474, 18);
            this.ucledNum10.Name = "ucledNum10";
            this.ucledNum10.Size = new System.Drawing.Size(40, 60);
            this.ucledNum10.TabIndex = 24;
            this.ucledNum10.Value = ':';
            this.ucledNum10.ValueChar = HZH_Controls.Controls.LEDNumChar.CHAR_Colon;
            // 
            // ucledNum9
            // 
            this.ucledNum9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucledNum9.LineWidth = 8;
            this.ucledNum9.Location = new System.Drawing.Point(428, 18);
            this.ucledNum9.Name = "ucledNum9";
            this.ucledNum9.Size = new System.Drawing.Size(40, 60);
            this.ucledNum9.TabIndex = 23;
            this.ucledNum9.Value = '0';
            this.ucledNum9.ValueChar = HZH_Controls.Controls.LEDNumChar.CHAR_0;
            // 
            // ucledNum8
            // 
            this.ucledNum8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucledNum8.LineWidth = 8;
            this.ucledNum8.Location = new System.Drawing.Point(382, 18);
            this.ucledNum8.Name = "ucledNum8";
            this.ucledNum8.Size = new System.Drawing.Size(40, 60);
            this.ucledNum8.TabIndex = 22;
            this.ucledNum8.Value = '9';
            this.ucledNum8.ValueChar = HZH_Controls.Controls.LEDNumChar.CHAR_9;
            // 
            // ucledNum7
            // 
            this.ucledNum7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucledNum7.LineWidth = 8;
            this.ucledNum7.Location = new System.Drawing.Point(336, 18);
            this.ucledNum7.Name = "ucledNum7";
            this.ucledNum7.Size = new System.Drawing.Size(40, 60);
            this.ucledNum7.TabIndex = 21;
            this.ucledNum7.Value = '8';
            this.ucledNum7.ValueChar = HZH_Controls.Controls.LEDNumChar.CHAR_8;
            // 
            // ucledNum6
            // 
            this.ucledNum6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucledNum6.LineWidth = 8;
            this.ucledNum6.Location = new System.Drawing.Point(290, 18);
            this.ucledNum6.Name = "ucledNum6";
            this.ucledNum6.Size = new System.Drawing.Size(40, 60);
            this.ucledNum6.TabIndex = 20;
            this.ucledNum6.Value = '7';
            this.ucledNum6.ValueChar = HZH_Controls.Controls.LEDNumChar.CHAR_7;
            // 
            // ucledNum5
            // 
            this.ucledNum5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucledNum5.LineWidth = 8;
            this.ucledNum5.Location = new System.Drawing.Point(244, 18);
            this.ucledNum5.Name = "ucledNum5";
            this.ucledNum5.Size = new System.Drawing.Size(40, 60);
            this.ucledNum5.TabIndex = 19;
            this.ucledNum5.Value = '6';
            this.ucledNum5.ValueChar = HZH_Controls.Controls.LEDNumChar.CHAR_6;
            // 
            // ucledNum4
            // 
            this.ucledNum4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucledNum4.LineWidth = 8;
            this.ucledNum4.Location = new System.Drawing.Point(198, 18);
            this.ucledNum4.Name = "ucledNum4";
            this.ucledNum4.Size = new System.Drawing.Size(40, 60);
            this.ucledNum4.TabIndex = 18;
            this.ucledNum4.Value = '5';
            this.ucledNum4.ValueChar = HZH_Controls.Controls.LEDNumChar.CHAR_5;
            // 
            // ucledNum3
            // 
            this.ucledNum3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucledNum3.LineWidth = 8;
            this.ucledNum3.Location = new System.Drawing.Point(152, 18);
            this.ucledNum3.Name = "ucledNum3";
            this.ucledNum3.Size = new System.Drawing.Size(40, 60);
            this.ucledNum3.TabIndex = 17;
            this.ucledNum3.Value = '4';
            this.ucledNum3.ValueChar = HZH_Controls.Controls.LEDNumChar.CHAR_4;
            // 
            // ucledNum2
            // 
            this.ucledNum2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucledNum2.LineWidth = 8;
            this.ucledNum2.Location = new System.Drawing.Point(106, 18);
            this.ucledNum2.Name = "ucledNum2";
            this.ucledNum2.Size = new System.Drawing.Size(40, 60);
            this.ucledNum2.TabIndex = 16;
            this.ucledNum2.Value = '3';
            this.ucledNum2.ValueChar = HZH_Controls.Controls.LEDNumChar.CHAR_3;
            // 
            // ucledNum1
            // 
            this.ucledNum1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucledNum1.LineWidth = 8;
            this.ucledNum1.Location = new System.Drawing.Point(60, 18);
            this.ucledNum1.Name = "ucledNum1";
            this.ucledNum1.Size = new System.Drawing.Size(40, 60);
            this.ucledNum1.TabIndex = 41;
            this.ucledNum1.Value = '2';
            this.ucledNum1.ValueChar = HZH_Controls.Controls.LEDNumChar.CHAR_2;
            // 
            // ledNum1
            // 
            this.ledNum1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ledNum1.LineWidth = 8;
            this.ledNum1.Location = new System.Drawing.Point(14, 18);
            this.ledNum1.Name = "ledNum1";
            this.ledNum1.Size = new System.Drawing.Size(40, 60);
            this.ledNum1.TabIndex = 42;
            this.ledNum1.Value = '1';
            this.ledNum1.ValueChar = HZH_Controls.Controls.LEDNumChar.CHAR_1;
            // 
            // ucledNums2
            // 
            this.ucledNums2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucledNums2.LineWidth = 8;
            this.ucledNums2.Location = new System.Drawing.Point(5, 383);
            this.ucledNums2.Name = "ucledNums2";
            this.ucledNums2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.ucledNums2.Size = new System.Drawing.Size(647, 58);
            this.ucledNums2.TabIndex = 46;
            this.ucledNums2.Value = "1.234";
            // 
            // ucledNums1
            // 
            this.ucledNums1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucledNums1.LineWidth = 8;
            this.ucledNums1.Location = new System.Drawing.Point(3, 307);
            this.ucledNums1.Name = "ucledNums1";
            this.ucledNums1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ucledNums1.Size = new System.Drawing.Size(647, 58);
            this.ucledNums1.TabIndex = 47;
            this.ucledNums1.Value = "1.234";
            // 
            // ucledDataTime1
            // 
            this.ucledDataTime1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucledDataTime1.LineWidth = 8;
            this.ucledDataTime1.Location = new System.Drawing.Point(19, 538);
            this.ucledDataTime1.Name = "ucledDataTime1";
            this.ucledDataTime1.Size = new System.Drawing.Size(642, 74);
            this.ucledDataTime1.TabIndex = 45;
            this.ucledDataTime1.Value = new System.DateTime(2019, 9, 2, 15, 52, 45, 485);
            // 
            // ucledTime2
            // 
            this.ucledTime2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucledTime2.LineWidth = 8;
            this.ucledTime2.Location = new System.Drawing.Point(382, 447);
            this.ucledTime2.Name = "ucledTime2";
            this.ucledTime2.Size = new System.Drawing.Size(279, 74);
            this.ucledTime2.TabIndex = 44;
            this.ucledTime2.Value = new System.DateTime(2019, 9, 2, 15, 46, 56, 286);
            // 
            // ucledDate1
            // 
            this.ucledDate1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucledDate1.LineWidth = 8;
            this.ucledDate1.Location = new System.Drawing.Point(19, 447);
            this.ucledDate1.Margin = new System.Windows.Forms.Padding(0);
            this.ucledDate1.Name = "ucledDate1";
            this.ucledDate1.Size = new System.Drawing.Size(333, 74);
            this.ucledDate1.TabIndex = 43;
            this.ucledDate1.Value = new System.DateTime(2019, 9, 2, 15, 31, 34, 633);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // ucledNum28
            // 
            this.ucledNum28.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.ucledNum28.LineWidth = 8;
            this.ucledNum28.Location = new System.Drawing.Point(14, 162);
            this.ucledNum28.Name = "ucledNum28";
            this.ucledNum28.Size = new System.Drawing.Size(40, 60);
            this.ucledNum28.TabIndex = 42;
            this.ucledNum28.Value = '1';
            this.ucledNum28.ValueChar = HZH_Controls.Controls.LEDNumChar.CHAR_1;
            // 
            // ucledNum29
            // 
            this.ucledNum29.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.ucledNum29.LineWidth = 8;
            this.ucledNum29.Location = new System.Drawing.Point(60, 162);
            this.ucledNum29.Name = "ucledNum29";
            this.ucledNum29.Size = new System.Drawing.Size(40, 60);
            this.ucledNum29.TabIndex = 41;
            this.ucledNum29.Value = '2';
            this.ucledNum29.ValueChar = HZH_Controls.Controls.LEDNumChar.CHAR_2;
            // 
            // ucledNum30
            // 
            this.ucledNum30.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.ucledNum30.LineWidth = 8;
            this.ucledNum30.Location = new System.Drawing.Point(106, 162);
            this.ucledNum30.Name = "ucledNum30";
            this.ucledNum30.Size = new System.Drawing.Size(40, 60);
            this.ucledNum30.TabIndex = 16;
            this.ucledNum30.Value = '3';
            this.ucledNum30.ValueChar = HZH_Controls.Controls.LEDNumChar.CHAR_3;
            // 
            // ucledNum31
            // 
            this.ucledNum31.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.ucledNum31.LineWidth = 8;
            this.ucledNum31.Location = new System.Drawing.Point(152, 162);
            this.ucledNum31.Name = "ucledNum31";
            this.ucledNum31.Size = new System.Drawing.Size(40, 60);
            this.ucledNum31.TabIndex = 17;
            this.ucledNum31.Value = '4';
            this.ucledNum31.ValueChar = HZH_Controls.Controls.LEDNumChar.CHAR_4;
            // 
            // ucledNum32
            // 
            this.ucledNum32.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.ucledNum32.LineWidth = 8;
            this.ucledNum32.Location = new System.Drawing.Point(198, 162);
            this.ucledNum32.Name = "ucledNum32";
            this.ucledNum32.Size = new System.Drawing.Size(40, 60);
            this.ucledNum32.TabIndex = 18;
            this.ucledNum32.Value = '5';
            this.ucledNum32.ValueChar = HZH_Controls.Controls.LEDNumChar.CHAR_5;
            // 
            // ucledNum33
            // 
            this.ucledNum33.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.ucledNum33.LineWidth = 8;
            this.ucledNum33.Location = new System.Drawing.Point(244, 162);
            this.ucledNum33.Name = "ucledNum33";
            this.ucledNum33.Size = new System.Drawing.Size(40, 60);
            this.ucledNum33.TabIndex = 19;
            this.ucledNum33.Value = '6';
            this.ucledNum33.ValueChar = HZH_Controls.Controls.LEDNumChar.CHAR_6;
            // 
            // ucledNum34
            // 
            this.ucledNum34.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.ucledNum34.LineWidth = 8;
            this.ucledNum34.Location = new System.Drawing.Point(290, 162);
            this.ucledNum34.Name = "ucledNum34";
            this.ucledNum34.Size = new System.Drawing.Size(40, 60);
            this.ucledNum34.TabIndex = 20;
            this.ucledNum34.Value = '7';
            this.ucledNum34.ValueChar = HZH_Controls.Controls.LEDNumChar.CHAR_7;
            // 
            // ucledNum35
            // 
            this.ucledNum35.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.ucledNum35.LineWidth = 8;
            this.ucledNum35.Location = new System.Drawing.Point(336, 162);
            this.ucledNum35.Name = "ucledNum35";
            this.ucledNum35.Size = new System.Drawing.Size(40, 60);
            this.ucledNum35.TabIndex = 21;
            this.ucledNum35.Value = '8';
            this.ucledNum35.ValueChar = HZH_Controls.Controls.LEDNumChar.CHAR_8;
            // 
            // ucledNum36
            // 
            this.ucledNum36.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.ucledNum36.LineWidth = 8;
            this.ucledNum36.Location = new System.Drawing.Point(382, 162);
            this.ucledNum36.Name = "ucledNum36";
            this.ucledNum36.Size = new System.Drawing.Size(40, 60);
            this.ucledNum36.TabIndex = 22;
            this.ucledNum36.Value = '9';
            this.ucledNum36.ValueChar = HZH_Controls.Controls.LEDNumChar.CHAR_9;
            // 
            // ucledNum37
            // 
            this.ucledNum37.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.ucledNum37.LineWidth = 8;
            this.ucledNum37.Location = new System.Drawing.Point(428, 162);
            this.ucledNum37.Name = "ucledNum37";
            this.ucledNum37.Size = new System.Drawing.Size(40, 60);
            this.ucledNum37.TabIndex = 23;
            this.ucledNum37.Value = '0';
            this.ucledNum37.ValueChar = HZH_Controls.Controls.LEDNumChar.CHAR_0;
            // 
            // ucledNum38
            // 
            this.ucledNum38.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.ucledNum38.LineWidth = 8;
            this.ucledNum38.Location = new System.Drawing.Point(474, 162);
            this.ucledNum38.Name = "ucledNum38";
            this.ucledNum38.Size = new System.Drawing.Size(40, 60);
            this.ucledNum38.TabIndex = 24;
            this.ucledNum38.Value = ':';
            this.ucledNum38.ValueChar = HZH_Controls.Controls.LEDNumChar.CHAR_Colon;
            // 
            // ucledNum39
            // 
            this.ucledNum39.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.ucledNum39.LineWidth = 8;
            this.ucledNum39.Location = new System.Drawing.Point(520, 162);
            this.ucledNum39.Name = "ucledNum39";
            this.ucledNum39.Size = new System.Drawing.Size(40, 60);
            this.ucledNum39.TabIndex = 25;
            this.ucledNum39.Value = '.';
            this.ucledNum39.ValueChar = HZH_Controls.Controls.LEDNumChar.CHAR_Dot;
            // 
            // ucledNum40
            // 
            this.ucledNum40.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.ucledNum40.LineWidth = 8;
            this.ucledNum40.Location = new System.Drawing.Point(566, 162);
            this.ucledNum40.Name = "ucledNum40";
            this.ucledNum40.Size = new System.Drawing.Size(40, 60);
            this.ucledNum40.TabIndex = 26;
            this.ucledNum40.Value = '-';
            this.ucledNum40.ValueChar = HZH_Controls.Controls.LEDNumChar.CHAR_HorizontalLine;
            // 
            // ucledNum41
            // 
            this.ucledNum41.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.ucledNum41.LineWidth = 8;
            this.ucledNum41.Location = new System.Drawing.Point(612, 162);
            this.ucledNum41.Name = "ucledNum41";
            this.ucledNum41.Size = new System.Drawing.Size(40, 60);
            this.ucledNum41.TabIndex = 27;
            this.ucledNum41.Value = 'A';
            this.ucledNum41.ValueChar = HZH_Controls.Controls.LEDNumChar.CHAR_A;
            // 
            // ucledNum42
            // 
            this.ucledNum42.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.ucledNum42.LineWidth = 8;
            this.ucledNum42.Location = new System.Drawing.Point(14, 240);
            this.ucledNum42.Name = "ucledNum42";
            this.ucledNum42.Size = new System.Drawing.Size(40, 60);
            this.ucledNum42.TabIndex = 28;
            this.ucledNum42.Value = 'b';
            this.ucledNum42.ValueChar = HZH_Controls.Controls.LEDNumChar.CHAR_b;
            // 
            // ucledNum43
            // 
            this.ucledNum43.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.ucledNum43.LineWidth = 8;
            this.ucledNum43.Location = new System.Drawing.Point(60, 240);
            this.ucledNum43.Name = "ucledNum43";
            this.ucledNum43.Size = new System.Drawing.Size(40, 60);
            this.ucledNum43.TabIndex = 29;
            this.ucledNum43.Value = 'C';
            this.ucledNum43.ValueChar = HZH_Controls.Controls.LEDNumChar.CHAR_C;
            // 
            // ucledNum44
            // 
            this.ucledNum44.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.ucledNum44.LineWidth = 8;
            this.ucledNum44.Location = new System.Drawing.Point(106, 240);
            this.ucledNum44.Name = "ucledNum44";
            this.ucledNum44.Size = new System.Drawing.Size(40, 60);
            this.ucledNum44.TabIndex = 30;
            this.ucledNum44.Value = 'c';
            this.ucledNum44.ValueChar = HZH_Controls.Controls.LEDNumChar.CHAR_c;
            // 
            // ucledNum45
            // 
            this.ucledNum45.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.ucledNum45.LineWidth = 8;
            this.ucledNum45.Location = new System.Drawing.Point(152, 240);
            this.ucledNum45.Name = "ucledNum45";
            this.ucledNum45.Size = new System.Drawing.Size(40, 60);
            this.ucledNum45.TabIndex = 31;
            this.ucledNum45.Value = 'd';
            this.ucledNum45.ValueChar = HZH_Controls.Controls.LEDNumChar.CHAR_d;
            // 
            // ucledNum46
            // 
            this.ucledNum46.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.ucledNum46.LineWidth = 8;
            this.ucledNum46.Location = new System.Drawing.Point(198, 240);
            this.ucledNum46.Name = "ucledNum46";
            this.ucledNum46.Size = new System.Drawing.Size(40, 60);
            this.ucledNum46.TabIndex = 32;
            this.ucledNum46.Value = 'E';
            this.ucledNum46.ValueChar = HZH_Controls.Controls.LEDNumChar.CHAR_E;
            // 
            // ucledNum47
            // 
            this.ucledNum47.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.ucledNum47.LineWidth = 8;
            this.ucledNum47.Location = new System.Drawing.Point(244, 240);
            this.ucledNum47.Name = "ucledNum47";
            this.ucledNum47.Size = new System.Drawing.Size(40, 60);
            this.ucledNum47.TabIndex = 33;
            this.ucledNum47.Value = 'F';
            this.ucledNum47.ValueChar = HZH_Controls.Controls.LEDNumChar.CHAR_F;
            // 
            // ucledNum48
            // 
            this.ucledNum48.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.ucledNum48.LineWidth = 8;
            this.ucledNum48.Location = new System.Drawing.Point(290, 240);
            this.ucledNum48.Name = "ucledNum48";
            this.ucledNum48.Size = new System.Drawing.Size(40, 60);
            this.ucledNum48.TabIndex = 34;
            this.ucledNum48.Value = 'H';
            this.ucledNum48.ValueChar = HZH_Controls.Controls.LEDNumChar.CHAR_H;
            // 
            // ucledNum49
            // 
            this.ucledNum49.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.ucledNum49.LineWidth = 8;
            this.ucledNum49.Location = new System.Drawing.Point(336, 240);
            this.ucledNum49.Name = "ucledNum49";
            this.ucledNum49.Size = new System.Drawing.Size(40, 60);
            this.ucledNum49.TabIndex = 35;
            this.ucledNum49.Value = 'h';
            this.ucledNum49.ValueChar = HZH_Controls.Controls.LEDNumChar.CHAR_h;
            // 
            // ucledNum50
            // 
            this.ucledNum50.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.ucledNum50.LineWidth = 8;
            this.ucledNum50.Location = new System.Drawing.Point(382, 240);
            this.ucledNum50.Name = "ucledNum50";
            this.ucledNum50.Size = new System.Drawing.Size(40, 60);
            this.ucledNum50.TabIndex = 36;
            this.ucledNum50.Value = 'J';
            this.ucledNum50.ValueChar = HZH_Controls.Controls.LEDNumChar.CHAR_J;
            // 
            // ucledNum51
            // 
            this.ucledNum51.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.ucledNum51.LineWidth = 8;
            this.ucledNum51.Location = new System.Drawing.Point(428, 240);
            this.ucledNum51.Name = "ucledNum51";
            this.ucledNum51.Size = new System.Drawing.Size(40, 60);
            this.ucledNum51.TabIndex = 37;
            this.ucledNum51.Value = 'L';
            this.ucledNum51.ValueChar = HZH_Controls.Controls.LEDNumChar.CHAR_L;
            // 
            // ucledNum52
            // 
            this.ucledNum52.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.ucledNum52.LineWidth = 8;
            this.ucledNum52.Location = new System.Drawing.Point(474, 240);
            this.ucledNum52.Name = "ucledNum52";
            this.ucledNum52.Size = new System.Drawing.Size(40, 60);
            this.ucledNum52.TabIndex = 38;
            this.ucledNum52.Value = 'o';
            this.ucledNum52.ValueChar = HZH_Controls.Controls.LEDNumChar.CHAR_o;
            // 
            // ucledNum53
            // 
            this.ucledNum53.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.ucledNum53.LineWidth = 8;
            this.ucledNum53.Location = new System.Drawing.Point(520, 240);
            this.ucledNum53.Name = "ucledNum53";
            this.ucledNum53.Size = new System.Drawing.Size(40, 60);
            this.ucledNum53.TabIndex = 39;
            this.ucledNum53.Value = 'P';
            this.ucledNum53.ValueChar = HZH_Controls.Controls.LEDNumChar.CHAR_P;
            // 
            // ucledNum54
            // 
            this.ucledNum54.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.ucledNum54.LineWidth = 8;
            this.ucledNum54.Location = new System.Drawing.Point(566, 240);
            this.ucledNum54.Name = "ucledNum54";
            this.ucledNum54.Size = new System.Drawing.Size(40, 60);
            this.ucledNum54.TabIndex = 40;
            this.ucledNum54.Value = 'r';
            this.ucledNum54.ValueChar = HZH_Controls.Controls.LEDNumChar.CHAR_r;
            // 
            // ucledNum55
            // 
            this.ucledNum55.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.ucledNum55.LineWidth = 8;
            this.ucledNum55.Location = new System.Drawing.Point(612, 240);
            this.ucledNum55.Name = "ucledNum55";
            this.ucledNum55.Size = new System.Drawing.Size(40, 60);
            this.ucledNum55.TabIndex = 15;
            this.ucledNum55.Value = 'U';
            this.ucledNum55.ValueChar = HZH_Controls.Controls.LEDNumChar.CHAR_U;
            // 
            // UCTestLED
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.ucledNums2);
            this.Controls.Add(this.ucledNums1);
            this.Controls.Add(this.ucledDataTime1);
            this.Controls.Add(this.ucledTime2);
            this.Controls.Add(this.ucledDate1);
            this.Controls.Add(this.ucledNum55);
            this.Controls.Add(this.ucledNum27);
            this.Controls.Add(this.ucledNum54);
            this.Controls.Add(this.ucledNum26);
            this.Controls.Add(this.ucledNum53);
            this.Controls.Add(this.ucledNum25);
            this.Controls.Add(this.ucledNum52);
            this.Controls.Add(this.ucledNum24);
            this.Controls.Add(this.ucledNum51);
            this.Controls.Add(this.ucledNum23);
            this.Controls.Add(this.ucledNum50);
            this.Controls.Add(this.ucledNum22);
            this.Controls.Add(this.ucledNum49);
            this.Controls.Add(this.ucledNum21);
            this.Controls.Add(this.ucledNum48);
            this.Controls.Add(this.ucledNum20);
            this.Controls.Add(this.ucledNum47);
            this.Controls.Add(this.ucledNum19);
            this.Controls.Add(this.ucledNum46);
            this.Controls.Add(this.ucledNum18);
            this.Controls.Add(this.ucledNum45);
            this.Controls.Add(this.ucledNum17);
            this.Controls.Add(this.ucledNum44);
            this.Controls.Add(this.ucledNum16);
            this.Controls.Add(this.ucledNum43);
            this.Controls.Add(this.ucledNum15);
            this.Controls.Add(this.ucledNum42);
            this.Controls.Add(this.ucledNum14);
            this.Controls.Add(this.ucledNum41);
            this.Controls.Add(this.ucledNum13);
            this.Controls.Add(this.ucledNum40);
            this.Controls.Add(this.ucledNum12);
            this.Controls.Add(this.ucledNum39);
            this.Controls.Add(this.ucledNum11);
            this.Controls.Add(this.ucledNum38);
            this.Controls.Add(this.ucledNum10);
            this.Controls.Add(this.ucledNum37);
            this.Controls.Add(this.ucledNum9);
            this.Controls.Add(this.ucledNum36);
            this.Controls.Add(this.ucledNum8);
            this.Controls.Add(this.ucledNum35);
            this.Controls.Add(this.ucledNum7);
            this.Controls.Add(this.ucledNum34);
            this.Controls.Add(this.ucledNum6);
            this.Controls.Add(this.ucledNum33);
            this.Controls.Add(this.ucledNum5);
            this.Controls.Add(this.ucledNum32);
            this.Controls.Add(this.ucledNum4);
            this.Controls.Add(this.ucledNum31);
            this.Controls.Add(this.ucledNum3);
            this.Controls.Add(this.ucledNum30);
            this.Controls.Add(this.ucledNum2);
            this.Controls.Add(this.ucledNum29);
            this.Controls.Add(this.ucledNum28);
            this.Controls.Add(this.ucledNum1);
            this.Controls.Add(this.ledNum1);
            this.Name = "UCTestLED";
            this.Size = new System.Drawing.Size(864, 619);
            this.ResumeLayout(false);

        }

        #endregion

        private HZH_Controls.Controls.UCLEDNum ucledNum27;
        private HZH_Controls.Controls.UCLEDNum ucledNum26;
        private HZH_Controls.Controls.UCLEDNum ucledNum25;
        private HZH_Controls.Controls.UCLEDNum ucledNum24;
        private HZH_Controls.Controls.UCLEDNum ucledNum23;
        private HZH_Controls.Controls.UCLEDNum ucledNum22;
        private HZH_Controls.Controls.UCLEDNum ucledNum21;
        private HZH_Controls.Controls.UCLEDNum ucledNum20;
        private HZH_Controls.Controls.UCLEDNum ucledNum19;
        private HZH_Controls.Controls.UCLEDNum ucledNum18;
        private HZH_Controls.Controls.UCLEDNum ucledNum17;
        private HZH_Controls.Controls.UCLEDNum ucledNum16;
        private HZH_Controls.Controls.UCLEDNum ucledNum15;
        private HZH_Controls.Controls.UCLEDNum ucledNum14;
        private HZH_Controls.Controls.UCLEDNum ucledNum13;
        private HZH_Controls.Controls.UCLEDNum ucledNum12;
        private HZH_Controls.Controls.UCLEDNum ucledNum11;
        private HZH_Controls.Controls.UCLEDNum ucledNum10;
        private HZH_Controls.Controls.UCLEDNum ucledNum9;
        private HZH_Controls.Controls.UCLEDNum ucledNum8;
        private HZH_Controls.Controls.UCLEDNum ucledNum7;
        private HZH_Controls.Controls.UCLEDNum ucledNum6;
        private HZH_Controls.Controls.UCLEDNum ucledNum5;
        private HZH_Controls.Controls.UCLEDNum ucledNum4;
        private HZH_Controls.Controls.UCLEDNum ucledNum3;
        private HZH_Controls.Controls.UCLEDNum ucledNum2;
        private HZH_Controls.Controls.UCLEDNum ucledNum1;
        private HZH_Controls.Controls.UCLEDNum ledNum1;
        private HZH_Controls.Controls.UCLEDNums ucledNums2;
        private HZH_Controls.Controls.UCLEDNums ucledNums1;
        private HZH_Controls.Controls.UCLEDDataTime ucledDataTime1;
        private HZH_Controls.Controls.UCLEDTime ucledTime2;
        private HZH_Controls.Controls.UCLEDData ucledDate1;
        private System.Windows.Forms.Timer timer1;
        private HZH_Controls.Controls.UCLEDNum ucledNum28;
        private HZH_Controls.Controls.UCLEDNum ucledNum29;
        private HZH_Controls.Controls.UCLEDNum ucledNum30;
        private HZH_Controls.Controls.UCLEDNum ucledNum31;
        private HZH_Controls.Controls.UCLEDNum ucledNum32;
        private HZH_Controls.Controls.UCLEDNum ucledNum33;
        private HZH_Controls.Controls.UCLEDNum ucledNum34;
        private HZH_Controls.Controls.UCLEDNum ucledNum35;
        private HZH_Controls.Controls.UCLEDNum ucledNum36;
        private HZH_Controls.Controls.UCLEDNum ucledNum37;
        private HZH_Controls.Controls.UCLEDNum ucledNum38;
        private HZH_Controls.Controls.UCLEDNum ucledNum39;
        private HZH_Controls.Controls.UCLEDNum ucledNum40;
        private HZH_Controls.Controls.UCLEDNum ucledNum41;
        private HZH_Controls.Controls.UCLEDNum ucledNum42;
        private HZH_Controls.Controls.UCLEDNum ucledNum43;
        private HZH_Controls.Controls.UCLEDNum ucledNum44;
        private HZH_Controls.Controls.UCLEDNum ucledNum45;
        private HZH_Controls.Controls.UCLEDNum ucledNum46;
        private HZH_Controls.Controls.UCLEDNum ucledNum47;
        private HZH_Controls.Controls.UCLEDNum ucledNum48;
        private HZH_Controls.Controls.UCLEDNum ucledNum49;
        private HZH_Controls.Controls.UCLEDNum ucledNum50;
        private HZH_Controls.Controls.UCLEDNum ucledNum51;
        private HZH_Controls.Controls.UCLEDNum ucledNum52;
        private HZH_Controls.Controls.UCLEDNum ucledNum53;
        private HZH_Controls.Controls.UCLEDNum ucledNum54;
        private HZH_Controls.Controls.UCLEDNum ucledNum55;
    }
}
