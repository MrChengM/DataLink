﻿namespace Test.UC
{
    partial class UCTestSplitLabel
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.ucSplitLabel8 = new HZH_Controls.Controls.UCSplitLabel();
            this.ucSplitLabel4 = new HZH_Controls.Controls.UCSplitLabel();
            this.ucSplitLabel7 = new HZH_Controls.Controls.UCSplitLabel();
            this.ucSplitLabel3 = new HZH_Controls.Controls.UCSplitLabel();
            this.ucSplitLabel6 = new HZH_Controls.Controls.UCSplitLabel();
            this.ucSplitLabel2 = new HZH_Controls.Controls.UCSplitLabel();
            this.ucSplitLabel5 = new HZH_Controls.Controls.UCSplitLabel();
            this.ucSplitLabel1 = new HZH_Controls.Controls.UCSplitLabel();
            this.SuspendLayout();
            // 
            // ucSplitLabel8
            // 
            this.ucSplitLabel8.Font = new System.Drawing.Font("微软雅黑", 22F);
            this.ucSplitLabel8.LineColor = System.Drawing.Color.Blue;
            this.ucSplitLabel8.Location = new System.Drawing.Point(18, 305);
            this.ucSplitLabel8.MaximumSize = new System.Drawing.Size(0, 42);
            this.ucSplitLabel8.MinimumSize = new System.Drawing.Size(150, 42);
            this.ucSplitLabel8.Name = "ucSplitLabel8";
            this.ucSplitLabel8.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.ucSplitLabel8.Size = new System.Drawing.Size(465, 42);
            this.ucSplitLabel8.TabIndex = 0;
            this.ucSplitLabel8.Text = "22号大小";
            // 
            // ucSplitLabel4
            // 
            this.ucSplitLabel4.Font = new System.Drawing.Font("微软雅黑", 8F);
            this.ucSplitLabel4.LineColor = System.Drawing.Color.Blue;
            this.ucSplitLabel4.Location = new System.Drawing.Point(18, 145);
            this.ucSplitLabel4.MaximumSize = new System.Drawing.Size(0, 15);
            this.ucSplitLabel4.MinimumSize = new System.Drawing.Size(150, 15);
            this.ucSplitLabel4.Name = "ucSplitLabel4";
            this.ucSplitLabel4.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.ucSplitLabel4.Size = new System.Drawing.Size(465, 15);
            this.ucSplitLabel4.TabIndex = 0;
            this.ucSplitLabel4.Text = "颜色分隔";
            // 
            // ucSplitLabel7
            // 
            this.ucSplitLabel7.Font = new System.Drawing.Font("微软雅黑", 18F);
            this.ucSplitLabel7.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.ucSplitLabel7.Location = new System.Drawing.Point(18, 264);
            this.ucSplitLabel7.MaximumSize = new System.Drawing.Size(0, 34);
            this.ucSplitLabel7.MinimumSize = new System.Drawing.Size(150, 34);
            this.ucSplitLabel7.Name = "ucSplitLabel7";
            this.ucSplitLabel7.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.ucSplitLabel7.Size = new System.Drawing.Size(465, 34);
            this.ucSplitLabel7.TabIndex = 0;
            this.ucSplitLabel7.Text = "18号大小";
            // 
            // ucSplitLabel3
            // 
            this.ucSplitLabel3.Font = new System.Drawing.Font("微软雅黑", 8F);
            this.ucSplitLabel3.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.ucSplitLabel3.Location = new System.Drawing.Point(18, 104);
            this.ucSplitLabel3.MaximumSize = new System.Drawing.Size(0, 15);
            this.ucSplitLabel3.MinimumSize = new System.Drawing.Size(150, 15);
            this.ucSplitLabel3.Name = "ucSplitLabel3";
            this.ucSplitLabel3.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.ucSplitLabel3.Size = new System.Drawing.Size(465, 15);
            this.ucSplitLabel3.TabIndex = 0;
            this.ucSplitLabel3.Text = "绿色分隔";
            // 
            // ucSplitLabel6
            // 
            this.ucSplitLabel6.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.ucSplitLabel6.LineColor = System.Drawing.Color.Red;
            this.ucSplitLabel6.Location = new System.Drawing.Point(20, 223);
            this.ucSplitLabel6.MaximumSize = new System.Drawing.Size(0, 23);
            this.ucSplitLabel6.MinimumSize = new System.Drawing.Size(0, 23);
            this.ucSplitLabel6.Name = "ucSplitLabel6";
            this.ucSplitLabel6.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.ucSplitLabel6.Size = new System.Drawing.Size(463, 23);
            this.ucSplitLabel6.TabIndex = 0;
            this.ucSplitLabel6.Text = "12号大小";
            // 
            // ucSplitLabel2
            // 
            this.ucSplitLabel2.Font = new System.Drawing.Font("微软雅黑", 8F);
            this.ucSplitLabel2.LineColor = System.Drawing.Color.Red;
            this.ucSplitLabel2.Location = new System.Drawing.Point(18, 63);
            this.ucSplitLabel2.MaximumSize = new System.Drawing.Size(0, 15);
            this.ucSplitLabel2.MinimumSize = new System.Drawing.Size(0, 15);
            this.ucSplitLabel2.Name = "ucSplitLabel2";
            this.ucSplitLabel2.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.ucSplitLabel2.Size = new System.Drawing.Size(465, 15);
            this.ucSplitLabel2.TabIndex = 0;
            this.ucSplitLabel2.Text = "红色分隔";
            // 
            // ucSplitLabel5
            // 
            this.ucSplitLabel5.Font = new System.Drawing.Font("微软雅黑", 8F);
            this.ucSplitLabel5.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(238)))), ((int)(((byte)(245)))));
            this.ucSplitLabel5.Location = new System.Drawing.Point(18, 182);
            this.ucSplitLabel5.MaximumSize = new System.Drawing.Size(0, 15);
            this.ucSplitLabel5.MinimumSize = new System.Drawing.Size(0, 15);
            this.ucSplitLabel5.Name = "ucSplitLabel5";
            this.ucSplitLabel5.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.ucSplitLabel5.Size = new System.Drawing.Size(465, 15);
            this.ucSplitLabel5.TabIndex = 0;
            this.ucSplitLabel5.Text = "默认大小";
            // 
            // ucSplitLabel1
            // 
            this.ucSplitLabel1.Font = new System.Drawing.Font("微软雅黑", 8F);
            this.ucSplitLabel1.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(238)))), ((int)(((byte)(245)))));
            this.ucSplitLabel1.Location = new System.Drawing.Point(18, 22);
            this.ucSplitLabel1.MaximumSize = new System.Drawing.Size(0, 15);
            this.ucSplitLabel1.MinimumSize = new System.Drawing.Size(0, 15);
            this.ucSplitLabel1.Name = "ucSplitLabel1";
            this.ucSplitLabel1.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.ucSplitLabel1.Size = new System.Drawing.Size(465, 15);
            this.ucSplitLabel1.TabIndex = 0;
            this.ucSplitLabel1.Text = "默认颜色";
            // 
            // UCTestSplitLabel
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.ucSplitLabel8);
            this.Controls.Add(this.ucSplitLabel4);
            this.Controls.Add(this.ucSplitLabel7);
            this.Controls.Add(this.ucSplitLabel3);
            this.Controls.Add(this.ucSplitLabel6);
            this.Controls.Add(this.ucSplitLabel2);
            this.Controls.Add(this.ucSplitLabel5);
            this.Controls.Add(this.ucSplitLabel1);
            this.Name = "UCTestSplitLabel";
            this.Size = new System.Drawing.Size(814, 426);
            this.ResumeLayout(false);

        }

        #endregion

        private HZH_Controls.Controls.UCSplitLabel ucSplitLabel1;
        private HZH_Controls.Controls.UCSplitLabel ucSplitLabel2;
        private HZH_Controls.Controls.UCSplitLabel ucSplitLabel3;
        private HZH_Controls.Controls.UCSplitLabel ucSplitLabel4;
        private HZH_Controls.Controls.UCSplitLabel ucSplitLabel5;
        private HZH_Controls.Controls.UCSplitLabel ucSplitLabel6;
        private HZH_Controls.Controls.UCSplitLabel ucSplitLabel7;
        private HZH_Controls.Controls.UCSplitLabel ucSplitLabel8;
    }
}
