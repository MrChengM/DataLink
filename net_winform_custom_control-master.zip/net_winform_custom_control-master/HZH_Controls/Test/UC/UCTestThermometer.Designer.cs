﻿namespace Test.UC
{
    partial class UCTestThermometer
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.ucThermometer1 = new HZH_Controls.Controls.UCThermometer();
            this.ucThermometer2 = new HZH_Controls.Controls.UCThermometer();
            this.ucThermometer3 = new HZH_Controls.Controls.UCThermometer();
            this.ucThermometer4 = new HZH_Controls.Controls.UCThermometer();
            this.ucThermometer5 = new HZH_Controls.Controls.UCThermometer();
            this.ucThermometer6 = new HZH_Controls.Controls.UCThermometer();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // ucThermometer1
            // 
            this.ucThermometer1.ForeColor = System.Drawing.Color.Black;
            this.ucThermometer1.GlassTubeColor = System.Drawing.Color.FromArgb(((int)(((byte)(211)))), ((int)(((byte)(211)))), ((int)(((byte)(211)))));
            this.ucThermometer1.LeftTemperatureUnit = HZH_Controls.Controls.TemperatureUnit.C;
            this.ucThermometer1.Location = new System.Drawing.Point(30, 17);
            this.ucThermometer1.MaxValue = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.ucThermometer1.MercuryColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucThermometer1.MinValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.ucThermometer1.Name = "ucThermometer1";
            this.ucThermometer1.RightTemperatureUnit = HZH_Controls.Controls.TemperatureUnit.F;
            this.ucThermometer1.Size = new System.Drawing.Size(101, 481);
            this.ucThermometer1.SplitCount = 10;
            this.ucThermometer1.TabIndex = 29;
            this.ucThermometer1.Value = new decimal(new int[] {
            55,
            0,
            0,
            0});
            // 
            // ucThermometer2
            // 
            this.ucThermometer2.ForeColor = System.Drawing.Color.Black;
            this.ucThermometer2.GlassTubeColor = System.Drawing.Color.FromArgb(((int)(((byte)(211)))), ((int)(((byte)(211)))), ((int)(((byte)(211)))));
            this.ucThermometer2.LeftTemperatureUnit = HZH_Controls.Controls.TemperatureUnit.C;
            this.ucThermometer2.Location = new System.Drawing.Point(211, 17);
            this.ucThermometer2.MaxValue = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.ucThermometer2.MercuryColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucThermometer2.MinValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.ucThermometer2.Name = "ucThermometer2";
            this.ucThermometer2.RightTemperatureUnit = HZH_Controls.Controls.TemperatureUnit.C;
            this.ucThermometer2.Size = new System.Drawing.Size(101, 481);
            this.ucThermometer2.SplitCount = 10;
            this.ucThermometer2.TabIndex = 29;
            this.ucThermometer2.Value = new decimal(new int[] {
            55,
            0,
            0,
            0});
            // 
            // ucThermometer3
            // 
            this.ucThermometer3.ForeColor = System.Drawing.Color.Black;
            this.ucThermometer3.GlassTubeColor = System.Drawing.Color.FromArgb(((int)(((byte)(211)))), ((int)(((byte)(211)))), ((int)(((byte)(211)))));
            this.ucThermometer3.LeftTemperatureUnit = HZH_Controls.Controls.TemperatureUnit.C;
            this.ucThermometer3.Location = new System.Drawing.Point(385, 17);
            this.ucThermometer3.MaxValue = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.ucThermometer3.MercuryColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucThermometer3.MinValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.ucThermometer3.Name = "ucThermometer3";
            this.ucThermometer3.RightTemperatureUnit = HZH_Controls.Controls.TemperatureUnit.None;
            this.ucThermometer3.Size = new System.Drawing.Size(101, 481);
            this.ucThermometer3.SplitCount = 10;
            this.ucThermometer3.TabIndex = 29;
            this.ucThermometer3.Value = new decimal(new int[] {
            55,
            0,
            0,
            0});
            // 
            // ucThermometer4
            // 
            this.ucThermometer4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(159)))), ((int)(((byte)(255)))));
            this.ucThermometer4.GlassTubeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(64)))), ((int)(((byte)(86)))));
            this.ucThermometer4.LeftTemperatureUnit = HZH_Controls.Controls.TemperatureUnit.C;
            this.ucThermometer4.Location = new System.Drawing.Point(513, 17);
            this.ucThermometer4.MaxValue = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.ucThermometer4.MercuryColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.ucThermometer4.MinValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.ucThermometer4.Name = "ucThermometer4";
            this.ucThermometer4.RightTemperatureUnit = HZH_Controls.Controls.TemperatureUnit.F;
            this.ucThermometer4.Size = new System.Drawing.Size(101, 481);
            this.ucThermometer4.SplitCount = 10;
            this.ucThermometer4.TabIndex = 29;
            this.ucThermometer4.Value = new decimal(new int[] {
            55,
            0,
            0,
            0});
            // 
            // ucThermometer5
            // 
            this.ucThermometer5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(159)))), ((int)(((byte)(255)))));
            this.ucThermometer5.GlassTubeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(64)))), ((int)(((byte)(86)))));
            this.ucThermometer5.LeftTemperatureUnit = HZH_Controls.Controls.TemperatureUnit.C;
            this.ucThermometer5.Location = new System.Drawing.Point(694, 17);
            this.ucThermometer5.MaxValue = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.ucThermometer5.MercuryColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.ucThermometer5.MinValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.ucThermometer5.Name = "ucThermometer5";
            this.ucThermometer5.RightTemperatureUnit = HZH_Controls.Controls.TemperatureUnit.C;
            this.ucThermometer5.Size = new System.Drawing.Size(101, 481);
            this.ucThermometer5.SplitCount = 10;
            this.ucThermometer5.TabIndex = 29;
            this.ucThermometer5.Value = new decimal(new int[] {
            55,
            0,
            0,
            0});
            // 
            // ucThermometer6
            // 
            this.ucThermometer6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(159)))), ((int)(((byte)(255)))));
            this.ucThermometer6.GlassTubeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(64)))), ((int)(((byte)(86)))));
            this.ucThermometer6.LeftTemperatureUnit = HZH_Controls.Controls.TemperatureUnit.C;
            this.ucThermometer6.Location = new System.Drawing.Point(868, 17);
            this.ucThermometer6.MaxValue = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.ucThermometer6.MercuryColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.ucThermometer6.MinValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.ucThermometer6.Name = "ucThermometer6";
            this.ucThermometer6.RightTemperatureUnit = HZH_Controls.Controls.TemperatureUnit.None;
            this.ucThermometer6.Size = new System.Drawing.Size(101, 481);
            this.ucThermometer6.SplitCount = 10;
            this.ucThermometer6.TabIndex = 29;
            this.ucThermometer6.Value = new decimal(new int[] {
            55,
            0,
            0,
            0});
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(60, 544);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(359, 12);
            this.label1.TabIndex = 30;
            this.label1.Text = "左右刻度支持分别设置 摄氏度、华氏度、兰氏度、列氏度、开尔文";
            // 
            // UCTestThermometer
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.label1);
            this.Controls.Add(this.ucThermometer6);
            this.Controls.Add(this.ucThermometer3);
            this.Controls.Add(this.ucThermometer5);
            this.Controls.Add(this.ucThermometer4);
            this.Controls.Add(this.ucThermometer2);
            this.Controls.Add(this.ucThermometer1);
            this.Name = "UCTestThermometer";
            this.Size = new System.Drawing.Size(1080, 713);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private HZH_Controls.Controls.UCThermometer ucThermometer1;
        private HZH_Controls.Controls.UCThermometer ucThermometer2;
        private HZH_Controls.Controls.UCThermometer ucThermometer3;
        private HZH_Controls.Controls.UCThermometer ucThermometer4;
        private HZH_Controls.Controls.UCThermometer ucThermometer5;
        private HZH_Controls.Controls.UCThermometer ucThermometer6;
        private System.Windows.Forms.Label label1;
    }
}
